﻿# TODO: Translation updated at 2026-10-07 22:53

translate Spanish strings:

    # game/options.rpy:15
    old "To Die With Ben"
    new "To Die With Ben"

    # game/options.rpy:32
    old "Автором игры является Митч.\n\nМеня вы можете найти в телеграмме: tea_house_Mitch\n\nДля игры я использовала музыку:\n\nMusic: https://www.bensound.com License code: SDFELDWQYOV6TLY7 Artist: : Benjamin Tissot\n\nRoyalty Free Music: Bensound.com/royalty-free-music License code: 5CBGOV1HO57ALDOQ Artist: : Benjamin Tissot\n\nMusic by: bensound.com License code: ZN8VLZENF423WXQP Artist: : Benjamin Tissot\n\nТак же некоторые звуки я брала с сайта: ZvukiPro.com\n\nХочу так же выразить благодарность всем людям, кто поддерживал меня на протяжении всего этого времени! Чмок в пупок, вы лучшие!"
    new "La autora del juego es Mitch.\n\nPueden encontrarme en Telegram: tea_house_Mitch\n\nPara el juego utilicé la siguiente música:\n\nMusic: https://www.bensound.com License code: SDFELDWQYOV6TLY7 Artist: : Benjamin Tissot\n\nRoyalty Free Music: Bensound.com/royalty-free-music License code: 5CBGOV1HO57ALDOQ Artist: : Benjamin Tissot\n\nMusic by: bensound.com License code: ZN8VLZENF423WXQP Artist: : Benjamin Tissot\n\nAdemás, tomé algunos sonidos del sitio: ZvukiPro.com\n\nTambién quiero agradecer a todas las personas que me apoyaron durante todo este tiempo. ¡Un besito en el ombligo, son lo mejor!"

