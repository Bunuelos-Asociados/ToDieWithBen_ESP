# TODO: Translation updated at 2026-10-07 22:53

# game/script3.rpy:5
translate Spanish start_8c3464d7:

    # "День, наконец, закончился и на город опустилась долгожданная прохлада."
    "Por fin terminó el día y sobre la ciudad descendió la tan esperada frescura."

# game/script3.rpy:7
translate Spanish start_f92b1263:

    # "Дождь постепенно переходил в ливень, находясь в тепле мне нравилось слушать как большие капли разбивались об окно и подоконник."
    "La lluvia se iba convirtiendo poco a poco en un aguacero y, al resguardo y con calidez, me gustaba escuchar cómo las gotas grandes se estrellaban contra la ventana y el alféizar."

# game/script3.rpy:10
translate Spanish start_e2fc40fb:

    # "Сессия была удачно закрыта, с общежития уехали все соседи и я наконец была предоставлена сама себе"
    "Los exámenes del semestre se habían superado con éxito, todos los compañeros de la residencia se habían marchado y, por fin, estaba completamente sola."

# game/script3.rpy:13
translate Spanish start_c03dd4b6:

    # "Уже после учёбы у меня в руках был массивный картридж, на котором чёрным маркером было написано Majora."
    "Después de clases, tenía en las manos un cartucho enorme en el que, con rotulador negro, ponía Majora."

# game/script3.rpy:16
translate Spanish start_caca0e46:

    # "Видимо кто-то случайно выронил его, а может и сознательно хотел избавиться от игры."
    "Quizás alguien lo había perdido por accidente, o tal vez se había deshecho de él a propósito."

# game/script3.rpy:19
translate Spanish start_5017d472:

    # "В любом случае, я была рада находке. Я давно не играла в Зельду."
    "En cualquier caso, me alegró el hallazgo. Hacía mucho que no jugaba a Zelda."

# game/script3.rpy:23
translate Spanish start_cf8cc34a:

    # "Руки сами потянулись к телевизору, но они так же резко остановились."
    "Mis manos se dirigieron solas hacia el televisor, pero se detuvieron en seco."

# game/script3.rpy:25
translate Spanish start_dda96fa8:

    # "Всё же игру потрепало время, а может это и вовсе не была та игра, о которой я думала."
    "Después de todo, el juego había sufrido el paso del tiempo, y quizás ni siquiera era el juego que yo creía."

# game/script3.rpy:29
translate Spanish fem_f295634e:

    # "Точно ли было хорошей идеей использовать картридж?"
    "¿Era realmente buena idea usar ese cartucho?"

# game/script3.rpy:32
translate Spanish fem_45d8ad56:

    # e "да, всё же это плохая идея."
    e "Sí, de todos modos es una mala idea."

# game/script3.rpy:33
translate Spanish fem_cb5d1860:

    # e "Я не знаю у кого был этот картридж до этого."
    e "No sé de quién fue este cartucho antes."

# game/script3.rpy:34
translate Spanish fem_1403d2fd:

    # "Я вытащила картридж кидая его куда-то на кровать, думаю я смогу провести вечер чуть иначе."
    "Saqué el cartucho y lo lancé sobre la cama, en algún lado. Creo que podré pasar la tarde de otra manera."

# game/script3.rpy:44
translate Spanish fem_300e4b2d:

    # "я подошла к старому телевизору"
    "Me acerqué al viejo televisor."

# game/script3.rpy:46
translate Spanish fem_403dbb17:

    # "включив игру, мне показалось, что она была самой обычной."
    "Al encender el juego, me pareció lo más normal del mundo."

# game/script3.rpy:50
translate Spanish fem_7362c4b0:

    # "Я верчу в руке картридж."
    "Hago girar el cartucho en mi mano."

# game/script3.rpy:51
translate Spanish fem_075990e5:

    # "Я осматриваю его снизу и сверху но ничего не замечаю."
    "Lo examino por arriba y por abajo, pero no noto nada fuera de lo común."

# game/script3.rpy:52
translate Spanish fem_fb6ee222:

    # "Обычный картридж."
    "Un cartucho normal y corriente."

# game/script3.rpy:55
translate Spanish fem2_f5afea6b:

    # "Может, всё же запустить игру?"
    "¿Quizás debería probar el juego de todos modos?"

# game/script3.rpy:56
translate Spanish fem2_fa949f9e:

    # "Да. В нём нет ничего странного."
    "Sí. No tiene nada de extraño."

# game/script3.rpy:57
translate Spanish fem2_74895e0d:

    # "Однако..."
    "Sin embargo..."

# game/script3.rpy:59
translate Spanish fem2_53a78b29:

    # "Я вставила картридж и тут же ужаснулась!"
    "Inserté el cartucho y me horroricé al instante."

# game/script3.rpy:60
translate Spanish fem2_ab9df70d:

    # "Этот картридж точно пренадлежал извращенцу!"
    "¡Seguro que este cartucho perteneció a un pervertido!"

# game/script3.rpy:61
translate Spanish fem2_17011fe5:

    # "Это что Линк?"
    "¿Eso es Link?"

# game/script3.rpy:62
translate Spanish fem2_4b9d5725:

    # "Какой кошмар!"
    "¡Qué pesadilla!"

# game/script3.rpy:72
translate Spanish tupozvolil_c9fbc3aa:

    # "Да, кажется, это просто никому не нужный картридж, с записанной на нём старой игрой."
    "Sí, parece un cartucho que nadie quiere, con un juego antiguo grabado en él."

# game/script3.rpy:75
translate Spanish tupozvolil_62c47545:

    # "Но вдруг телевизор потух"
    "Pero de pronto, la pantalla se apagó."

# game/script3.rpy:76
translate Spanish tupozvolil_5859eab8:

    # e "Чёрт, на что я надеялась!"
    e "Maldición, ¿qué esperaba?"

# game/script3.rpy:77
translate Spanish tupozvolil_3236e94e:

    # "Я предполагала, что игра взломана, но она видимо изначально была неисправна, вот владелец и решил выкинуть картридж."
    "Supuse que el juego estaba modificado, pero al parecer ya venía defectuoso de fábrica; por eso el dueño decidió deshacerse del cartucho."

# game/script3.rpy:79
translate Spanish tupozvolil_e2244f01:

    # "Но резко меня словно током прошибло!"
    "¡Pero de repente sentí una descarga, como si me hubiera dado un calambrazo!"

# game/script3.rpy:81
translate Spanish tupozvolil_c28f5418:

    # "Экран вдруг зажёгся и из него показались руки, затем белёсая макушка, а после и передняя часть тела!"
    "La pantalla se encendió de golpe y de ella asomaron unas manos, luego una coronilla pálida y, después, la parte superior del cuerpo."

# game/script3.rpy:84
translate Spanish tupozvolil_6db9a3aa:

    # "Ужас пронзил меня, когда в пустых глазницах загорелись две красные точки и по щекам, словно слёзы, крупными каплями начала катиться кровь!"
    "El terror me atravesó cuando en las cuencas vacías se encendieron dos puntos rojos y, por las mejillas, como si fueran lágrimas, comenzaron a rodar gruesas gotas de sangre."

# game/script3.rpy:86
translate Spanish tupozvolil_e9b7aa9e:

    # "Кажется это Линк."
    "Parece que es Link."

# game/script3.rpy:87
translate Spanish tupozvolil_26a0fbe9:

    # "Хотя нет, это..."
    "Aunque no, es..."

# game/script3.rpy:90
translate Spanish tupozvolil_a9b12556:

    # e1 "Моё имя Бен."
    e1 "Mi nombre es Ben."

# game/script3.rpy:91
translate Spanish tupozvolil_ded555dc:

    # e1 "Хотя, может..."
    e1 "Aunque, quizás..."

# game/script3.rpy:93
translate Spanish tupozvolil_5187ed0f:

    # e1 "Оно тебе уже знакомо?"
    e1 "¿Ya te resulta familiar?"

# game/script3.rpy:94
translate Spanish tupozvolil_a26b233b:

    # "Существо полностью покинуло телевизор, вставая напротив меня. Я же вжалась в изголовье кровати."
    "La criatura salió por completo del televisor y se plantó frente a mí. Yo me encogí contra el cabecero de la cama."

# game/script3.rpy:96
translate Spanish tupozvolil_97f61b35:

    # "Он умеет читать мысли?"
    "¿Sabe leer la mente?"

# game/script3.rpy:97
translate Spanish tupozvolil_719b5d80:

    # "В горле встал ком. Кто или что сейчас стоит напротив меня!?"
    "Se me hizo un nudo en la garganta. ¿Quién o qué está parado frente a mí?"

# game/script3.rpy:98
translate Spanish tupozvolil_49cbbcd3:

    # "Существо с ухмылкой смотрело на меня ожидая ответа. В голове я начала прокручивать самые жуткие истории в надежде вспомнить в них его. Может я действительно что-то да слышала?"
    "La criatura me miraba con una sonrisa burlona, esperando una respuesta.En mi cabeza, empecé a repasar las historias más espeluznantes con la esperanza de recordar en cuál aparecía. ¿Y si de verdad había oído algo?"

# game/script3.rpy:107
translate Spanish tupozvolil_4d98383a:

    # e "кажется, что я тебя знаю"
    e "Creo que te conozco."

# game/script3.rpy:113
translate Spanish tupozvolil_31dac2eb:

    # e "Не припоминаю..."
    e "No recuerdo..."

# game/script3.rpy:119
translate Spanish tupozvolil_72a33094:

    # e "..."
    e "..."

# game/script3.rpy:122
translate Spanish tupozvolil_72a33094_1:

    # e "..."
    e "..."

# game/script3.rpy:125
translate Spanish tupozvolil_ed9e74a7:

    # e1 "Ладно, не важно."
    e1 "Bueno, no importa."

# game/script3.rpy:126
translate Spanish tupozvolil_5f2e5d25:

    # "Он поменялся в лице не получив ответ. В его голосе слышалось раздражение, он сразу попытался его скрыть."
    "Su expresión cambió al no recibir respuesta. Se notaba irritación en su voz, aunque intentó ocultarla de inmediato."

# game/script3.rpy:128
translate Spanish tupozvolil_1c27fc6e:

    # "Моё молчание определённо его не устроило."
    "Mi silencio, sin duda, no le convenció."

# game/script3.rpy:136
translate Spanish fg_58b4aaf8:

    # e1 "Ох, я польщён"
    e1 "Oh, me siento halagado."

# game/script3.rpy:137
translate Spanish fg_0fe0f7b0:

    # "Он заулыбался словно ребёнок"
    "Sonrió como un niño."

# game/script3.rpy:143
translate Spanish ff_75a71485:

    # e1 "Ха, не удивительно."
    e1 "Ja, no me sorprende."

# game/script3.rpy:146
translate Spanish ff_488892fd:

    # e1 "Человек, что знает обо мне, никогда бы не стал вставлять странный картридж в свою консоль."
    e1 "Alguien que supiera de mi existencia nunca habría insertado un cartucho extraño en su consola."

# game/script3.rpy:148
translate Spanish ff_1371c237:

    # "Он не упустил возможности меня пристыдить."
    "No dejó pasar la oportunidad de avergonzarme."

# game/script3.rpy:153
translate Spanish proda_189e974c:

    # "Я сидела ни жива ни мертва. Чего он хочет? Чёртов псих!"
    "Estaba sentada, más muerta que viva. ¿Qué quiere? ¡Maldito loco!"

# game/script3.rpy:156
translate Spanish proda_0626613b:

    # e1 "Что же."
    e1 "Pues nada."

# game/script3.rpy:157
translate Spanish proda_d16bd540:

    # e1 " Мы с тобой отлично проведём время!"
    e1 "¡Tú y yo vamos a pasar un rato genial!"

# game/script3.rpy:158
translate Spanish proda_2424d5d4:

    # e "Кто ты..."
    e "¿Quién eres...?"

# game/script3.rpy:161
translate Spanish proda_b51dfcc4:

    # e1 "Я же представился."
    e1 "Ya me presenté."

# game/script3.rpy:162
translate Spanish proda_15012605:

    # e1 "Глупый человек. Я Бен."
    e1 "Humano estúpido. Soy Ben."

# game/script3.rpy:163
translate Spanish proda_f1ca388b:

    # e1 "Бен утопленик."
    e1 "Ben Drowned."

# game/script3.rpy:164
translate Spanish proda_70145664:

    # e "Это определённо не может быть правдой. Я просто слишком устала."
    e "Esto definitivamente no puede ser real. Solo estoy demasiado cansada."

# game/script3.rpy:165
translate Spanish proda_feb230e0:

    # "Мне до последнего хотелось верить, что это просто глупый сон..."
    "Hasta el último momento quise creer que solo era un sueño tonto..."

# game/script3.rpy:168
translate Spanish proda_587ad4dd:

    # e1 "Все в начале говорят, что их участь лишь дурной сон и неправда... Всё это не реально."
    e1 "Todos al principio dicen que su destino es solo un mal sueño, que no es verdad... Que nada de esto es real."

# game/script3.rpy:170
translate Spanish proda_22d9a2b8:

    # e1 "Но знаешь что действительно реально?"
    e1 "¿Pero sabes qué es realmente real?"

# game/script3.rpy:174
translate Spanish proda_6af0d215:

    # "Он сжал руку и я тут же почувствовала ужасную боль в бедре."
    "Cerró el puño y, al instante, sentí un dolor espantoso en el muslo."

# game/script3.rpy:175
translate Spanish proda_df4622af:

    # e1 "Боль."
    e1 "El dolor."

# game/script3.rpy:176
translate Spanish proda_8e755865:

    # e1 "Согласись, это точно не может быть сном."
    e1 "Admítelo, esto definitivamente no puede ser un sueño."

# game/script3.rpy:179
translate Spanish proda_a06cccba:

    # "Я схватилась за рану глядя, как руки пачкаются от крови. Действительно не сон. Но что тогда?"
    "Me agarré la herida mientras veía cómo mis manos se manchaban de sangre. Realmente no es un sueño. Pero entonces, ¿qué es?"

# game/script3.rpy:181
translate Spanish proda_9972dd12:

    # "Паника медленно подступала. Он убьёт меня? Я хотела подняться, но боль глухо напомнила о себе"
    "El pánico empezaba a invadirme. ¿Me va a matar? Quise levantarme, pero un dolor sordo me recordó que estaba herida."

# game/script3.rpy:183
translate Spanish proda_84d5490f:

    # "Рядом с прикроватной тумбочкой лежал небольшой ножик. Он совсем недавно служил инструментом для нарезки фруктов и овощей."
    "Junto a la mesita de noche había un cuchillo pequeño. Hasta hacía poco, solo servía para cortar frutas y verduras."

# game/script3.rpy:185
translate Spanish proda_17df5c79:

    # "Но теперь он мог стать ключом к спасению."
    "Pero ahora podía ser la clave de mi salvación."

# game/script3.rpy:188
translate Spanish proda_fbfba810:

    # "Бен закатил глаза глядя на мою попытку встать."
    "Ben puso los ojos en blanco al ver mi intento de levantarme."

# game/script3.rpy:189
translate Spanish proda_12bf6cbd:

    # "И этого момента мне хватит что бы взять нож."
    "Y ese momento será suficiente para tomar el cuchillo."

# game/script3.rpy:190
translate Spanish proda_bafaa53a:

    # "Что же делать?"
    "¿Qué debo hacer?"

# game/script3.rpy:195
translate Spanish proda_e9fe095e:

    # "Мне надо быть уверенной в своей защите. Он не человек, нож мне точно пригодится."
    "Necesito asegurarme de poder defenderme. No es humano; el cuchillo definitivamente me servirá."

# game/script3.rpy:200
translate Spanish proda_bc71c142:

    # "Нет это плохая идея, мне нельзя так рисковать..."
    "No, es una mala idea, no debo arriesgarme así..."

# game/script3.rpy:204
translate Spanish noj_d88201b4:

    # "Теперь у меня есть какая-никакая защита."
    "Ahora tengo algo con qué defenderme."

# game/script3.rpy:205
translate Spanish noj_a1b66cab:

    # "Да и он всё ещё отвлечён."
    "Además, sigue distraído."

# game/script3.rpy:206
translate Spanish noj_5ba8fa39:

    # "Может..."
    "Quizás..."

# game/script3.rpy:207
translate Spanish noj_27ad5659:

    # "Это хороший момент для нападения. Один удар..."
    "Es un buen momento para atacar. Un solo golpe..."

# game/script3.rpy:210
translate Spanish noj_97188645:

    # "Этого момента вполне достаточно! Да и он не выглядит как сильный соперник!"
    "¡Este momento es más que suficiente! Además, no parece un rival fuerte."

# game/script3.rpy:213
translate Spanish noj_f49d9909:

    # "Дрожащими руками я держала перед собой нож."
    "Con manos temblorosas, sostenía el cuchillo frente a mí."

# game/script3.rpy:214
translate Spanish noj_78721c0a:

    # e1 "Отдай побрякушку. Не совершай ошибок."
    e1 "Entrégame esa baratija. No cometas errores."

# game/script3.rpy:219
translate Spanish noj_068cd9b2:

    # "Лучше я подожду другого момента."
    "Será mejor que espere otra oportunidad."

# game/script3.rpy:224
translate Spanish noj2_12a55a0f:

    # "Теперь уж точно нельзя медлить. Тут уж либо вперёд до конца, либо сдаваться."
    "Ahora no hay tiempo que perder. O llego hasta el final o me rindo."

# game/script3.rpy:229
translate Spanish noj2_625521a4:

    # "Вся решимость вмиг испарилась."
    "Toda mi determinación se evaporó al instante."

# game/script3.rpy:230
translate Spanish noj2_54336fb4:

    # "Я сжимаю зубы, но нож всё же отдаю. Он тут же пропадает у него в кармане."
    "Aprieto los dientes, pero aun así le entrego el cuchillo. Este desaparece de inmediato en su bolsillo."

# game/script3.rpy:231
translate Spanish noj2_0da693b5:

    # e1 "Эта штучка тебе бы всё равно не помогла."
    e1 "Esa cosa no te habría servido de todos modos."

# game/script3.rpy:236
translate Spanish noj2_a7ff5058:

    # "Я совершила выпад борясь с болью в ноге, лезвие ударило прямо в голову."
    "Me lancé hacia adelante luchando contra el dolor en la pierna; la hoja impactó directamente en su cabeza."

# game/script3.rpy:237
translate Spanish noj2_cc7c4468:

    # "Сейчас он упадёт и мучения кончатся!"
    "¡Ahora caerá y el sufrimiento terminará!"

# game/script3.rpy:239
translate Spanish noj2_972a5b19:

    # "Он замер."
    "Se quedó inmóvil."

# game/script3.rpy:241
translate Spanish noj2_f4bcd24c:

    # "Мы вдвоём лишь уставились на дыру... Удивительно, что небольшой ножик смог проломить череп."
    "Ambos nos quedamos mirando el agujero... Es sorprendente que un cuchillo tan pequeño haya logrado perforar el cráneo."

# game/script3.rpy:244
translate Spanish noj2_839d347f:

    # "Но из раны не потекла кровь... А он вновь лишь мерзко улыбнулся!"
    "Pero de la herida no brotó sangre... ¡Él solo volvió a esbozar una sonrisa repugnante!"

# game/script3.rpy:246
translate Spanish noj2_a4abe0c7:

    # "Более того: Дыра во лбу едва заметно, но стремительно начала исчезать!"
    "Más aún: el agujero en la frente comenzó a desaparecer, apenas perceptible pero a gran velocidad."

# game/script3.rpy:247
translate Spanish noj2_7c5c4d70:

    # e1 "Я ведь сказал не совершать ошибок."
    e1 "Te dije que no cometieras errores."

# game/script3.rpy:256
translate Spanish noj2_e42dbbde:

    # "Голову пронзила резкая боль."
    "Un dolor agudo me atravesó la cabeza."

# game/script3.rpy:257
translate Spanish noj2_fed4055e:

    # "Он с силой прижал меня к полу наседая сверху."
    "Me presionó con fuerza contra el suelo, echándose encima de mí."

# game/script3.rpy:258
translate Spanish noj2_71470e55:

    # "Одной рукой он крепко держал мои руки над головой."
    "Con una sola mano, sujetaba firmemente mis brazos por encima de mi cabeza."

# game/script3.rpy:259
translate Spanish noj2_5df29dd9:

    # "Совсем не могу пошевелиться... Да и едва могу дышать. "
    "No puedo moverme en absoluto... Y apenas puedo respirar."

# game/script3.rpy:260
translate Spanish noj2_a7c22bca:

    # "Я зря надеялась на то что он слаб! Он точно не человек!"
    "¡Fue un error creer que era débil! ¡Definitivamente no es humano!"

# game/script3.rpy:261
translate Spanish noj2_83b63990:

    # "Затылок пульсировал, я заметила, как блестел в его руке мой нож."
    "La nuca me palpitaba. Noté cómo brillaba mi cuchillo en su mano."

# game/script3.rpy:262
translate Spanish noj2_fc0e70ed:

    # e "Стой!"
    e "¡Detente!"

# game/script3.rpy:264
translate Spanish noj2_17f9f273:

    # "Не успела я прокричать мольбы, как лезвие легко вошло в тело, пробивая одежду и плоть."
    "No me dio tiempo a gritar mis súplicas cuando la hoja se deslizó con facilidad en mi cuerpo, atravesando la ropa y la carne."

# game/script3.rpy:266
translate Spanish noj2_3aa88906:

    # "В нос ударил запах крови."
    "El olor a sangre me golpeó la nariz."

# game/script3.rpy:267
translate Spanish noj2_d5e32393:

    # "Я закричала, но это никак не помогало облегчить боль."
    "Grité, pero eso no sirvió de nada para aliviar el dolor."

# game/script3.rpy:268
translate Spanish noj2_e7377137:

    # "Я чувствовала, как сталь поражает органы опускаясь глубже"
    "Sentía cómo el acero alcanzaba mis órganos, hundiéndose cada vez más."

# game/script3.rpy:269
translate Spanish noj2_e533181f:

    # "Он с улыбкой смотрел как вся моя одежда пропитывалась кровью."
    "Él sonreía al ver cómo toda mi ropa se empapaba de sangre."

# game/script3.rpy:270
translate Spanish noj2_32335e8e:

    # "Из глаз покатились слёзы, позже я сорвалась на рыдания."
    "Las lágrimas brotaron de mis ojos; después, rompí a sollozar."

# game/script3.rpy:272
translate Spanish noj2_0b67a22b:

    # "Когда нож повредил артерию, кровь брызнула фонтаном."
    "Cuando el cuchillo alcanzó una arteria, la sangre salió a borbotones."

# game/script3.rpy:273
translate Spanish noj2_b40b826f:

    # "И она смешивалась на лице с его кровью. Ему, кажется, нравилось пачкаться ей..."
    "Y se mezclaba en su rostro con su propia sangre. Parece que le gustaba ensuciarse con ella..."

# game/script3.rpy:274
translate Spanish noj2_f3e5f724:

    # "Я издала последний вопль, когда его рука вошла в распоротый живот."
    "Lancé un último grito cuando su mano se introdujo en mi abdomen abierto."

# game/script3.rpy:275
translate Spanish noj2_9792c4e4:

    # "Я чувствовала его холодные пальцы меж остатками органов."
    "Sentí sus dedos fríos entre los restos de mis órganos."

# game/script3.rpy:276
translate Spanish noj2_6eb566f3:

    # "Но уже через минуту я не чувствовала ничего..."
    "Pero al cabo de un minuto ya no sentía nada..."

# game/script3.rpy:277
translate Spanish noj2_19b8cc7f:

    # "Глаза медленно начали закрываться"
    "Mis ojos comenzaron a cerrarse lentamente."

# game/script3.rpy:280
translate Spanish noj2_a20cefa7:

    # "..."
    "..."

# game/script3.rpy:281
translate Spanish noj2_4cbe740e:

    # e1 "Тебя постигла ужасная участь, не так ли?"
    e1 "Te ha tocado un destino terrible, ¿verdad?"

# game/script3.rpy:293
translate Spanish proda2_cb056798:

    # "Он усмехается"
    "Él sonríe con suficiencia."

# game/script3.rpy:294
translate Spanish proda2_296ada7b:

    # e "Что тебе нужно?"
    e "¿Qué quieres?"

# game/script3.rpy:296
translate Spanish proda2_18661991:

    # "Он подходит ближе оказываясь совсем рядом со мной."
    "Se acerca hasta quedar muy cerca de mí."

# game/script3.rpy:297
translate Spanish proda2_2ffb82f5:

    # e1 "Знаешь"
    e1 "¿Sabes?"

# game/script3.rpy:299
translate Spanish proda2_625d770e:

    # e1 "Я так давно не чувствовал физического тела, уже почти забыл что это за ощущение."
    e1 "Hace tanto que no siento un cuerpo físico que casi había olvidado cómo se siente."

# game/script3.rpy:300
translate Spanish proda2_a5794d73:

    # e1 "Я соскучился по человеческим чувствам. По всем кроме эмпатии естественно."
    e1 "Extrañaba los sentimientos humanos. Todos, excepto la empatía, claro."

# game/script3.rpy:302
translate Spanish proda2_19c3e025:

    # "Он утробно посмеялся."
    "Soltó una risa grave y gutural."

# game/script3.rpy:303
translate Spanish proda2_4ee74c94:

    # e1 "Я уже второй раз оказываюсь в этом картридже. Благо кое-кто точно угадал с человеком которому достанется картридж."
    e1 "Es la segunda vez que termino en este cartucho. Por suerte, alguien supo elegir exactamente a la persona adecuada para recibirlo."

# game/script3.rpy:306
translate Spanish proda2_bc2abc35:

    # e1 "Мне было ужасно скучно."
    e1 "Me aburría terriblemente."

# game/script3.rpy:308
translate Spanish proda2_242144a3:

    # e1 "Но увидев тебя я понял, что смогу отлично провести это время!"
    e1 "¡Pero al verte entendí que podría pasar este tiempo de maravilla!"

# game/script3.rpy:310
translate Spanish proda2_f84c830c:

    # e1 "Ты ведь поможешь мне?"
    e1 "Me ayudarás, ¿verdad?"

# game/script3.rpy:311
translate Spanish proda2_d2ae4fa7:

    # e1 "Верно?"
    e1 "¿Cierto?"

# game/script3.rpy:312
translate Spanish proda2_ff6b31c2:

    # e "Я... э-эм."
    e "Yo... eh..."

# game/script3.rpy:313
translate Spanish proda2_63b74ab7:

    # "Внутри билось два чувства:"
    "Dos sentimientos luchaban en mi interior:"

# game/script3.rpy:314
translate Spanish proda2_cddacf57:

    # "Я осознавала, что любое резкое высказывание может стать финальным."
    "Sabía que cualquier palabra brusca podría ser la última."

# game/script3.rpy:315
translate Spanish proda2_79644485:

    # "Но в то же время плясать под его фальшивую дудку не хотелось."
    "Pero al mismo tiempo, no quería bailar al son de su falsa melodía."

# game/script3.rpy:320
translate Spanish proda2_cc3db282:

    # "Он хихикает."
    "Él suelta una risita."

# game/script3.rpy:321
translate Spanish proda2_78a27d39:

    # "На секунду я уловила дружеские нотки в его голосе."
    "Por un segundo, capté un tono amistoso en su voz."

# game/script3.rpy:323
translate Spanish proda2_85b0ef43:

    # e1 "Отлично..."
    e1 "Genial..."

# game/script3.rpy:324
translate Spanish proda2_68a9340a:

    # "Он схватил меня за грудки грубо поднимая с места."
    "Me agarró de la ropa a la altura del pecho y, con brusquedad, me levantó de mi sitio."

# game/script3.rpy:326
translate Spanish proda2_5a5bdb82:

    # "Едва ли я смогла насладиться чувством безопасности, как оказалась в воздухе."
    "Apenas tuve tiempo de sentirme a salvo cuando ya estaba en el aire."

# game/script3.rpy:327
translate Spanish proda2_25e79b28:

    # "И откуда в нём столько силы?!"
    "¿De dónde saca tanta fuerza?"

# game/script3.rpy:328
translate Spanish proda2_ea56f0ed:

    # "Не успела я об этом подумать, как спина соприкоснулась с телевизором."
    "No me dio tiempo a pensarlo cuando mi espalda chocó contra el televisor."

# game/script3.rpy:329
translate Spanish proda2_dcc9a7cb:

    # "Я не успеваю даже вскрикнуть в тот момент, когда тело коснулось экрана."
    "Ni siquiera me dio tiempo a gritar en el instante en que mi cuerpo tocó la pantalla."

# game/script3.rpy:330
translate Spanish proda2_24569459:

    # "Я ожидала, что стекло разобьётся."
    "Esperaba que el cristal se hiciera añicos."

# game/script3.rpy:331
translate Spanish proda2_c97149d9:

    # "Но вместо этого..."
    "Pero en lugar de eso..."

# game/script3.rpy:335
translate Spanish proda2_2614d0d2:

    # e1 "Да ладо тебе."
    e1 "Vamos, no seas así."

# game/script3.rpy:337
translate Spanish proda2_20075ff0:

    # e1 "Обещаю что мы отлично проведём время."
    e1 "Te prometo que nos divertiremos mucho."

# game/script3.rpy:342
translate Spanish proda2_0f719890:

    # "Я крикнула на него не боясь потерять самообладание."
    "Le grité, sin miedo a perder el control."

# game/script3.rpy:343
translate Spanish proda2_f4f07b47:

    # "Он, кажется, опешил не ожидая от тебя такой реакции"
    "Parece que se quedó desconcertado; no esperaba esa reacción de mi parte."

# game/script3.rpy:345
translate Spanish proda2_de3a1185:

    # "Но после он довольно хмыкнул."
    "Pero después soltó un 'mm' satisfecho."

# game/script3.rpy:346
translate Spanish proda2_9379eb96:

    # e1 "Ладно, вижу ты не фанатка острых ощущений."
    e1 "Bueno, veo que no eres fan de las emociones fuertes."

# game/script3.rpy:347
translate Spanish proda2_a9b65a41:

    # e1 "Но я принимаю твой выбор!"
    e1 "¡Pero acepto tu decisión!"

# game/script3.rpy:355
translate Spanish telic_1b2f24a3:

    # "Я оказалась внутри телевизора!"
    "¡Terminé dentro del televisor!"

# game/script3.rpy:357
translate Spanish telic_98095b97:

    # e "Боже!"
    e "¡Dios mío!"

# game/script3.rpy:359
translate Spanish telic_15b19b8e:

    # "Я вижу его через стекло экрана!"
    "¡Lo veo a través del cristal de la pantalla!"

# game/script3.rpy:360
translate Spanish telic_687838fb:

    # e1 "Ну как тебе?"
    e1 "¿Qué te parece?"

# game/script3.rpy:361
translate Spanish telic_bc02a3b6:

    # "Он наклонился к телевизору, заглядывая в мои испуганные глаза."
    "Se inclinó hacia el televisor, mirándome fijamente a los ojos, llenos de miedo."

# game/script3.rpy:362
translate Spanish telic_f58534ea:

    # e "Что это?! Что происходит?!"
    e "¿¡Qué es esto!? ¿¡Qué está pasando!?"

# game/script3.rpy:363
translate Spanish telic_70997299:

    # "Паника подступала. Тут слишком узко!"
    "El pánico me invadía. ¡Aquí es demasiado estrecho!"

# game/script3.rpy:365
translate Spanish telic_4bdeca94:

    # e1 "Ха-ха, да ладно! Каждый мечтает попасть в любимую игру!"
    e1 "Ja, ja, ¡vamos! Todo el mundo sueña con entrar en su juego favorito."

# game/script3.rpy:366
translate Spanish telic_31a3d14e:

    # "Внутри всё похолодело. Я нахожусь словно в узкой клетке, у которой прутья только спереди."
    "Se me heló la sangre. Estaba como en una jaula estrecha, con barrotes solo al frente."

# game/script3.rpy:367
translate Spanish telic_43a35f99:

    # "Но снизу, по бокам и сверху давящая пустота."
    "Pero abajo, a los lados y arriba, solo había un vacío opresivo."

# game/script3.rpy:368
translate Spanish telic_2732b874:

    # "Я пару раз ударила кулаком по стеклу, но звук удара громко раздался словно у меня в голове. "
    "Golpeé el cristal un par de veces con el puño, pero el sonido retumbó fuerte, como dentro de mi propia cabeza."

# game/script3.rpy:369
translate Spanish telic_22268e0b:

    # e "Бен, что я тебе сделала? Зачем это!"
    e "Ben, ¿qué te hice? ¿¡Para qué esto!?"

# game/script3.rpy:371
translate Spanish telic_508787c5:

    # e1 "Тебе не нравится? Но для меня это привычная среда. Хотя, может, вы людишки слишком большие? Да, кости вам определённо мешают."
    e1 "¿No te gusta? Pero para mí esto es un entorno familiar. Aunque, quizás ustedes, los humanillos, son demasiado grandes. Sí, los huesos definitivamente estorban."

# game/script3.rpy:373
translate Spanish telic_bddd2ca6:

    # "Мне становилось тяжело дышать. Мне страшно, слёзы покатились по щекам."
    "Me costaba respirar. Tenía miedo y las lágrimas rodaban por mis mejillas."

# game/script3.rpy:374
translate Spanish telic_950d93c2:

    # "Надо срочно что-то делать..."
    "Tengo que hacer algo, y rápido..."

# game/script3.rpy:378
translate Spanish telic_570f3d8b:

    # e "Прошу!"
    e "¡Te lo ruego!"

# game/script3.rpy:379
translate Spanish telic_f0335c58:

    # e "Выпусти меня!"
    e "¡Déjame salir!"

# game/script3.rpy:381
translate Spanish telic_ace8333d:

    # e1 "Что? Уже наскучило?"
    e1 "¿Qué? ¿Ya te aburriste?"

# game/script3.rpy:382
translate Spanish telic_96832057:

    # e "Да, прошу, отпусти!"
    e "Sí, por favor, ¡déjame ir!"

# game/script3.rpy:384
translate Spanish telic_5c04524e:

    # e1 "Ладно, как скажешь."
    e1 "Vale, como quieras."

# game/script3.rpy:385
translate Spanish telic_5b021df4:

    # "Он улыбается и щёлкает пальцами."
    "Sonríe y chasquea los dedos."

# game/script3.rpy:387
translate Spanish telic_dde35867:

    # "И после этого стены вертикального пространства стали сдвигаться!"
    "¡Y tras eso, las paredes del espacio vertical comenzaron a juntarse!"

# game/script3.rpy:389
translate Spanish telic_9b46087c:

    # "Клетка сужалась!"
    "¡La jaula se estrechaba!"

# game/script3.rpy:390
translate Spanish telic_562318f5:

    # e "Что происходит?!"
    e "¿¡Qué está pasando!?"

# game/script3.rpy:392
translate Spanish telic_486f064b:

    # e1 "Ну... Ты же хотела на волю."
    e1 "Bueno... Querías libertad, ¿no?"

# game/script3.rpy:393
translate Spanish telic_60fbba8b:

    # "Я сжалась так сильно, как только позволили кости, понимая, что меня сейчас буквально раздавит!"
    "Me encogí todo lo que mis huesos permitieron, sabiendo que literalmente me aplastarían."

# game/script3.rpy:394
translate Spanish telic_5352c950:

    # e "Бен! Прошу!"
    e "¡Ben! ¡Por favor!"

# game/script3.rpy:396
translate Spanish telic_3bed2610:

    # "Но он был непреклонен и с радостью смотрел, как от ужаса у меня в глазах прыгали блики."
    "Pero fue implacable y miraba con deleite cómo el horror hacía que los reflejos saltaran en mis ojos."

# game/script3.rpy:398
translate Spanish telic_7184d906:

    # "С каждым сокращённым сантиметром свободы давление становилось всё сильнее."
    "Con cada centímetro de espacio que se reducía, la presión aumentaba."

# game/script3.rpy:399
translate Spanish telic_726c3dc2:

    # "В глазах сначала потемнело, а после из лопнувших в глазах сосудов брызнула кровь, окрашивая всю видимую мной картину в красный."
    "Mi visión se oscureció y, luego, los vasos sanguíneos de mis ojos reventaron y la sangre salpicó, tiñendo de rojo todo lo que podía ver."

# game/script3.rpy:402
translate Spanish telic_53ebd3bf:

    # "А затем стены схлопнулись окончательно..."
    "Y entonces, las paredes se cerraron del todo..."

# game/script3.rpy:404
translate Spanish telic_cdde8804:

    # e1 "Упс..."
    e1 "Ups..."

# game/script3.rpy:412
translate Spanish telic_46b836c4:

    # "Нет, всё же я должна разбить стекло."
    "No, debo romper el cristal de todos modos."

# game/script3.rpy:413
translate Spanish telic_585104e2:

    # "Я ударила кулаком по стеклу, и удар вновь прозвучал в голове"
    "Golpeé el cristal con el puño y, de nuevo, el golpe resonó dentro de mi cabeza."

# game/script3.rpy:420
translate Spanish telic_a2ad5b4c:

    # "Я старалась не обращать внимания на ужасный гул, что становился сильнее при каждом ударе"
    "Intentaba ignorar el zumbido horrible que se intensificaba con cada golpe."

# game/script3.rpy:424
translate Spanish telic_a2ad5b4c_1:

    # "Я старалась не обращать внимания на ужасный гул, что становился сильнее при каждом ударе"
    "Intentaba ignorar el zumbido horrible que se intensificaba con cada golpe."

# game/script3.rpy:430
translate Spanish smert3_7231d22d:

    # "Я наносила удары не обращая внимания на боль, и наконец по стеклу пошла трещина, а по моей скуле покатилась тёплая капля крови."
    "Seguí golpeando sin hacer caso al dolor y, por fin, una grieta recorrió el cristal mientras una gota de sangre caliente rodaba por mi pómulo."

# game/script3.rpy:433
translate Spanish smert3_71a1c879:

    # "Предвкушая свободу, я не переставала наносить удары один за другим. И теперь звон в ушах заглушал все остальные звуки."
    "Anticipando la libertad, no dejaba de golpear, uno tras otro. Y ahora, el pitido en mis oídos ahogaba cualquier otro sonido."

# game/script3.rpy:436
translate Spanish smert3_4ba956bc:

    # "Осталось нанести последний удар и стекло разобьётся!"
    "¡Solo falta un último golpe y el cristal se hará añicos!"

# game/script3.rpy:437
translate Spanish smert3_955d1779:

    # "Я замахнулась."
    "Alcé el puño para golpear."

# game/script3.rpy:439
translate Spanish smert3_5155381d:

    # "Удар!"
    "¡Golpe!"

# game/script3.rpy:440
translate Spanish smert3_fee20578:

    # "Стекло треснуло в мелкую сетку, но не разбилось."
    "El cristal se agrietó formando una fina red, pero no se rompió."

# game/script3.rpy:441
translate Spanish smert3_b3e718f5:

    # "Однако как только стекло треснуло, я схватилась за голову закрывая глаза."
    "Sin embargo, en cuanto el cristal se agrietó, me llevé las manos a la cabeza y cerré los ojos."

# game/script3.rpy:443
translate Spanish smert3_8e784f72:

    # "Кажется, что-то треснуло в моей голове. Из ушей полилась кровь."
    "Parecía que algo se había roto dentro de mi cabeza. La sangre comenzó a brotar de mis oídos."

# game/script3.rpy:444
translate Spanish smert3_f2612c8f:

    # "И силы вытекали из меня вместе с ней."
    "Y mis fuerzas se escapaban junto con ella."

# game/script3.rpy:445
translate Spanish smert3_d4d32724:

    # "Звон плавно начал затихать..."
    "El pitido comenzó a desvanecerse lentamente..."

# game/script3.rpy:456
translate Spanish tamagochi_4231b4f9:

    # "Я наносила удары не обращая внимания на боль, я ощущала, как по моей скуле покатилась тёплая капля крови."
    "Seguí golpeando sin hacer caso al dolor, y sentí cómo una gota de sangre caliente rodaba por mi pómulo."

# game/script3.rpy:459
translate Spanish tamagochi_71a1c879:

    # "Предвкушая свободу, я не переставала наносить удары один за другим. И теперь звон в ушах заглушал все остальные звуки."
    "Anticipando la libertad, no dejaba de golpear, uno tras otro. Y ahora, el pitido en mis oídos ahogaba cualquier otro sonido."

# game/script3.rpy:461
translate Spanish tamagochi_4ba956bc:

    # "Осталось нанести последний удар и стекло разобьётся!"
    "¡Solo falta un último golpe y el cristal se hará añicos!"

# game/script3.rpy:462
translate Spanish tamagochi_955d1779:

    # "Я замахнулась."
    "Alcé el puño para golpear."

# game/script3.rpy:463
translate Spanish tamagochi_88db33ed:

    # e1 "Стой..."
    e1 "Espera..."

# game/script3.rpy:464
translate Spanish tamagochi_6396dfa3:

    # "И кулак замер в воздухе. Не знаю, как я смогла услышать его через этот звон. Но после его слов он резко прекратился."
    "Y mi puño se quedó suspendido en el aire. No sé cómo logré escucharlo a través de ese pitido, pero tras sus palabras, este se detuvo de golpe."

# game/script3.rpy:465
translate Spanish tamagochi_cc188342:

    # e1 "Ударишь ещё — умрёшь"
    e1 "Un golpe más y morirás."

# game/script3.rpy:466
translate Spanish tamagochi_516f252b:

    # "Я опешила."
    "Me quedé paralizada."

# game/script3.rpy:467
translate Spanish tamagochi_4c4c0034:

    # "Умру?"
    "¿Moriré?"

# game/script3.rpy:468
translate Spanish tamagochi_274e7669:

    # e1 "Ты правда думала, что я выпущу тебя?"
    e1 "¿De verdad creíste que te dejaría salir?"

# game/script3.rpy:469
translate Spanish tamagochi_b612d7c9:

    # e "Э-э-э..."
    e "E-eh..."

# game/script3.rpy:470
translate Spanish tamagochi_5f736f46:

    # e1 "Не думай о себе слишком многого."
    e1 "No te des tanta importancia."

# game/script3.rpy:472
translate Spanish tamagochi_a8c8ff87:

    # e1 "Но твоё стремление мне по душе. Думаю, я мог бы даже оставить тебя себе."
    e1 "Pero esa determinación tuya me agrada. Creo que incluso podría adoptarte."

# game/script3.rpy:473
translate Spanish tamagochi_871a75ec:

    # "Я смотрела на него мокрыми глазами. Всё, это точно конец... Прожить остаток жизни в узеньком телевизоре..."
    "Lo miré con los ojos llenos de lágrimas. Se acabó, esto es definitivamente el final... Pasar el resto de mi vida dentro de un televisor estrecho..."

# game/script3.rpy:475
translate Spanish tamagochi_63d00ac5:

    # e1 "Не печалься так сильно. Поверь ты будешь отличным питомцем."
    e1 "No te pongas tan triste. Créeme, serás una excelente mascota."

# game/script3.rpy:476
translate Spanish tamagochi_faeeaf0a:

    # e1 "А я хозяином. Я хорошо позабочусь о тебе."
    e1 "Y yo seré tu dueño. Cuidaré muy bien de ti."

# game/script3.rpy:478
translate Spanish tamagochi_2b977eb1:

    # e1 "Очень хорошо..."
    e1 "Muy bien..."

# game/script3.rpy:487
translate Spanish cilv_0dcb604a:

    # e "Этот парень настойчив..."
    e "Este chico es insistente..."

# game/script3.rpy:491
translate Spanish cilv_cc3db282:

    # "Он хихикает."
    "Él suelta una risita."

# game/script3.rpy:492
translate Spanish cilv_78a27d39:

    # "На секунду я уловила дружеские нотки в его голосе."
    "Por un segundo, capté un tono amistoso en su voz."

# game/script3.rpy:494
translate Spanish cilv_85b0ef43:

    # e1 "Отлично..."
    e1 "Genial..."

# game/script3.rpy:495
translate Spanish cilv_68a9340a:

    # "Он схватил меня за грудки грубо поднимая с места."
    "Me agarró de la ropa a la altura del pecho y, con brusquedad, me levantó de mi sitio."

# game/script3.rpy:497
translate Spanish cilv_5a5bdb82:

    # "Едва ли я смогла насладиться чувством безопасности, как оказалась в воздухе."
    "Apenas tuve tiempo de sentirme a salvo cuando ya estaba en el aire."

# game/script3.rpy:498
translate Spanish cilv_25e79b28:

    # "И откуда в нём столько силы?!"
    "¿De dónde saca tanta fuerza?"

# game/script3.rpy:499
translate Spanish cilv_ea56f0ed:

    # "Не успела я об этом подумать, как спина соприкоснулась с телевизором."
    "No me dio tiempo a pensarlo cuando mi espalda chocó contra el televisor."

# game/script3.rpy:500
translate Spanish cilv_a46cd8b6:

    # "Я не успеваешь даже вскрикнуть в тот момент когда тело коснулось экрана."
    "Ni siquiera me dio tiempo a gritar en el instante en que mi cuerpo tocó la pantalla."

# game/script3.rpy:501
translate Spanish cilv_659cb9df:

    # "Я ожидала что стекло разобьётся."
    "Esperaba que el cristal se hiciera añicos."

# game/script3.rpy:502
translate Spanish cilv_c97149d9:

    # "Но вместо этого..."
    "Pero en lugar de eso..."

# game/script3.rpy:508
translate Spanish cilv_a2846656:

    # "я крикнула на него не боясь потерять самообладание."
    "Le grité, sin miedo a perder el control."

# game/script3.rpy:509
translate Spanish cilv_a6964402:

    # "Он, кажется, опешил не ожидая от меня такой реакции"
    "Parece que se quedó desconcertado; no esperaba esa reacción de mi parte."

# game/script3.rpy:511
translate Spanish cilv_de3a1185:

    # "Но после он довольно хмыкнул."
    "Pero después soltó un 'mm' satisfecho."

# game/script3.rpy:512
translate Spanish cilv_9379eb96:

    # e1 "Ладно, вижу ты не фанатка острых ощущений."
    e1 "Bueno, veo que no eres fan de las emociones fuertes."

# game/script3.rpy:513
translate Spanish cilv_a9b65a41:

    # e1 "Но я принимаю твой выбор!"
    e1 "¡Pero acepto tu decisión!"

# game/script3.rpy:520
translate Spanish telic2_1b2f24a3:

    # "Я оказалась внутри телевизора!"
    "¡Terminé dentro del televisor!"

# game/script3.rpy:522
translate Spanish telic2_98095b97:

    # e "Боже!"
    e "¡Dios mío!"

# game/script3.rpy:524
translate Spanish telic2_15b19b8e:

    # "Я вижу его через стекло экрана!"
    "¡Lo veo a través del cristal de la pantalla!"

# game/script3.rpy:525
translate Spanish telic2_687838fb:

    # e1 "Ну как тебе?"
    e1 "¿Qué te parece?"

# game/script3.rpy:526
translate Spanish telic2_fe150cdf:

    # "Он наклонился к телевизору заглядывая в мои испуганные глаза."
    "Se inclinó hacia el televisor, mirándome fijamente a los ojos, llenos de miedo."

# game/script3.rpy:527
translate Spanish telic2_f58534ea:

    # e "Что это?! Что происходит?!"
    e "¿¡Qué es esto!? ¿¡Qué está pasando!?"

# game/script3.rpy:528
translate Spanish telic2_70997299:

    # "Паника подступала. Тут слишком узко!"
    "El pánico me invadía. ¡Aquí es demasiado estrecho!"

# game/script3.rpy:530
translate Spanish telic2_4bdeca94:

    # e1 "Ха-ха, да ладно! Каждый мечтает попасть в любимую игру!"
    e1 "Ja, ja, ¡vamos! Todo el mundo sueña con entrar en su juego favorito."

# game/script3.rpy:531
translate Spanish telic2_31a3d14e:

    # "Внутри всё похолодело. Я нахожусь словно в узкой клетке, у которой прутья только спереди."
    "Se me heló la sangre. Estaba como en una jaula estrecha, con barrotes solo al frente."

# game/script3.rpy:532
translate Spanish telic2_43a35f99:

    # "Но снизу, по бокам и сверху давящая пустота."
    "Pero abajo, a los lados y arriba, solo había un vacío opresivo."

# game/script3.rpy:533
translate Spanish telic2_2732b874:

    # "Я пару раз ударила кулаком по стеклу, но звук удара громко раздался словно у меня в голове. "
    "Golpeé el cristal un par de veces con el puño, pero el sonido retumbó fuerte, como dentro de mi propia cabeza."

# game/script3.rpy:534
translate Spanish telic2_22268e0b:

    # e "Бен, что я тебе сделала? Зачем это!"
    e "Ben, ¿qué te hice? ¿¡Para qué esto!?"

# game/script3.rpy:536
translate Spanish telic2_508787c5:

    # e1 "Тебе не нравится? Но для меня это привычная среда. Хотя, может, вы людишки слишком большие? Да, кости вам определённо мешают."
    e1 "¿No te gusta? Pero para mí esto es un entorno familiar. Aunque, quizás ustedes, los humanillos, son demasiado grandes. Sí, los huesos definitivamente estorban."

# game/script3.rpy:538
translate Spanish telic2_bddd2ca6:

    # "Мне становилось тяжело дышать. Мне страшно, слёзы покатились по щекам."
    "Me costaba respirar. Tenía miedo y las lágrimas rodaban por mis mejillas."

# game/script3.rpy:539
translate Spanish telic2_950d93c2:

    # "Надо срочно что-то делать..."
    "Tengo que hacer algo, y rápido..."

# game/script3.rpy:546
translate Spanish telic2_46b836c4:

    # "Нет, всё же я должна разбить стекло."
    "No, debo romper el cristal de todos modos."

# game/script3.rpy:547
translate Spanish telic2_d72d75e7:

    # "Я ударила кулаком по стеклу и удар вновь прозвучал в голове"
    "Golpeé el cristal con el puño y, de nuevo, el golpe resonó dentro de mi cabeza."

# game/script3.rpy:556
translate Spanish free_570f3d8b:

    # e "Прошу!"
    e "¡Te lo ruego!"

# game/script3.rpy:557
translate Spanish free_f0335c58:

    # e "Выпусти меня!"
    e "¡Déjame salir!"

# game/script3.rpy:559
translate Spanish free_ace8333d:

    # e1 "Что? Уже наскучило?"
    e1 "¿Qué? ¿Ya te aburriste?"

# game/script3.rpy:560
translate Spanish free_96832057:

    # e "Да, прошу, отпусти!"
    e "Sí, por favor, ¡déjame ir!"

# game/script3.rpy:562
translate Spanish free_5c04524e:

    # e1 "Ладно, как скажешь."
    e1 "Vale, como quieras."

# game/script3.rpy:563
translate Spanish free_5b021df4:

    # "Он улыбается и щёлкает пальцами."
    "Sonríe y chasquea los dedos."

# game/script3.rpy:565
translate Spanish free_dde35867:

    # "И после этого стены вертикального пространства стали сдвигаться!"
    "¡Y tras eso, las paredes del espacio vertical comenzaron a juntarse!"

# game/script3.rpy:567
translate Spanish free_9b46087c:

    # "Клетка сужалась!"
    "¡La jaula se estrechaba!"

# game/script3.rpy:568
translate Spanish free_b73b0e03:

    # e "Что происходит!"
    e "¿¡Qué está pasando!?"

# game/script3.rpy:570
translate Spanish free_486f064b:

    # e1 "Ну... Ты же хотела на волю."
    e1 "Bueno... Querías libertad, ¿no?"

# game/script3.rpy:571
translate Spanish free_60fbba8b:

    # "Я сжалась так сильно, как только позволили кости, понимая, что меня сейчас буквально раздавит!"
    "Me encogí todo lo que mis huesos permitieron, sabiendo que literalmente me aplastarían."

# game/script3.rpy:572
translate Spanish free_5352c950:

    # e "Бен! Прошу!"
    e "¡Ben! ¡Por favor!"

# game/script3.rpy:574
translate Spanish free_3bed2610:

    # "Но он был непреклонен и с радостью смотрел, как от ужаса у меня в глазах прыгали блики."
    "Pero fue implacable y miraba con deleite cómo el horror hacía que los reflejos saltaran en mis ojos."

# game/script3.rpy:576
translate Spanish free_7184d906:

    # "С каждым сокращённым сантиметром свободы давление становилось всё сильнее."
    "Con cada centímetro de espacio que se reducía, la presión aumentaba."

# game/script3.rpy:577
translate Spanish free_726c3dc2:

    # "В глазах сначала потемнело, а после из лопнувших в глазах сосудов брызнула кровь, окрашивая всю видимую мной картину в красный."
    "Mi visión se oscureció y, luego, los vasos sanguíneos de mis ojos reventaron y la sangre salpicó, tiñendo de rojo todo lo que podía ver."

# game/script3.rpy:580
translate Spanish free_53ebd3bf:

    # "А затем стены схлопнулись окончательно..."
    "Y entonces, las paredes se cerraron del todo..."

# game/script3.rpy:582
translate Spanish free_cdde8804:

    # e1 "Упс..."
    e1 "Ups..."

# game/script3.rpy:592
translate Spanish tama1_5c04524e:

    # e1 "Ладно, как скажешь."
    e1 "Vale, como quieras."

# game/script3.rpy:593
translate Spanish tama1_5b021df4:

    # "Он улыбается и щёлкает пальцами."
    "Sonríe y chasquea los dedos."

# game/script3.rpy:595
translate Spanish tama1_dde35867:

    # "И после этого стены вертикального пространства стали сдвигаться!"
    "¡Y tras eso, las paredes del espacio vertical comenzaron a juntarse!"

# game/script3.rpy:597
translate Spanish tama1_9b46087c:

    # "Клетка сужалась!"
    "¡La jaula se estrechaba!"

# game/script3.rpy:598
translate Spanish tama1_b73b0e03:

    # e "Что происходит!"
    e "¿¡Qué está pasando!?"

# game/script3.rpy:600
translate Spanish tama1_486f064b:

    # e1 "Ну... Ты же хотела на волю."
    e1 "Bueno... Querías libertad, ¿no?"

# game/script3.rpy:601
translate Spanish tama1_1c23ec9c:

    # "Я сжалась так сильно как только позволили кости, понимая что меня сейчас буквально раздавит!"
    "Me encogí todo lo que mis huesos permitieron, sabiendo que literalmente me aplastarían."

# game/script3.rpy:602
translate Spanish tama1_5352c950:

    # e "Бен! Прошу!"
    e "¡Ben! ¡Por favor!"

# game/script3.rpy:604
translate Spanish tama1_3bed2610:

    # "Но он был непреклонен и с радостью смотрел, как от ужаса у меня в глазах прыгали блики."
    "Pero fue implacable y miraba con deleite cómo el horror hacía que los reflejos saltaran en mis ojos."

# game/script3.rpy:606
translate Spanish tama1_7184d906:

    # "С каждым сокращённым сантиметром свободы давление становилось всё сильнее."
    "Con cada centímetro de espacio que se reducía, la presión aumentaba."

# game/script3.rpy:607
translate Spanish tama1_726c3dc2:

    # "В глазах сначала потемнело, а после из лопнувших в глазах сосудов брызнула кровь, окрашивая всю видимую мной картину в красный."
    "Mi visión se oscureció y, luego, los vasos sanguíneos de mis ojos reventaron y la sangre salpicó, tiñendo de rojo todo lo que podía ver."

# game/script3.rpy:610
translate Spanish tama1_53ebd3bf:

    # "А затем стены схлопнулись окончательно..."
    "Y entonces, las paredes se cerraron del todo..."

# game/script3.rpy:612
translate Spanish tama1_cdde8804:

    # e1 "Упс..."
    e1 "Ups..."

# game/script3.rpy:614
translate Spanish tama1_a20cefa7:

    # "..."
    "..."

# game/script3.rpy:615
translate Spanish tama1_709da71b:

    # "Мне холодно."
    "Tengo frío."

# game/script3.rpy:616
translate Spanish tama1_10bd6646:

    # "Тут темно..."
    "Aquí está oscuro..."

# game/script3.rpy:617
translate Spanish tama1_622efb73:

    # "Может, я просто сплю?"
    "¿Quizás solo estoy dormida?"

# game/script3.rpy:620
translate Spanish tama1_22dde288:

    # "Нет."
    "No."

# game/script3.rpy:621
translate Spanish tama1_536a19aa:

    # "Я мертва."
    "Estoy muerta."

# game/script3.rpy:622
translate Spanish tama1_b1ce5206:

    # "Не думаю что в этом есть смысл. "
    "No creo que tenga sentido."

# game/script3.rpy:623
translate Spanish tama1_ca0af82c:

    # "Я и так слишком сильно старалась."
    "Ya me he esforzado demasiado."

# game/script3.rpy:635
translate Spanish tama2_0709a071:

    # "Я пытаюсь открыть глаза, но ничего не выходит."
    "Intento abrir los ojos, pero no puedo."

# game/script3.rpy:638
translate Spanish tama2_22dde288:

    # "Нет."
    "No."

# game/script3.rpy:639
translate Spanish tama2_536a19aa:

    # "Я мертва."
    "Estoy muerta."

# game/script3.rpy:640
translate Spanish tama2_b1ce5206:

    # "Не думаю что в этом есть смысл. "
    "No creo que tenga sentido."

# game/script3.rpy:641
translate Spanish tama2_ca0af82c:

    # "Я и так слишком сильно старалась."
    "Ya me he esforzado demasiado."

# game/script3.rpy:652
translate Spanish tama3_8fc9c561:

    # "Я пытаюсь открыть глаза но ничего не выходит."
    "Intento abrir los ojos, pero no puedo."

# game/script3.rpy:655
translate Spanish tama3_22dde288:

    # "Нет."
    "No."

# game/script3.rpy:656
translate Spanish tama3_536a19aa:

    # "Я мертва."
    "Estoy muerta."

# game/script3.rpy:657
translate Spanish tama3_b1ce5206:

    # "Не думаю что в этом есть смысл. "
    "No creo que tenga sentido."

# game/script3.rpy:658
translate Spanish tama3_ca0af82c:

    # "Я и так слишком сильно старалась."
    "Ya me he esforzado demasiado."

# game/script3.rpy:667
translate Spanish tama4_33cfe7de:

    # "Нужно попробовать ещё."
    "Debo intentarlo una vez más."

# game/script3.rpy:668
translate Spanish tama4_881f3c1c:

    # "Боже, мои веки словно заклеили клеем."
    "Dios, tengo los párpados como pegados con pegamento."

# game/script3.rpy:669
translate Spanish tama4_bd084aed:

    # "Но всё же, со второй попытки, я смогла это сделать..."
    "Pero, al segundo intento, lo logré..."

# game/script3.rpy:672
translate Spanish tama4_6ee65ea0:

    # "Первым, что я увидела было небо."
    "Lo primero que vi fue el cielo."

# game/script3.rpy:673
translate Spanish tama4_384d7d6a:

    # "Погода пасмурная."
    "El día está nublado."

# game/script3.rpy:674
translate Spanish tama4_c42bf76f:

    # "Я пытаюсь подняться."
    "Intento levantarme."

# game/script3.rpy:676
translate Spanish tama4_9e593f44:

    # "Удивительно, но мне это удаётся."
    "Sorprendentemente, lo consigo."

# game/script3.rpy:677
translate Spanish tama4_2ca9fccf:

    # e "Где я?"
    e "¿Dónde estoy?"

# game/script3.rpy:678
translate Spanish tama4_3b1d593e:

    # "Я оказалась в заснеженном поле."
    "Me encontré en un campo nevado."

# game/script3.rpy:679
translate Spanish tama4_d269855a:

    # "Казалось, что оно было бесконечным. Лишь тонкая полоска деревьев вдали внушала надежду на обратное."
    "Parecía infinito. Solo una fina línea de árboles a lo lejos infundía la esperanza de lo contrario."

# game/script3.rpy:680
translate Spanish tama4_5ba8fa39:

    # "Может..."
    "Quizás..."

# game/script3.rpy:681
translate Spanish tama4_199577b7:

    # "Я смогу найти что-то вдали?"
    "¿Podré encontrar algo allí lejos?"

# game/script3.rpy:684
translate Spanish tama4_53f6faa9:

    # "Но ведь Бен убил меня?"
    "Pero Ben me mató, ¿no?"

# game/script3.rpy:685
translate Spanish tama4_04134225:

    # "Меня ведь больше не существует."
    "Ya no existo."

# game/script3.rpy:686
translate Spanish tama4_eadaac03:

    # "Пора бы уже принять конец..."
    "Ya sería hora de aceptar el final..."

# game/script3.rpy:687
translate Spanish tama4_a4845a57:

    # "А не пытаться ухватиться за то, что уже давно выскользнуло из рук."
    "Y no aferrarme a lo que hace tiempo se me escapó de las manos."

# game/script3.rpy:689
translate Spanish tama4_2f16e815:

    # "С этими мыслями я опускаюсь обратно в снег."
    "Con estos pensamientos, vuelvo a dejarme caer en la nieve."

# game/script3.rpy:690
translate Spanish tama4_6ae6fa62:

    # "Он не таял, когда руки ложились на него."
    "No se derretía cuando mis manos lo tocaban."

# game/script3.rpy:691
translate Spanish tama4_bd1009d9:

    # "И мне надо это принять."
    "Y tengo que aceptarlo."

# game/script3.rpy:704
translate Spanish silver_e7016975:

    # "Я сделала шаг вперёд."
    "Di un paso adelante."

# game/script3.rpy:705
translate Spanish silver_24d6a56c:

    # e2 "Ты не сможешь никуда прийти."
    e2 "No podrás llegar a ninguna parte."

# game/script3.rpy:706
translate Spanish silver_9bf8b351:

    # "Сзади меня раздался голос."
    "Una voz sonó detrás de mí."

# game/script3.rpy:707
translate Spanish silver_14fd19b7:

    # "Я остановилась и обернулась."
    "Me detuve y me di la vuelta."

# game/script3.rpy:709
translate Spanish silver_5a404265:

    # "Передо мной, прямо на снегу, сидел парень!"
    "Frente a mí, sentado directamente sobre la nieve, ¡había un chico!"

# game/script3.rpy:710
translate Spanish silver_a4a9d92b:

    # "Без рук и ног!"
    "¡Sin brazos ni piernas!"

# game/script3.rpy:711
translate Spanish silver_9abd6a8b:

    # "Без глаз!"
    "¡Sin ojos!"

# game/script3.rpy:712
translate Spanish silver_c3238d9a:

    # "Бен сотворил с ним это?!"
    "¿¡Ben le hizo esto!?"

# game/script3.rpy:713
translate Spanish silver_955be9d9:

    # e2 "Это место не имеет конца. Но, может, ты и сможешь что-нибудь найти."
    e2 "Este lugar no tiene fin. Pero, quizás, tú sí puedas encontrar algo."

# game/script3.rpy:714
translate Spanish silver_f31df709:

    # "Кажется, что этот парень не способен причинить мне вред. И я думаю это не только из-за отсутствия конечностей. Он не выглядит как садист или убийца."
    "Parece que este chico no es capaz de hacerme daño. Y creo que no solo por la falta de extremidades. No parece un sádico ni un asesino."

# game/script3.rpy:716
translate Spanish silver_5c5f5278:

    # e2 "Ты умерла?"
    e2 "¿Estás muerta?"

# game/script3.rpy:717
translate Spanish silver_4b586399:

    # e "Похоже на то..."
    e "Así parece..."

# game/script3.rpy:718
translate Spanish silver_571f1c7a:

    # e "Кто ты?"
    e "¿Quién eres?"

# game/script3.rpy:719
translate Spanish silver_5842a42d:

    # "Я задаю вполне логичный вопрос."
    "Hago una pregunta perfectamente lógica."

# game/script3.rpy:720
translate Spanish silver_7e2b14f9:

    # e3 "Он зовёт меня Сильвер."
    e3 "Él me llama Silver."

# game/script3.rpy:721
translate Spanish silver_2100e818:

    # e "Почему я тут оказалась? Это твоих рук дело?"
    e "¿Por qué terminé aquí? ¿Es cosa tuya?"

# game/script3.rpy:722
translate Spanish silver_15fcfab6:

    # e3 "Нет."
    e3 "No."

# game/script3.rpy:723
translate Spanish silver_641518f7:

    # e3 "Может, это Бен позволил увидеть тебе это место?"
    e3 "¿Quizás Ben te permitió ver este lugar?"

# game/script3.rpy:724
translate Spanish silver_42771ab1:

    # e "Так ты его знаешь?!"
    e "¡¿Así que lo conoces?!"

# game/script3.rpy:726
translate Spanish silver_397006df:

    # "Я разозлилась после того, как услышала имя своего мучителя из его уст."
    "Me enfurecí al escuchar el nombre de mi verdugo salir de su boca."

# game/script3.rpy:727
translate Spanish silver_f62e7e4d:

    # e "Ты его друг?! Отвечай! Так спокойно можешь называть его имя?!"
    e "¡¿Eres su amigo?! ¡Responde! ¡¿Puedes decir su nombre con tanta calma?!"

# game/script3.rpy:728
translate Spanish silver_3336975b:

    # e3 "Почему ты кричишь?"
    e3 "¿Por qué gritas?"

# game/script3.rpy:729
translate Spanish silver_6cf73641:

    # "Он явно меня испугался."
    "Claramente le di miedo."

# game/script3.rpy:730
translate Spanish silver_a4d4b2eb:

    # e "Ты заодно с этим уродом?!"
    e "¡¿Estás de su parte, con ese monstruo?!"

# game/script3.rpy:732
translate Spanish silver_1d4f09bb:

    # e3 "Он не урод..."
    e3 "No es un monstruo..."

# game/script3.rpy:733
translate Spanish silver_f90876a7:

    # "Паренёк поменялся в лице."
    "La expresión del chico cambió."

# game/script3.rpy:734
translate Spanish silver_f40e3b71:

    # e3 "Может как раз он человечнее некоторых."
    e3 "Quizás es más humano que algunos."

# game/script3.rpy:735
translate Spanish silver_99c48e90:

    # e "Защищаешь его?!"
    e "¡¿Lo defiendes?!"

# game/script3.rpy:736
translate Spanish silver_360f4116:

    # e3 "Я просто знаю, что говорю. Мы все жертвы. Ты бы тоже была бы рада убить его при возможности. И ты бы тоже была убийцей."
    e3 "Solo sé lo que digo. Todos somos víctimas. Tú también te alegrarías de matarlo si tuvieras la oportunidad. Y tú también serías una asesina."

# game/script3.rpy:738
translate Spanish silver_266c1a05:

    # "Я открыла рот что бы возразить, но мигом вспомнила про нож, который так и не послужил оружием, но был на готове."
    "Abrí la boca para replicar, pero de pronto recordé el cuchillo que nunca usé como arma, pero que llevaba preparado."

# game/script3.rpy:740
translate Spanish silver_4eb2173e:

    # e "Ладно..."
    e "Vale..."

# game/script3.rpy:741
translate Spanish silver_f03228f3:

    # "Умерив свой пыл, проговорила я."
    "Dije, controlando mi enfado."

# game/script3.rpy:742
translate Spanish silver_4ddaf913:

    # e "Как мне выбраться отсюда?"
    e "¿Cómo puedo salir de aquí?"

# game/script3.rpy:743
translate Spanish silver_8d68e002:

    # e3 "Никак. Тебя не существует."
    e3 "No hay forma. Tú no existes."

# game/script3.rpy:744
translate Spanish silver_6f4dcd7c:

    # e "О чём ты? Я ведь сейчас тут!"
    e "¿De qué hablas? ¡Pero si estoy aquí ahora mismo!"

# game/script3.rpy:745
translate Spanish silver_2ef55ee7:

    # e3 "Ты внутри картриджа. В тёмной его части, созданной им."
    e3 "Estás dentro del cartucho. En su parte oscura, creada por él."

# game/script3.rpy:746
translate Spanish silver_c71f5981:

    # "Думаю, он имел в виду Бена, но больше я не понимала, о чём он говорит."
    "Supongo que se refería a Ben, pero ya no entendía de qué hablaba."

# game/script3.rpy:747
translate Spanish silver_b1504aa9:

    # e3 "Ты больше не сможешь вернуться домой. Тебя стёрли из твоего мира. Понимаешь?"
    e3 "Ya no podrás volver a casa. Te han borrado de tu mundo. ¿Lo entiendes?"

# game/script3.rpy:748
translate Spanish silver_4e3c682a:

    # e3 "Ты когда-нибудь слышала, что мир это симуляция?"
    e3 "¿Alguna vez oíste que el mundo es una simulación?"

# game/script3.rpy:749
translate Spanish silver_30092237:

    # e3 "Это правда. И в каждом мире любое живое существо имеет свой код — его жизнь."
    e3 "Es verdad. Y en cada mundo, cualquier ser vivo tiene su propio código: su vida."

# game/script3.rpy:750
translate Spanish silver_6cdbf387:

    # e3 "Каждый твой выбор имеет значение. И когда выбираешь что-то, где-то твой выбор был иным. И это повлекло за собой другие последствия."
    e3 "Cada una de tus decisiones importa. Y cuando eliges algo, en algún otro lugar tu elección fue distinta. Y eso trajo otras consecuencias."

# game/script3.rpy:751
translate Spanish silver_eef45c27:

    # e3 "Если твой выбор привёл к тому что ты умерла, значит в этой вселенной твой код стирается."
    e3 "Si tu elección te llevó a morir, significa que en este universo tu código se borra."

# game/script3.rpy:752
translate Spanish silver_0070980e:

    # "Мир симуляция? Что за чушь? Может, я ещё жива и у меня предсмертный бред?!"
    "¿El mundo es una simulación? ¿Qué tontería es esa? ¡¿Quizás sigo viva y estoy delirando a las puertas de la muerte?!"

# game/script3.rpy:754
translate Spanish silver_fbefedbc:

    # e3 "Теперь ты оказалась тут."
    e3 "Ahora has terminado aquí."

# game/script3.rpy:755
translate Spanish silver_d744e40c:

    # e "И что мне делать?"
    e "¿Y qué debo hacer?"

# game/script3.rpy:756
translate Spanish silver_473667d6:

    # e3 "Ничего."
    e3 "Nada."

# game/script3.rpy:758
translate Spanish silver_997106af:

    # "Я поникла, а мой взгляд стал пустым."
    "Mi ánimo decayó y mi mirada se perdió en la nada."

# game/script3.rpy:759
translate Spanish silver_1abf8f6d:

    # "Мне хотелось разрыдаться. Взвыть словно раненое животное, что предчувствует собственную кончину."
    "Quería romper a llorar. Aullar como un animal herido que presiente su propio fin."

# game/script3.rpy:761
translate Spanish silver_c57eccde:

    # "Но слёз не было."
    "Pero no salían lágrimas."

# game/script3.rpy:763
translate Spanish silver_99843fef:

    # e3 "Я знаю, тебе страшно."
    e3 "Sé que tienes miedo."

# game/script3.rpy:764
translate Spanish silver_696f4922:

    # e3 "Я и сам долго находился в том же положении, что и ты."
    e3 "Yo también estuve mucho tiempo en la misma situación que tú."

# game/script3.rpy:765
translate Spanish silver_3044fb20:

    # e3 "Мне было так холодно. И это холод, к которому невозможно привыкнуть, но и умереть ты не можешь."
    e3 "Sentía mucho frío. Y es un frío al que es imposible acostumbrarse, pero tampoco puedes morir."

# game/script3.rpy:767
translate Spanish silver_91761b88:

    # e3 "Но позже..."
    e3 "Pero luego..."

# game/script3.rpy:768
translate Spanish silver_52f707e3:

    # e3 "Бен спас меня."
    e3 "Ben me salvó."

# game/script3.rpy:769
translate Spanish silver_4cad3fb2:

    # e3 "Привёл сюда. Обещал, что сможет перенести в открытую сеть. Даже сказал, что поможет вернуть конечности по своему возвращению!"
    e3 "Me trajo aquí. Prometió que podría transferirme a la red abierta. ¡Incluso dijo que me ayudaría a recuperar las extremidades cuando regresara!"

# game/script3.rpy:771
translate Spanish silver_d59d9b69:

    # "Сильвер, кажется, впервые улыбнулся, вспоминая про моего убийцу."
    "Silver sonrió por primera vez, al parecer, al recordar a mi asesino."

# game/script3.rpy:772
translate Spanish silver_e290e57e:

    # "Бен как то его спас, этот жестокий коротышка? От чего?"
    "¿Ben lo salvó de alguna manera, ese cruel enano? ¿De qué?"

# game/script3.rpy:774
translate Spanish silver_8e8cec0c:

    # e3 "Пожалуйста, не злись на него."
    e3 "Por favor, no te enfades con él."

# game/script3.rpy:775
translate Spanish silver_27334dae:

    # e3 "Он не плохой, правда."
    e3 "No es malo, de verdad."

# game/script3.rpy:776
translate Spanish silver_ab23ecff:

    # e3 "Его тоже обманом запечатали в картридже. И ему не повезло больше нас."
    e3 "A él también lo sellaron en el cartucho con engaños. Y tuvo menos suerte que nosotros."

# game/script3.rpy:777
translate Spanish silver_6aebb27e:

    # e3 "Единственное, что теперь пожирает его изнутри — жажда мести."
    e3 "Lo único que ahora lo consume por dentro es la sed de venganza."

# game/script3.rpy:778
translate Spanish silver_d39e32ae:

    # e3 "Он лгал если говорил, что в нём нет чувств."
    e3 "Mintió si dijo que no tiene sentimientos."

# game/script3.rpy:779
translate Spanish silver_eebfe4e7:

    # e3 "Он ощущает то же вечное опустошение, что и ты."
    e3 "Siente el mismo vacío eterno que tú."

# game/script3.rpy:781
translate Spanish silver_a5ad3daf:

    # e "Но зачем он убил меня?! Я никак не была причастна к его смерти!"
    e "¡¿Pero por qué me mató?! ¡Yo no tuve nada que ver con su muerte!"

# game/script3.rpy:783
translate Spanish silver_130d8058:

    # e3 "Он потерял веру в людей. Но сострадание и милосердие ему по-прежнему не чужды. Хоть он и считает их пороком."
    e3 "Perdió la fe en la humanidad. Pero la compasión y la misericordia aún no le son ajenas. Aunque las considere un defecto."

# game/script3.rpy:784
translate Spanish silver_2993ccac:

    # e3 "Твоей вины нет ни в чём. Но, возможно, ты просто принимала не правильные решения."
    e3 "No tienes la culpa de nada. Pero, quizás, simplemente tomaste decisiones incorrectas."

# game/script3.rpy:785
translate Spanish silver_f2d8b550:

    # "Слова Сильвера успокаивали меня. Он так много знает, да и сам парень располагает к себе."
    "Las palabras de Silver me calmaban. Sabe tanto, y el chico en sí inspira confianza."

# game/script3.rpy:793
translate Spanish silver13_291db96f:

    # "Расскажи мне о нём больше."
    "Cuéntame más sobre él."

# game/script3.rpy:794
translate Spanish silver13_3c175388:

    # e3 "Бен был человеком. Обычным парнем, что едва достиг возраста, когда жизнь ощущается по-другому."
    e3 "Ben era humano. Un chico común que apenas había llegado a la edad en que la vida se siente de otra manera."

# game/script3.rpy:795
translate Spanish silver13_6f2a3a02:

    # e3 "Но связался не с теми... Люди в вашем мире жестоки."
    e3 "Pero se juntó con la gente equivocada... La gente de su mundo es cruel."

# game/script3.rpy:796
translate Spanish silver13_a9916f59:

    # e3 "Они убили его на благо культа Детей луны."
    e3 "Lo asesinaron para beneficio del culto de los Hijos de la Luna."

# game/script3.rpy:797
translate Spanish silver13_9e31dd2d:

    # "Я внимательно слушала Сильвера, моя злость утихла и теперь упоминания Бена не причиняли мне боль."
    "Escuchaba atentamente a Silver, mi ira se había calmado y ahora mencionar a Ben ya no me dolía."

# game/script3.rpy:799
translate Spanish silver13_6645379a:

    # e3 "До тебя жертвой был другой парень, благодаря ему Бен выбрался в интернет."
    e3 "Antes que tú, la víctima fue otro chico; gracias a él, Ben logró salir a internet."

# game/script3.rpy:800
translate Spanish silver13_1e8d97ff:

    # e3 "Но он всё ещё зависим от картриджа или от другого устройства, если картридж не используется. Если не будет электричества, что питает устройство от которого зависим Бен, то он теряет свою независимость от вашего мира."
    e3 "Pero sigue dependiendo del cartucho o de otro dispositivo si el cartucho no se usa. Si no hay electricidad que alimente el dispositivo del que depende Ben, pierde su independencia de su mundo (el de ustedes)."

# game/script3.rpy:802
translate Spanish silver13_2862f6aa:

    # e3 "Даже находясь в интернете Бен зависим от картриджа. Он должен находиться в сохранности."
    e3 "Incluso estando en internet, Ben depende del cartucho. Debe permanecer a salvo."

# game/script3.rpy:803
translate Spanish silver13_cab7ab2c:

    # e3 "Но ему наскучили похождения по интернету, он захотел выйти наружу."
    e3 "Pero se aburrió de deambular por internet, quiso salir al exterior."

# game/script3.rpy:805
translate Spanish silver13_b1e402c8:

    # e3 "Глупо конечно было доверять свою жизнь тому парню, ведь он просто выкинул картридж на улицу. Безумно безрассудный поступок со стороны Бена."
    e3 "Por supuesto, fue una estupidez confiar su vida a ese chico, ya que simplemente tiró el cartucho a la calle. Un acto insensato y temerario por parte de Ben."

# game/script3.rpy:807
translate Spanish silver13_b648c027:

    # "Я не понимала о ком говорит Сильвер, но мои вопросы определённо будут тут лишними."
    "No entendía de quién hablaba Silver, pero mis preguntas definitivamente sobrarían aquí."

# game/script3.rpy:809
translate Spanish silver13_0f8167f4:

    # e3 "Но он хотел посмотреть, как изменился мир и люди."
    e3 "Pero quería ver cómo habían cambiado el mundo y las personas."

# game/script3.rpy:810
translate Spanish silver13_7dab1ae9:

    # e "Понятно."
    e "Entiendo."

# game/script3.rpy:811
translate Spanish silver13_8aae061b:

    # e "Но он всё ещё убийца."
    e "Pero sigue siendo un asesino."

# game/script3.rpy:812
translate Spanish silver13_7529d6d8:

    # e3 "Да ты права. И я не могу заставить тебя простить его, ведь и он не может отпустить боль."
    e3 "Sí, tienes razón. Y no puedo obligarte a perdonarlo, ya que él tampoco puede dejar ir el dolor."

# game/script3.rpy:813
translate Spanish silver13_b1270dd8:

    # e3 "Но если ты сможешь отпустить его поступок, то тебе самой будет легче."
    e3 "Pero si logras dejar ir su acto, tú misma te sentirás mejor."

# game/script3.rpy:823
translate Spanish silver15_8ae9b900:

    # e3 "Я понимаю, это тяжело."
    e3 "Entiendo que es difícil."

# game/script3.rpy:825
translate Spanish silver15_9f15d849:

    # e3 "Но ты уже куда сильнее его, раз пошла на это."
    e3 "Pero ya eres mucho más fuerte que él, si has sido capaz de dar este paso."

# game/script3.rpy:827
translate Spanish silver15_8f468b2f:

    # e3 "Знаешь, я тут уже достаточно долго, но уже привык ждать. И если хочешь..."
    e3 "Sabes, llevo aquí bastante tiempo, pero ya me acostumbré a esperar. Y si quieres..."

# game/script3.rpy:828
translate Spanish silver15_d7139297:

    # e3 "Ты можешь остаться со мной. Тебе больше ничего не угрожает. И ты такая же несчастная душа, как и другие."
    e3 "Puedes quedarte conmigo. Ya nada te amenaza. Y eres un alma tan desdichada como las demás."

# game/script3.rpy:831
translate Spanish silver15_f8b88a20:

    # e "Да."
    e "Sí."

# game/script3.rpy:832
translate Spanish silver15_c5b30918:

    # e "Я хочу."
    e "Quiero hacerlo."

# game/script3.rpy:833
translate Spanish silver15_efb2ba0e:

    # "Мне становиться спокойно рядом с Сильвером. Он действительно не плохой."
    "Me siento tranquila junto a Silver. Realmente no es mala persona."

# game/script3.rpy:834
translate Spanish silver15_b8ed498c:

    # "И его слова заставили меня задуматься о том, действительно ли Бен так плох."
    "Y sus palabras me hicieron pensar si Ben es realmente tan malo."

# game/script3.rpy:836
translate Spanish silver15_7962be37:

    # "Я опускаюсь рядом с Сильвером."
    "Me siento al lado de Silver."

# game/script3.rpy:837
translate Spanish silver15_d1e2108c:

    # "Мне жаль его."
    "Lo siento por él."

# game/script3.rpy:838
translate Spanish silver15_56d2faeb:

    # "А ему, кажется, жаль меня."
    "Y a él, al parecer, le doy lástima."

# game/script3.rpy:839
translate Spanish silver15_b63ea87c:

    # "Стыдно это признавать, но ещё мне жаль Бена."
    "Me da vergüenza admitirlo, pero también siento lástima por Ben."

# game/script3.rpy:840
translate Spanish silver15_07d55d5c:

    # e "Тут холодно."
    e "Aquí hace frío."

# game/script3.rpy:841
translate Spanish silver15_96e8ac2c:

    # e3 "Нет. Тебе так только кажется."
    e3 "No. Solo te lo parece."

# game/script3.rpy:842
translate Spanish silver15_328a7fda:

    # e3 "Душа ещё не забыла это чувство, и теперь, глядя на снег, тебе становится холодно."
    e3 "El alma aún no ha olvidado esa sensación, y ahora, al mirar la nieve, sientes frío."

# game/script3.rpy:843
translate Spanish silver15_deb72903:

    # e "Думаю так и есть."
    e "Creo que sí."

# game/script3.rpy:844
translate Spanish silver15_c5c3e573:

    # "Я уже не ощущаю того страха."
    "Ya no siento ese miedo."

# game/script3.rpy:845
translate Spanish silver15_737ccea6:

    # "Мне больше не хочется плакать."
    "Ya no tengo ganas de llorar."

# game/script3.rpy:848
translate Spanish silver15_1916a5f9:

    # "Я чувствую покой."
    "Siento paz."

# game/script3.rpy:856
translate Spanish silver15_22dde288:

    # "Нет."
    "No."

# game/script3.rpy:857
translate Spanish silver15_0e7a63be:

    # "Извини, мне надо идти."
    "Lo siento, debo irme."

# game/script3.rpy:858
translate Spanish silver15_20a8a3cf:

    # "Спасибо за всё."
    "Gracias por todo."

# game/script3.rpy:860
translate Spanish silver15_be37a0ec:

    # e3 "Как скажешь..."
    e3 "Como quieras..."

# game/script3.rpy:861
translate Spanish silver15_d3a747d4:

    # e3 "Прощай."
    e3 "Adiós."

# game/script3.rpy:863
translate Spanish silver15_2b8150a8:

    # "Я разворачиваюсь и гляжу вперёд."
    "Me doy la vuelta y miro hacia adelante."

# game/script3.rpy:864
translate Spanish silver15_dfb88423:

    # "Что-то влечёт меня туда, может всё же там что-то есть..."
    "Algo me atrae hacia allí, quizás después de todo haya algo..."

# game/script3.rpy:873
translate Spanish silver12_7ec73570:

    # e3 "Я рад."
    e3 "Me alegro."

# game/script3.rpy:874
translate Spanish silver12_ee1be960:

    # e3 "Ты очень сильная, не каждый может так легко смириться со смертью и отпустить вину своего мучителя."
    e3 "Eres muy fuerte, no cualquiera puede aceptar la muerte con tanta facilidad y dejar ir la culpa de su verdugo."

# game/script3.rpy:876
translate Spanish silver12_8f468b2f:

    # e3 "Знаешь, я тут уже достаточно долго, но уже привык ждать. И если хочешь..."
    e3 "Sabes, llevo aquí bastante tiempo, pero ya me acostumbré a esperar. Y si quieres..."

# game/script3.rpy:877
translate Spanish silver12_d7139297:

    # e3 "Ты можешь остаться со мной. Тебе больше ничего не угрожает. И ты такая же несчастная душа, как и другие."
    e3 "Puedes quedarte conmigo. Ya nada te amenaza. Y eres un alma tan desdichada como las demás."

# game/script3.rpy:880
translate Spanish silver12_f8b88a20:

    # e "Да."
    e "Sí."

# game/script3.rpy:881
translate Spanish silver12_c5b30918:

    # e "Я хочу."
    e "Quiero hacerlo."

# game/script3.rpy:882
translate Spanish silver12_efb2ba0e:

    # "Мне становиться спокойно рядом с Сильвером. Он действительно не плохой."
    "Me siento tranquila junto a Silver. Realmente no es mala persona."

# game/script3.rpy:883
translate Spanish silver12_b8ed498c:

    # "И его слова заставили меня задуматься о том, действительно ли Бен так плох."
    "Y sus palabras me hicieron pensar si Ben es realmente tan malo."

# game/script3.rpy:885
translate Spanish silver12_7962be37:

    # "Я опускаюсь рядом с Сильвером."
    "Me siento al lado de Silver."

# game/script3.rpy:886
translate Spanish silver12_d1e2108c:

    # "Мне жаль его."
    "Lo siento por él."

# game/script3.rpy:887
translate Spanish silver12_56d2faeb:

    # "А ему, кажется, жаль меня."
    "Y a él, al parecer, le doy lástima."

# game/script3.rpy:888
translate Spanish silver12_b63ea87c:

    # "Стыдно это признавать, но ещё мне жаль Бена."
    "Me da vergüenza admitirlo, pero también siento lástima por Ben."

# game/script3.rpy:889
translate Spanish silver12_07d55d5c:

    # e "Тут холодно."
    e "Aquí hace frío."

# game/script3.rpy:890
translate Spanish silver12_96e8ac2c:

    # e3 "Нет. Тебе так только кажется."
    e3 "No. Solo te lo parece."

# game/script3.rpy:891
translate Spanish silver12_328a7fda:

    # e3 "Душа ещё не забыла это чувство, и теперь, глядя на снег, тебе становится холодно."
    e3 "El alma aún no ha olvidado esa sensación, y ahora, al mirar la nieve, sientes frío."

# game/script3.rpy:892
translate Spanish silver12_deb72903:

    # e "Думаю так и есть."
    e "Creo que sí."

# game/script3.rpy:893
translate Spanish silver12_c5c3e573:

    # "Я уже не ощущаю того страха."
    "Ya no siento ese miedo."

# game/script3.rpy:894
translate Spanish silver12_737ccea6:

    # "Мне больше не хочется плакать."
    "Ya no tengo ganas de llorar."

# game/script3.rpy:897
translate Spanish silver12_1916a5f9:

    # "Я чувствую покой."
    "Siento paz."

# game/script3.rpy:905
translate Spanish silver12_58f16a49:

    # e "Нет."
    e "No."

# game/script3.rpy:906
translate Spanish silver12_d947125a:

    # e "Извини, мне надо идти."
    e "Lo siento, debo irme."

# game/script3.rpy:907
translate Spanish silver12_50006682:

    # e "Спасибо за всё."
    e "Gracias por todo."

# game/script3.rpy:909
translate Spanish silver12_be37a0ec:

    # e3 "Как скажешь..."
    e3 "Como quieras..."

# game/script3.rpy:910
translate Spanish silver12_d3a747d4:

    # e3 "Прощай."
    e3 "Adiós."

# game/script3.rpy:912
translate Spanish silver12_2b8150a8:

    # "Я разворачиваюсь и гляжу вперёд."
    "Me doy la vuelta y miro hacia adelante."

# game/script3.rpy:913
translate Spanish silver12_cd14b5cf:

    # "Что-то влечёт меня туда, может всё же там что то есть..."
    "Algo me atrae hacia allí, quizás después de todo haya algo..."

# game/script3.rpy:922
translate Spanish silver14_d7a06f47:

    # e3 "Что же..."
    e3 "Bueno..."

# game/script3.rpy:923
translate Spanish silver14_d7aea038:

    # e3 "Я не в праве указывать тебе."
    e3 "No tengo derecho a decirte qué hacer."

# game/script3.rpy:924
translate Spanish silver14_5d160e07:

    # e3 " Но знаешь, я тут уже достаточно долго, и уже привык ждать. И если хочешь..."
    e3 "Pero sabes, llevo aquí bastante tiempo y ya me acostumbré a esperar. Y si quieres..."

# game/script3.rpy:926
translate Spanish silver14_58f16a49:

    # e "Нет."
    e "No."

# game/script3.rpy:927
translate Spanish silver14_2bb46a54:

    # "Резко отрезаю я зная, что он хочет мне предложить."
    "Corto en seco, sabiendo lo que quiere ofrecerme."

# game/script3.rpy:929
translate Spanish silver14_be37a0ec:

    # e3 "Как скажешь..."
    e3 "Como quieras..."

# game/script3.rpy:930
translate Spanish silver14_d3a747d4:

    # e3 "Прощай."
    e3 "Adiós."

# game/script3.rpy:932
translate Spanish silver14_2b8150a8:

    # "Я разворачиваюсь и гляжу вперёд."
    "Me doy la vuelta y miro hacia adelante."

# game/script3.rpy:933
translate Spanish silver14_dfb88423:

    # "Что-то влечёт меня туда, может всё же там что-то есть..."
    "Algo me atrae hacia allí, quizás después de todo haya algo..."

# game/script3.rpy:943
translate Spanish silver17_8c3cb9b3:

    # e "Расскажи мне о себе."
    e "Cuéntame sobre ti."

# game/script3.rpy:944
translate Spanish silver17_047d5e1c:

    # e3 "Ох. О себе?"
    e3 "Oh. ¿Sobre mí?"

# game/script3.rpy:946
translate Spanish silver17_b0b4669a:

    # e3 "Ну-у, я так-то не помню кто я, честно, не знаю даже своего настоящего имени."
    e3 "Bueeno, la verdad es que no recuerdo quién soy, ni siquiera sé mi nombre real."

# game/script3.rpy:947
translate Spanish silver17_97a2a6e4:

    # e3 "Я лишь знаю, что существовал в старом картридже Pokemon Silver."
    e3 "Solo sé que existía en un viejo cartucho de Pokémon Silver."

# game/script3.rpy:948
translate Spanish silver17_b48887de:

    # e3 "Я не знал, что был мёртв, и это куда хуже, чем осознать смерть даже до её прихода."
    e3 "No sabía que estaba muerto, y eso es mucho peor que ser consciente de la muerte incluso antes de que llegue."

# game/script3.rpy:949
translate Spanish silver17_9cafaff0:

    # e3 "Ты просто блуждаешь по пустым коридорам, никого не находишь, а после понимаешь, что находишься в темноте, а твои похождения не больше чем собственные мысли."
    e3 "Solo deambulas por pasillos vacíos, no encuentras a nadie, y luego te das cuenta de que estás en la oscuridad, y que tus andanzas no son más que tus propios pensamientos."

# game/script3.rpy:952
translate Spanish silver17_09f5ac9f:

    # e3 "А Бен нашёл меня через историю одного парня на 4chan."
    e3 "Y Ben me encontró a través de la historia de un chico en 4chan."

# game/script3.rpy:953
translate Spanish silver17_2718d896:

    # e3 "Никто из нас не знал моего имени, поэтому он назвал меня Лост Сильвер, и знаешь..."
    e3 "Ninguno de los dos sabía mi nombre, así que me llamó Lost Silver, y sabes..."

# game/script3.rpy:954
translate Spanish silver17_69c89536:

    # e3 "Мне нравится это имя."
    e3 "Me gusta ese nombre."

# game/script3.rpy:956
translate Spanish silver17_6c495ef8:

    # e3 "Я не знаю, что бы со мной было если бы не он."
    e3 "No sé qué habría sido de mí si no hubiera sido por él."

# game/script3.rpy:957
translate Spanish silver17_1d86319c:

    # e3 "Возможно, я бы так и сидел в темноте и холоде, ожидая смерти, которая никогда не наступит."
    e3 "Quizás habría seguido sentado en la oscuridad y el frío, esperando una muerte que nunca llegaría."

# game/script3.rpy:958
translate Spanish silver17_b959561d:

    # "Я долго переваривала сказанное им. Но одно уловила сразу:"
    "Tardé en procesar sus palabras. Pero una cosa capté de inmediato:"

# game/script3.rpy:959
translate Spanish silver17_111569ef:

    # e "Ты персонаж... Персонаж игры!"
    e "Eres un personaje... ¡Un personaje de videojuego!"

# game/script3.rpy:960
translate Spanish silver17_f661a5f3:

    # e "Он смотрит на меня словно не понимая причину моего удивления."
    e "Me mira como si no entendiera la razón de mi asombro."

# game/script3.rpy:961
translate Spanish silver17_066d9ec8:

    # e3 "Да, ты права."
    e3 "Sí, tienes razón."

# game/script3.rpy:962
translate Spanish silver17_d5cf8d4d:

    # e "Но как... Как ты можешь иметь самосознание, ты ведь..."
    e "Pero cómo... ¿Cómo puedes tener conciencia de ti mismo, si tú solo eres..."

# game/script3.rpy:963
translate Spanish silver17_4d1eb3fe:

    # e "Набор пикселей! Ты создан нами!"
    e "¡Un montón de píxeles! ¡Fuiste creado por nosotros!"

# game/script3.rpy:965
translate Spanish silver17_0d5962ea:

    # e3 "Так же, как и вы созданы тем, кого называете Богом."
    e3 "Al igual que ustedes fueron creados por aquel a quien llaman Dios."

# game/script3.rpy:966
translate Spanish silver17_88480f4c:

    # e3 "Вы, люди, стали приписывать себе слишком много заслуг. И это губит вас."
    e3 "Ustedes, los humanos, se han atribuido demasiados méritos. Y eso los está destruyendo."

# game/script3.rpy:967
translate Spanish silver17_053871b9:

    # "Я задумалась."
    "Reflexioné."

# game/script3.rpy:968
translate Spanish silver17_4c4bbb3a:

    # "Он легко парировал всё, что я говорила в оборону."
    "Refutó con facilidad todo lo que dije para defenderme."

# game/script3.rpy:969
translate Spanish silver17_848a8dbc:

    # "Но всё, что меня окружало, говорило, что мои знания о мире были обманом."
    "Pero todo lo que me rodeaba indicaba que mi conocimiento del mundo era una mentira."

# game/script3.rpy:971
translate Spanish silver17_89e5be71:

    # e "Ясно."
    e "Entiendo."

# game/script3.rpy:972
translate Spanish silver17_61c23575:

    # e "Но мне всё еще тяжело понять, как ты с таким трепетом относишься к нему."
    e "Pero aún me cuesta entender cómo lo tratas con tanta devoción."

# game/script3.rpy:973
translate Spanish silver17_2cdf201f:

    # e "Ведь он всё ещё убийца."
    e "Después de todo, sigue siendo un asesino."

# game/script3.rpy:974
translate Spanish silver17_7529d6d8:

    # e3 "Да ты права. И я не могу заставить тебя простить его, ведь и он не может отпустить боль."
    e3 "Sí, tienes razón. Y no puedo obligarte a perdonarlo, ya que él tampoco puede dejar ir el dolor."

# game/script3.rpy:975
translate Spanish silver17_b1270dd8:

    # e3 "Но если ты сможешь отпустить его поступок, то тебе самой будет легче."
    e3 "Pero si logras dejar ir su acto, tú misma te sentirás mejor."

# game/script3.rpy:990
translate Spanish igra_8d2a20ad:

    # "Он отстранился."
    "Se apartó."

# game/script3.rpy:991
translate Spanish igra_408adb3a:

    # "Я же уставилась на него ожидая следующих покушений на мои личные границы."
    "Me quedé mirándolo, esperando que volviera a cruzar mis límites personales."

# game/script3.rpy:992
translate Spanish igra_e5d0d7aa:

    # "Но он молчал, так же обдумывая следующие действия и слова."
    "Pero guardó silencio, mientras también sopesaba sus siguientes acciones y palabras."

# game/script3.rpy:995
translate Spanish igra_792fd3ea:

    # e1 "А как насчёт игры?"
    e1 "¿Y qué hay del juego?"

# game/script3.rpy:996
translate Spanish igra_7cb4f436:

    # "Я не успела и ответить, как он продолжил:"
    "No me dio tiempo ni a responder cuando continuó:"

# game/script3.rpy:997
translate Spanish igra_9ab8c3dd:

    # e1 "Да, я думаю это хорошая идея! Я буду задавать вопросы, а ты — отвечать."
    e1 "Sí, ¡creo que es una buena idea! Yo haré las preguntas y tú responderás."

# game/script3.rpy:998
translate Spanish igra_f7f70af1:

    # e1 "К тому же, в конце тебя будет ждать награда."
    e1 "Además, al final te espera una recompensa."

# game/script3.rpy:999
translate Spanish igra_9b15e8f7:

    # e1 "Что думаешь?"
    e1 "¿Qué te parece?"

# game/script3.rpy:1004
translate Spanish igra_164cea05:

    # e1 "Я знал, что ты согласишься!"
    e1 "¡Sabía que aceptarías!"

# game/script3.rpy:1005
translate Spanish igra_63e58443:

    # e1 "Хорошо."
    e1 "Está bien."

# game/script3.rpy:1006
translate Spanish igra_596b0f05:

    # e1 "Я вижу ты фанатка Зельды."
    e1 "Veo que eres fan de Zelda."

# game/script3.rpy:1007
translate Spanish igra_7c8c3fcd:

    # e1 "Думаю понятно, что и мне нравится эта игра."
    e1 "Supongo que es obvio que a mí también me gusta este juego."

# game/script3.rpy:1008
translate Spanish igra_cda13c24:

    # e1 "В таком случае вначале я буду задавать тебе вопросы по игре. "
    e1 "En ese caso, al principio te haré preguntas sobre el juego."

# game/script3.rpy:1009
translate Spanish igra_3f14a411:

    # e "Ладно."
    e "De acuerdo."

# game/script3.rpy:1010
translate Spanish igra_55211302:

    # e1 "Отлично! Вопросы в начале не будут сложными, всего будет две игры и пять раундов:"
    e1 "¡Genial! Las preguntas iniciales no serán difíciles. Habrá dos juegos y cinco rondas en total:"

# game/script3.rpy:1011
translate Spanish igra_d29be26e:

    # e1 "Два в первой игре и три во второй. В каждом раунде первой игры три вопроса!"
    e1 "Dos en el primer juego y tres en el segundo. ¡En cada ronda del primer juego habrá tres preguntas!"

# game/script3.rpy:1014
translate Spanish igra_5b57722e:

    # e1 "После каждой игры тебя будет ждать награда, но если ты хотя бы в одном вопросе или раунде ошибёшься, то игра для тебя закончится."
    e1 "Después de cada juego te esperará una recompensa, pero si te equivocas en al menos una pregunta o ronda, el juego terminará para ti."

# game/script3.rpy:1016
translate Spanish igra_258da5ca:

    # "Он как то не по-доброму улыбнулся."
    "Sonrió de un modo poco amistoso."

# game/script3.rpy:1023
translate Spanish otkaz_786d7888:

    # e "Нет, я всё же откажусь. Извини."
    e "No, igual voy a rechazarlo. Lo siento."

# game/script3.rpy:1026
translate Spanish otkaz_b77fe2ba:

    # "Он расстроился, но настаивать, на удивление, не стал."
    "Se mostró decepcionado, pero, sorprendentemente, no insistió."

# game/script3.rpy:1031
translate Spanish otkaz_a3ae09d5:

    # e1 "Хорошо, но мне всё еще скучно"
    e1 "Bueno, pero igual me aburro."

# game/script3.rpy:1033
translate Spanish otkaz_4be29c52:

    # "он сел рядом со мной и я сразу напряглась."
    "Se sentó a mi lado y de inmediato me tensé."

# game/script3.rpy:1034
translate Spanish otkaz_5cbc7981:

    # e "Мы можем поговорить... Ну знаешь обсудить..."
    e "Podemos hablar... Ya sabes, conversar..."

# game/script3.rpy:1036
translate Spanish otkaz_32a65d76:

    # e1 "Поговорить?"
    e1 "¿Hablar?"

# game/script3.rpy:1037
translate Spanish otkaz_3d40eb7a:

    # "Он посмотрел на меня как на дуру."
    "Me miró como a una tonta."

# game/script3.rpy:1039
translate Spanish otkaz_3dcf95d6:

    # e1 "А что..."
    e1 "¿Y qué...?"

# game/script3.rpy:1040
translate Spanish otkaz_20000994:

    # e1 "Я кажусь тебе интересным собеседником?"
    e1 "¿Te parezco un interlocutor interesante?"

# game/script3.rpy:1041
translate Spanish otkaz_a66ffab8:

    # e "Э-э-э, да... Конeчно."
    e "Eh... sí... Claro."

# game/script3.rpy:1042
translate Spanish otkaz_dd91b714:

    # "Я врала, мне просто хотелось заговорить его, может он смилуется и покинет меня?"
    "Mentía. Solo quería mantenerlo hablando, quizás se apiadara y me dejara en paz."

# game/script3.rpy:1043
translate Spanish otkaz_d9317a94:

    # "Пока что он не кажется мне опасным убийцей."
    "Por ahora no me parece un asesino peligroso."

# game/script3.rpy:1044
translate Spanish otkaz_405a918b:

    # e "Знаешь, я эм... Хотела бы попросить тебя. Ну-у..."
    e "Sabes, eh... Quería pedirte algo. Bueeno..."

# game/script3.rpy:1046
translate Spanish otkaz_47441d72:

    # e1 "Хотя, наверное, тебе просто интересен я."
    e1 "Aunque, supongo, solo te intereso yo."

# game/script3.rpy:1048
translate Spanish otkaz_1301a0fa:

    # e1 "Ну конечно."
    e1 "Claro que sí."

# game/script3.rpy:1049
translate Spanish otkaz_196d9363:

    # "Он не даёт мне и слова сказать!"
    "¡Ni siquiera me deja terminar una frase!"

# game/script3.rpy:1050
translate Spanish otkaz_19ecb29b:

    # e1 "И я с радостью могу ответить на твои вопросы."
    e1 "Y con gusto puedo responder a tus preguntas."

# game/script3.rpy:1051
translate Spanish otkaz_a7e126de:

    # e "Я эм..."
    e "Yo, eh..."

# game/script3.rpy:1053
translate Spanish otkaz_c37cc6ae:

    # e1 "Но ты не спеши. Я понимаю сразу всё из головы вылетело."
    e1 "Pero no te apures. Entiendo que se te haya ido todo de la cabeza."

# game/script3.rpy:1054
translate Spanish otkaz_6b264119:

    # "Да что он вообще о себе думает?"
    "¿Pero quién se cree que es?"

# game/script3.rpy:1055
translate Spanish otkaz_92204a62:

    # "Но мне остаётся только принять его идею, ведь не известно что он предложит вместо пустой болтовни."
    "Pero no me queda más que aceptar su idea, ya que no sé qué podría ofrecer en lugar de una charla vacía."

# game/script3.rpy:1056
translate Spanish otkaz_54fd1a33:

    # "И опять я прокололась."
    "Y otra vez metí la pata."

# game/script3.rpy:1057
translate Spanish otkaz_e041f65a:

    # "Он как будто бы читает все мои желания и будущие действия!"
    "¡Es como si leyera todos mis deseos y mis próximos movimientos!"

# game/script3.rpy:1058
translate Spanish otkaz_99fd2d54:

    # "И что же теперь ему задать?"
    "¿Y qué le pregunto ahora?"

# game/script3.rpy:1068
translate Spanish otkaz1_6a939256:

    # "Он помрачнел."
    "Su expresión se ensombreció."

# game/script3.rpy:1069
translate Spanish otkaz1_08ca940b:

    # "Я задела не самую приятную для него тему."
    "Había tocado un tema que no le resultaba precisamente agradable."

# game/script3.rpy:1070
translate Spanish otkaz1_3d76067a:

    # e1 "Я был совсем мелким когда начал увлекаться Зельдой."
    e1 "Era muy pequeño cuando empecé a interesarme por Zelda."

# game/script3.rpy:1071
translate Spanish otkaz1_3bfd0440:

    # e1 "Позже связался не с той компашкой."
    e1 "Más tarde me junté con la compañía equivocada."

# game/script3.rpy:1072
translate Spanish otkaz1_d35e9552:

    # e1 "Культисты там, секта, жертвоприношения."
    e1 "Cultistas, una secta, sacrificios."

# game/script3.rpy:1074
translate Spanish otkaz1_c1050685:

    # e1 "Дети луны обещали, что я смогу стать тем, кого считаю кумиром."
    e1 "Los Hijos de la Luna prometieron que podría convertirme en quien consideraba mi ídolo."

# game/script3.rpy:1075
translate Spanish otkaz1_e272a691:

    # "Он засмеялся."
    "Soltó una risa."

# game/script3.rpy:1076
translate Spanish otkaz1_e97c7a6f:

    # e1 "Так и случилось."
    e1 "Y así fue."

# game/script3.rpy:1078
translate Spanish otkaz1_21d285f8:

    # e1 "Только вот..."
    e1 "El problema es que..."

# game/script3.rpy:1079
translate Spanish otkaz1_34e2a37c:

    # e1 "Эти уроды обещали мне власть и полную свободу."
    e1 "Esos monstruos me prometieron poder y libertad absoluta."

# game/script3.rpy:1080
translate Spanish otkaz1_87a71759:

    # e1 "А в итоге оставили гнить душу в старом картридже."
    e1 "Y al final dejaron que mi alma se pudriera en un viejo cartucho."

# game/script3.rpy:1081
translate Spanish otkaz1_a716cddc:

    # e1 "Но знаешь что..."
    e1 "Pero, ¿sabes qué...?"

# game/script3.rpy:1083
translate Spanish otkaz1_89e0cd41:

    # e1 "Я считаю, что мне просто не повезло."
    e1 "Creo que simplemente tuve mala suerte."

# game/script3.rpy:1084
translate Spanish otkaz1_ab3ebba7:

    # e1 "Не повезло так же, как и тебе сейчас."
    e1 "La misma mala suerte que tú tienes ahora."

# game/script3.rpy:1085
translate Spanish otkaz1_40e2dc8b:

    # e "Не повезло?"
    e "¿Mala suerte?"

# game/script3.rpy:1086
translate Spanish otkaz1_1f288fab:

    # e1 "Не повезло."
    e1 "Mala suerte."

# game/script3.rpy:1095
translate Spanish otkaz1_996916a7:

    # "Я резко оказываюсь на кровати."
    "De repente, me encuentro en la cama."

# game/script3.rpy:1096
translate Spanish otkaz1_24ae82f3:

    # "От несильного удара из лёгких выбило весь воздух."
    "Un golpe, no demasiado fuerte, me sacó todo el aire de los pulmones."

# game/script3.rpy:1097
translate Spanish otkaz1_1b4b6f19:

    # "Его руки крепко сомкнулись на моей шее."
    "Sus manos se cerraron con fuerza alrededor de mi cuello."

# game/script3.rpy:1098
translate Spanish otkaz1_5c7cdbd2:

    # "Я пытаюсь сопротивляться."
    "Intento resistirme."

# game/script3.rpy:1099
translate Spanish otkaz1_bbbb4483:

    # "Пытаюсь царапать его, но обескровленная плоть лишь остаётся под ногтями."
    "Intento arañarlo, pero solo me queda carne sin rastro de sangre bajo las uñas."

# game/script3.rpy:1100
translate Spanish otkaz1_99b375e6:

    # "В глазах начало темнеть."
    "Mi visión comenzó a oscurecerse."

# game/script3.rpy:1102
translate Spanish otkaz1_3f88b34c:

    # "Он сильнее сжал мою шею, выбивая из меня весь оставшийся кислород."
    "Apretó mi cuello con más fuerza, sacándome el último resto de oxígeno."

# game/script3.rpy:1103
translate Spanish otkaz1_f1b7eccc:

    # "Слёзы предательски покатились по щекам."
    "Las lágrimas traicioneras rodaron por mis mejillas."

# game/script3.rpy:1104
translate Spanish otkaz1_ecde26f2:

    # "Не могу вдохнуть, не могу даже дёрнуться."
    "No puedo respirar, ni siquiera puedo moverme."

# game/script3.rpy:1107
translate Spanish otkaz1_236fdbb8:

    # "Ничего не могу."
    "No puedo hacer nada."

# game/script3.rpy:1115
translate Spanish otkaz2_986ea467:

    # e1 "Глаза?"
    e1 "¿Los ojos?"

# game/script3.rpy:1116
translate Spanish otkaz2_e5692b1f:

    # "Я действительно идиотка."
    "De verdad que soy idiota."

# game/script3.rpy:1117
translate Spanish otkaz2_616b85af:

    # e1 "Это действительно то что тебя интересует?"
    e1 "¿Eso es realmente lo que te interesa?"

# game/script3.rpy:1118
translate Spanish otkaz2_83394905:

    # e "Ну э-э-э..."
    e "Bueno, eh..."

# game/script3.rpy:1119
translate Spanish otkaz2_aaa732fa:

    # "Я замялась."
    "Dudé."

# game/script3.rpy:1121
translate Spanish otkaz2_70c47a9b:

    # e1 "Мои глаза остались в прошлой жизни, и новые меня вполне устраивают."
    e1 "Mis ojos se quedaron en mi vida pasada, y los nuevos me vienen bien."

# game/script3.rpy:1122
translate Spanish otkaz2_a2f107ab:

    # e1 "Хотя..."
    e1 "Aunque..."

# game/script3.rpy:1131
translate Spanish otkaz2_580ae959:

    # e1 "Твои тоже мне нравятся."
    e1 "Los tuyos también me gustan."

# game/script3.rpy:1132
translate Spanish otkaz2_996916a7:

    # "Я резко оказываюсь на кровати."
    "De repente, me encuentro en la cama."

# game/script3.rpy:1133
translate Spanish otkaz2_24ae82f3:

    # "От несильного удара из лёгких выбило весь воздух."
    "Un golpe, no demasiado fuerte, me sacó todo el aire de los pulmones."

# game/script3.rpy:1134
translate Spanish otkaz2_10a242f8:

    # e1 "Можно я их заберу?"
    e1 "¿Puedo quedármelos?"

# game/script3.rpy:1135
translate Spanish otkaz2_f66d953c:

    # "Я быстро зажмурила глаза понимая, к чему он клонит."
    "Cerré los ojos de golpe, entendiendo a qué se refería."

# game/script3.rpy:1137
translate Spanish otkaz2_0f8627e0:

    # e "Нет!"
    e "¡No!"

# game/script3.rpy:1139
translate Spanish otkaz2_be5baa92:

    # "Но было поздно."
    "Pero era demasiado tarde."

# game/script3.rpy:1147
translate Spanish otkaz3_cc2c1f96:

    # "Я жалобно мямлила надеясь на лучшее."
    "Murmuraba quejumbrosa, esperando lo mejor."

# game/script3.rpy:1148
translate Spanish otkaz3_aee52dc5:

    # e1 "Какие же вы все одинаковые..."
    e1 "Todos ustedes son tan iguales..."

# game/script3.rpy:1149
translate Spanish otkaz3_9a6bfc35:

    # e1 "Все молите о пощаде и вас волнует только собственная жизнь."
    e1 "Todos suplican piedad y solo les importa su propia vida."

# game/script3.rpy:1150
translate Spanish otkaz3_0e723da6:

    # "Мой вопрос его совершенно не устроил."
    "Mi pregunta no le gustó en absoluto."

# game/script3.rpy:1151
translate Spanish otkaz3_01d34fa1:

    # e1 "Но когда мои органы вынимали из ещё живого тела, никто не думал больно мне или нет. И хочу ли я жить."
    e1 "Pero cuando me sacaban los órganos de un cuerpo aún vivo, a nadie le importó si me dolía o no. O si quería vivir."

# game/script3.rpy:1160
translate Spanish otkaz3_996916a7:

    # "Я резко оказываюсь на кровати."
    "De repente, me encuentro en la cama."

# game/script3.rpy:1161
translate Spanish otkaz3_24ae82f3:

    # "От несильного удара из лёгких выбило весь воздух."
    "Un golpe, no demasiado fuerte, me sacó todo el aire de los pulmones."

# game/script3.rpy:1162
translate Spanish otkaz3_1b4b6f19:

    # "Его руки крепко сомкнулись на моей шее."
    "Sus manos se cerraron con fuerza alrededor de mi cuello."

# game/script3.rpy:1163
translate Spanish otkaz3_5c7cdbd2:

    # "Я пытаюсь сопротивляться."
    "Intento resistirme."

# game/script3.rpy:1164
translate Spanish otkaz3_4ee37121:

    # e1 "Никто не думал как тесно может быть в цифровом мире, где, по факту, ты один."
    e1 "Nadie pensó lo claustrofóbico que puede ser el mundo digital, donde, en realidad, estás solo."

# game/script3.rpy:1165
translate Spanish otkaz3_58ee087a:

    # e "Бен я..."
    e "Ben, yo..."

# game/script3.rpy:1166
translate Spanish otkaz3_27198c72:

    # e1 "Нет, даже не пытайся."
    e1 "No, ni lo intentes."

# game/script3.rpy:1167
translate Spanish otkaz3_f1ea79b3:

    # "Его хватка стала сильнее, он с призрением смотрел на меня."
    "Su agarre se hizo más fuerte, me miraba con desprecio."

# game/script3.rpy:1168
translate Spanish otkaz3_99b375e6:

    # "В глазах начало темнеть."
    "Mi visión comenzó a oscurecerse."

# game/script3.rpy:1169
translate Spanish otkaz3_f1b7eccc:

    # "Слёзы предательски покатились по щекам."
    "Las lágrimas traicioneras rodaron por mis mejillas."

# game/script3.rpy:1170
translate Spanish otkaz3_ecde26f2:

    # "Не могу вдохнуть, не могу даже дёрнуться."
    "No puedo respirar, ni siquiera puedo moverme."

# game/script3.rpy:1173
translate Spanish otkaz3_236fdbb8:

    # "Ничего не могу."
    "No puedo hacer nada."

# game/script3.rpy:1175
translate Spanish otkaz3_19a46657:

    # "Последнее, что я услышала — хруст моих же шейных позвонков."
    "Lo último que escuché fue el crujido de mis propias vértebras cervicales."

# game/script3.rpy:1187
translate Spanish igra1_3c62379a:

    # "Риски действительно велики."
    "Los riesgos son realmente altos."

# game/script3.rpy:1188
translate Spanish igra1_8e4c0c8c:

    # "Может, лучше отказаться?"
    "¿Quizás sea mejor rechazarlo?"

# game/script3.rpy:1189
translate Spanish igra1_838a28f7:

    # "Хотя награда тоже интригует..."
    "Aunque la recompensa también resulta intrigante..."

# game/script3.rpy:1196
translate Spanish igra2_7cdbd183:

    # e "Нет, я хочу продолжить!"
    e "¡No, quiero continuar!"

# game/script3.rpy:1199
translate Spanish igra2_971fe6c1:

    # e1 "Оу, какая уверенность..."
    e1 "Oh, qué seguridad..."

# game/script3.rpy:1202
translate Spanish igra2_6820366d:

    # e1 "Мне нравится!"
    e1 "¡Me gusta!"

# game/script3.rpy:1203
translate Spanish igra2_f8063e3e:

    # e1 "Тогда давай начнём."
    e1 "Entonces, empecemos."

# game/script3.rpy:1204
translate Spanish igra2_cda2e378:

    # e1 "Не переживай, первый раунд лёгкий:"
    e1 "No te preocupes, la primera ronda es fácil:"

# game/script3.rpy:1205
translate Spanish igra2_af01da7b:

    # e1 "Как звали главного героя игры?"
    e1 "¿Cómo se llamaba el protagonista del juego?"

# game/script3.rpy:1223
translate Spanish cnojom_91db31cd:

    # e1 "Хм..."
    e1 "Mm..."

# game/script3.rpy:1224
translate Spanish cnojom_6695217a:

    # e1 "Кажется, ты не угадала..."
    e1 "Parece que no acertaste..."

# game/script3.rpy:1227
translate Spanish cnojom_8236bfe6:

    # e1 "..."
    e1 "..."

# game/script3.rpy:1236
translate Spanish cnojom_4eb0092b:

    # "Я не успела ни слова сказать, как оказалась на полу прямо под ним."
    "No me dio tiempo a decir una palabra cuando ya estaba en el suelo, justo debajo de él."

# game/script3.rpy:1237
translate Spanish cnojom_d438dfe5:

    # "Он легко удерживал мои руки над головой."
    "Sostenía mis manos por encima de mi cabeza con facilidad."

# game/script3.rpy:1238
translate Spanish cnojom_f52853cd:

    # e "Бен!"
    e "¡Ben!"

# game/script3.rpy:1239
translate Spanish cnojom_d09a6c25:

    # "Я вскрикнула чувствуя, как его рука шарит там где не следовало."
    "Grité al sentir su mano manoseando donde no debía."

# game/script3.rpy:1240
translate Spanish cnojom_186b4d8c:

    # "Я пыталась извиваться чувствуя, как его пальцы исследуют каждый сантиметр моего тела в области бёдер."
    "Intenté retorcerme mientras sentía sus dedos recorrer cada centímetro de mi cuerpo en la zona de las caderas."

# game/script3.rpy:1243
translate Spanish cnojom_1685e4d2:

    # e1 "Ой."
    e1 "Ups."

# game/script3.rpy:1244
translate Spanish cnojom_a00cba62:

    # e1 "Что это?"
    e1 "¿Qué es esto?"

# game/script3.rpy:1245
translate Spanish cnojom_c8a6a9e7:

    # "Его пальцы уверенно проникли ко мне в карман."
    "Sus dedos se metieron con seguridad en mi bolsillo."

# game/script3.rpy:1247
translate Spanish cnojom_0fd2e3f5:

    # e1 "Нашёл!"
    e1 "¡Lo encontré!"

# game/script3.rpy:1248
translate Spanish cnojom_03bd074b:

    # "Он поднял в воздух мой нож."
    "Alzó mi cuchillo en el aire."

# game/script3.rpy:1249
translate Spanish cnojom_3f2317a7:

    # "Я измучено простонала, теряя надежду на спасение."
    "Solté un gemido exhausto, perdiendo toda esperanza de salvación."

# game/script3.rpy:1250
translate Spanish cnojom_aee18daa:

    # e "Прошу..."
    e "Te lo ruego..."

# game/script3.rpy:1252
translate Spanish cnojom_311f6ebf:

    # "Он приставил нож к моему горлу."
    "Presionó el cuchillo contra mi garganta."

# game/script3.rpy:1253
translate Spanish cnojom_d396b2d3:

    # "Я сглотнула"
    "Tragué saliva."

# game/script3.rpy:1254
translate Spanish cnojom_c6aa85ec:

    # e1 "Ты проиграла."
    e1 "Perdiste."

# game/script3.rpy:1255
translate Spanish cnojom_2923cbe2:

    # "После этих слов он медленно вонзил нож в кожу."
    "Tras esas palabras, clavó lentamente el cuchillo en mi piel."

# game/script3.rpy:1256
translate Spanish cnojom_8cb11e07:

    # "Я взвыла не столько от боли сколько от страха."
    "Aullé, no tanto por el dolor como por el miedo."

# game/script3.rpy:1258
translate Spanish cnojom_cfcc0899:

    # "Нож дошёл до точки невозврата, перерезая мне горло от уха до уха."
    "El cuchillo alcanzó el punto de no retorno, cortándome la garganta de oreja a oreja."

# game/script3.rpy:1259
translate Spanish cnojom_235e95fa:

    # "Кровь фонтанировала."
    "La sangre brotaba a chorros."

# game/script3.rpy:1260
translate Spanish cnojom_2c96848a:

    # "Мои крики сменились на затихающие бульканья."
    "Mis gritos se transformaron en gorgoteos que se apagaban."

# game/script3.rpy:1261
translate Spanish cnojom_19167e6a:

    # "Глаза стали медленно закрываться."
    "Mis ojos comenzaron a cerrarse lentamente."

# game/script3.rpy:1264
translate Spanish cnojom_8f117c10:

    # "Мне становилось холодно."
    "Empezaba a sentir frío."

# game/script3.rpy:1273
translate Spanish besnoja_91db31cd:

    # e1 "Хм..."
    e1 "Mm..."

# game/script3.rpy:1274
translate Spanish besnoja_d7795e97:

    # e1 "Кажется ты не угадала..."
    e1 "Parece que no acertaste..."

# game/script3.rpy:1277
translate Spanish besnoja_8236bfe6:

    # e1 "..."
    e1 "..."

# game/script3.rpy:1286
translate Spanish besnoja_4eb0092b:

    # "Я не успела ни слова сказать, как оказалась на полу прямо под ним."
    "No me dio tiempo a decir una palabra cuando ya estaba en el suelo, justo debajo de él."

# game/script3.rpy:1287
translate Spanish besnoja_d438dfe5:

    # "Он легко удерживал мои руки над головой."
    "Sostenía mis manos por encima de mi cabeza con facilidad."

# game/script3.rpy:1288
translate Spanish besnoja_70ca58d5:

    # "Он держал в свободной руке нож, что ловко схватил с прикроватной тумбы."
    "En la mano libre sujetaba el cuchillo que había tomado hábilmente de la mesita de noche."

# game/script3.rpy:1289
translate Spanish besnoja_aee18daa:

    # e "Прошу..."
    e "Te lo ruego..."

# game/script3.rpy:1291
translate Spanish besnoja_311f6ebf:

    # "Он приставил нож к моему горлу."
    "Presionó el cuchillo contra mi garganta."

# game/script3.rpy:1292
translate Spanish besnoja_d396b2d3:

    # "Я сглотнула"
    "Tragué saliva."

# game/script3.rpy:1293
translate Spanish besnoja_c6aa85ec:

    # e1 "Ты проиграла."
    e1 "Perdiste."

# game/script3.rpy:1294
translate Spanish besnoja_2923cbe2:

    # "После этих слов он медленно вонзил нож в кожу."
    "Tras esas palabras, clavó lentamente el cuchillo en mi piel."

# game/script3.rpy:1295
translate Spanish besnoja_8cb11e07:

    # "Я взвыла не столько от боли сколько от страха."
    "Aullé, no tanto por el dolor como por el miedo."

# game/script3.rpy:1297
translate Spanish besnoja_cfcc0899:

    # "Нож дошёл до точки невозврата, перерезая мне горло от уха до уха."
    "El cuchillo alcanzó el punto de no retorno, cortándome la garganta de oreja a oreja."

# game/script3.rpy:1298
translate Spanish besnoja_235e95fa:

    # "Кровь фонтанировала."
    "La sangre brotaba a chorros."

# game/script3.rpy:1299
translate Spanish besnoja_2c96848a:

    # "Мои крики сменились на затихающие бульканья."
    "Mis gritos se transformaron en gorgoteos que se apagaban."

# game/script3.rpy:1300
translate Spanish besnoja_19167e6a:

    # "Глаза стали медленно закрываться."
    "Mis ojos comenzaron a cerrarse lentamente."

# game/script3.rpy:1303
translate Spanish besnoja_8f117c10:

    # "Мне становилось холодно."
    "Empezaba a sentir frío."

# game/script3.rpy:1312
translate Spanish dalee_6f48112c:

    # e1 "Ты угадала!"
    e1 "¡Acertaste!"

# game/script3.rpy:1313
translate Spanish dalee_d9237105:

    # e1 "Идём дальше!"
    e1 "¡Sigamos!"

# game/script3.rpy:1314
translate Spanish dalee_255850fc:

    # e1 "Какое оружие из серии самое сильное?"
    e1 "¿Cuál es el arma más poderosa de la saga?"

# game/script3.rpy:1323
translate Spanish dalee2_daee7764:

    # e1 "Ого, ты молодец!"
    e1 "Vaya, ¡lo haces muy bien!"

# game/script3.rpy:1324
translate Spanish dalee2_5c6beda3:

    # e1 "Какое племя живёт под водой?"
    e1 "¿Qué tribu vive bajo el agua?"

# game/script3.rpy:1333
translate Spanish dalee3_e2c0d901:

    # e1 "Ха-ха, хорошо, первый раунд закончен!"
    e1 "Ja, ja, bien, ¡la primera ronda ha terminado!"

# game/script3.rpy:1334
translate Spanish dalee3_f513b35d:

    # e1 "Теперь будет сложнее!"
    e1 "¡Ahora será más difícil!"

# game/script3.rpy:1335
translate Spanish dalee3_3a4f1134:

    # e1 "Когда появилась первая Зельда?"
    e1 "¿Cuándo salió el primer Zelda?"

# game/script3.rpy:1344
translate Spanish dalee4_fe6d419d:

    # e1 "Хорошо!"
    e1 "¡Bien!"

# game/script3.rpy:1345
translate Spanish dalee4_dd9c65b8:

    # e1 "Последний вопрос:"
    e1 "Última pregunta:"

# game/script3.rpy:1346
translate Spanish dalee4_9d07d8d9:

    # e1 "Сколько игр вышло на дынный момент?"
    e1 "¿Cuántos juegos han salido hasta la fecha?"

# game/script3.rpy:1357
translate Spanish dalee5_33994ea4:

    # e1 "Ты справилась с первой игрой и я, как и обещал, кое-чем тебя награжу."
    e1 "Superaste el primer juego y, como prometí, te recompensaré con algo."

# game/script3.rpy:1358
translate Spanish dalee5_39fea39d:

    # "Он щёлкнул пальцами и я ощутила, как начала затягиваться рана на бедре."
    "Chasqueó los dedos y sentí cómo la herida del muslo comenzaba a cerrarse."

# game/script3.rpy:1359
translate Spanish dalee5_97f7c716:

    # "Я коснулась пальцами места раны, но не ощутила той дыры, что причиняла мне боль."
    "Toqué el lugar de la herida con los dedos, pero ya no sentía aquel agujero que me dolía."

# game/script3.rpy:1360
translate Spanish dalee5_0eef0d0c:

    # "Она исчезла."
    "Había desaparecido."

# game/script3.rpy:1361
translate Spanish dalee5_cde8754c:

    # "Кажется я начинаю входить в азарт!"
    "¡Parece que estoy empezando a emocionarme!"

# game/script3.rpy:1362
translate Spanish dalee5_9c011fd8:

    # e1 "Оу, я вижу огонёк азарта в твоих глазах. Уверен, тебе понравится следующая игра."
    e1 "Oh, veo una chispa de emoción en tus ojos. Estoy seguro de que te gustará el siguiente juego."

# game/script3.rpy:1363
translate Spanish dalee5_61774386:

    # e1 "Ведь если ты выиграешь, то я покину тебя. Ну и ты вернёшься к своей унылой и скучной жизни."
    e1 "Porque si ganas, te dejaré en paz. Y tú volverás a tu vida monótona y aburrida."

# game/script3.rpy:1365
translate Spanish dalee5_6118ea57:

    # e1 "Так что? Играем?"
    e1 "¿Entonces? ¿Jugamos?"

# game/script3.rpy:1366
translate Spanish dalee5_7aa36427:

    # "Я замерла в изумлении"
    "Me quedé paralizada de asombro."

# game/script3.rpy:1367
translate Spanish dalee5_bbadd1d4:

    # "Но не известно, что скрывается за его сладкими словами."
    "Pero no se sabe qué se esconde tras sus dulces palabras."

# game/script3.rpy:1368
translate Spanish dalee5_fcfddc11:

    # "Может это ловушка?"
    "¿Será una trampa?"

# game/script3.rpy:1373
translate Spanish dalee5_8d6f326d:

    # e "Я больше не хочу играть."
    e "Ya no quiero jugar."

# game/script3.rpy:1374
translate Spanish dalee5_04fc5383:

    # e1 "Как скажешь."
    e1 "Como quieras."

# game/script3.rpy:1378
translate Spanish dalee6_59ab792c:

    # "Нет! Я справлюсь!"
    "¡No! ¡Lo lograré!"

# game/script3.rpy:1379
translate Spanish dalee6_ec5c18ee:

    # e "Я рискну!"
    e "¡Me arriesgaré!"

# game/script3.rpy:1382
translate Spanish dalee6_51f8cf77:

    # e1 "Ты начинаешь мне нравиться."
    e1 "Empiezas a caerme bien."

# game/script3.rpy:1383
translate Spanish dalee6_15ebabeb:

    # "Он похихикал, оценивая меня и определённо рассматривая со всех сторон"
    "Soltó una risita, evaluándome y, sin duda, recorriéndome con la mirada de arriba abajo."

# game/script3.rpy:1384
translate Spanish dalee6_c35e99e9:

    # "Хмыкнув он продолжил:"
    "Tras soltar un bufido, continuó:"

# game/script3.rpy:1386
translate Spanish dalee6_2008ccc4:

    # e1 "Игра на интуицию."
    e1 "Juego de intuición."

# game/script3.rpy:1387
translate Spanish dalee6_1f02f0f6:

    # e1 "Тебе нужно найти шарик спрятанный под стаканом."
    e1 "Tienes que encontrar la bolita escondida bajo el vaso."

# game/script3.rpy:1388
translate Spanish dalee6_8f42ab86:

    # e1 "Не подсматривай, ладно?"
    e1 "No mires, ¿vale?"

# game/script3.rpy:1389
translate Spanish dalee6_e55cfe84:

    # "Я кивнула и закрыла глаза."
    "Asentí y cerré los ojos."

# game/script3.rpy:1391
translate Spanish dalee6_cfadf125:

    # "Я слышала, как он берёт со стола стаканы моих соседей."
    "Escuché cómo tomaba de la mesa los vasos de mis vecinos."

# game/script3.rpy:1392
translate Spanish dalee6_a53ed1be:

    # e1 "Открывай."
    e1 "Abre."

# game/script3.rpy:1394
translate Spanish dalee6_ac29d269:

    # "Передо мной теперь стоит три стакана."
    "Frente a mí hay tres vasos."

# game/script3.rpy:1395
translate Spanish dalee6_788e079a:

    # "Где же может быть шарик???"
    "¿Dónde estará la bolita?"

# game/script3.rpy:1396
translate Spanish dalee6_bf676845:

    # "Мне нужно скорее определиться."
    "Debo decidirme rápido."

# game/script3.rpy:1399
translate Spanish dalee6_e7efb3df:

    # e1 "Посмотрим..."
    e1 "Veamos..."

# game/script3.rpy:1401
translate Spanish dalee6_c45c4a0a:

    # "Он открыл один стакан."
    "Destapó un vaso."

# game/script3.rpy:1404
translate Spanish dalee6_e7efb3df_1:

    # e1 "Посмотрим..."
    e1 "Veamos..."

# game/script3.rpy:1406
translate Spanish dalee6_c45c4a0a_1:

    # "Он открыл один стакан."
    "Destapó un vaso."

# game/script3.rpy:1409
translate Spanish dalee6_e7efb3df_2:

    # e1 "Посмотрим..."
    e1 "Veamos..."

# game/script3.rpy:1411
translate Spanish dalee6_c45c4a0a_2:

    # "Он открыл один стакан."
    "Destapó un vaso."

# game/script3.rpy:1423
translate Spanish cno_91db31cd:

    # e1 "Хм..."
    e1 "Mm..."

# game/script3.rpy:1424
translate Spanish cno_6695217a:

    # e1 "Кажется, ты не угадала..."
    e1 "Parece que no acertaste..."

# game/script3.rpy:1425
translate Spanish cno_8236bfe6:

    # e1 "..."
    e1 "..."

# game/script3.rpy:1434
translate Spanish cno_4eb0092b:

    # "Я не успела ни слова сказать, как оказалась на полу прямо под ним."
    "No me dio tiempo a decir una palabra cuando ya estaba en el suelo, justo debajo de él."

# game/script3.rpy:1435
translate Spanish cno_d438dfe5:

    # "Он легко удерживал мои руки над головой."
    "Sostenía mis manos por encima de mi cabeza con facilidad."

# game/script3.rpy:1436
translate Spanish cno_f52853cd:

    # e "Бен!"
    e "¡Ben!"

# game/script3.rpy:1437
translate Spanish cno_d09a6c25:

    # "Я вскрикнула чувствуя, как его рука шарит там где не следовало."
    "Grité al sentir su mano manoseando donde no debía."

# game/script3.rpy:1438
translate Spanish cno_186b4d8c:

    # "Я пыталась извиваться чувствуя, как его пальцы исследуют каждый сантиметр моего тела в области бёдер."
    "Intenté retorcerme mientras sentía sus dedos recorrer cada centímetro de mi cuerpo en la zona de las caderas."

# game/script3.rpy:1441
translate Spanish cno_1685e4d2:

    # e1 "Ой."
    e1 "Ups."

# game/script3.rpy:1442
translate Spanish cno_a00cba62:

    # e1 "Что это?"
    e1 "¿Qué es esto?"

# game/script3.rpy:1443
translate Spanish cno_c8a6a9e7:

    # "Его пальцы уверенно проникли ко мне в карман."
    "Sus dedos se metieron con seguridad en mi bolsillo."

# game/script3.rpy:1445
translate Spanish cno_0fd2e3f5:

    # e1 "Нашёл!"
    e1 "¡Lo encontré!"

# game/script3.rpy:1446
translate Spanish cno_03bd074b:

    # "Он поднял в воздух мой нож."
    "Alzó mi cuchillo en el aire."

# game/script3.rpy:1447
translate Spanish cno_3f2317a7:

    # "Я измучено простонала, теряя надежду на спасение."
    "Solté un gemido exhausto, perdiendo toda esperanza de salvación."

# game/script3.rpy:1448
translate Spanish cno_aee18daa:

    # e "Прошу..."
    e "Te lo ruego..."

# game/script3.rpy:1450
translate Spanish cno_311f6ebf:

    # "Он приставил нож к моему горлу."
    "Presionó el cuchillo contra mi garganta."

# game/script3.rpy:1451
translate Spanish cno_d396b2d3:

    # "Я сглотнула"
    "Tragué saliva."

# game/script3.rpy:1452
translate Spanish cno_c6aa85ec:

    # e1 "Ты проиграла."
    e1 "Perdiste."

# game/script3.rpy:1453
translate Spanish cno_2923cbe2:

    # "После этих слов он медленно вонзил нож в кожу."
    "Tras esas palabras, clavó lentamente el cuchillo en mi piel."

# game/script3.rpy:1454
translate Spanish cno_8cb11e07:

    # "Я взвыла не столько от боли сколько от страха."
    "Aullé, no tanto por el dolor como por el miedo."

# game/script3.rpy:1456
translate Spanish cno_8123f47f:

    # "Нож дошёл до точки невозврата перерезая мне горло от уха до уха."
    "El cuchillo alcanzó el punto de no retorno, cortándome la garganta de oreja a oreja."

# game/script3.rpy:1457
translate Spanish cno_235e95fa:

    # "Кровь фонтанировала."
    "La sangre brotaba a chorros."

# game/script3.rpy:1458
translate Spanish cno_2c96848a:

    # "Мои крики сменились на затихающие бульканья."
    "Mis gritos se transformaron en gorgoteos que se apagaban."

# game/script3.rpy:1459
translate Spanish cno_19167e6a:

    # "Глаза стали медленно закрываться."
    "Mis ojos comenzaron a cerrarse lentamente."

# game/script3.rpy:1462
translate Spanish cno_8f117c10:

    # "Мне становилось холодно."
    "Empezaba a sentir frío."

# game/script3.rpy:1470
translate Spanish bes_91db31cd:

    # e1 "Хм..."
    e1 "Mm..."

# game/script3.rpy:1471
translate Spanish bes_6695217a:

    # e1 "Кажется, ты не угадала..."
    e1 "Parece que no acertaste..."

# game/script3.rpy:1472
translate Spanish bes_8236bfe6:

    # e1 "..."
    e1 "..."

# game/script3.rpy:1474
translate Spanish bes_4eb0092b:

    # "Я не успела ни слова сказать, как оказалась на полу прямо под ним."
    "No me dio tiempo a decir una palabra cuando ya estaba en el suelo, justo debajo de él."

# game/script3.rpy:1475
translate Spanish bes_d438dfe5:

    # "Он легко удерживал мои руки над головой."
    "Sostenía mis manos por encima de mi cabeza con facilidad."

# game/script3.rpy:1476
translate Spanish bes_70ca58d5:

    # "Он держал в свободной руке нож, что ловко схватил с прикроватной тумбы."
    "En la mano libre sujetaba el cuchillo que había tomado hábilmente de la mesita de noche."

# game/script3.rpy:1477
translate Spanish bes_aee18daa:

    # e "Прошу..."
    e "Te lo ruego..."

# game/script3.rpy:1487
translate Spanish bes_311f6ebf:

    # "Он приставил нож к моему горлу."
    "Presionó el cuchillo contra mi garganta."

# game/script3.rpy:1488
translate Spanish bes_d396b2d3:

    # "Я сглотнула"
    "Tragué saliva."

# game/script3.rpy:1489
translate Spanish bes_c6aa85ec:

    # e1 "Ты проиграла."
    e1 "Perdiste."

# game/script3.rpy:1490
translate Spanish bes_2923cbe2:

    # "После этих слов он медленно вонзил нож в кожу."
    "Tras esas palabras, clavó lentamente el cuchillo en mi piel."

# game/script3.rpy:1491
translate Spanish bes_8cb11e07:

    # "Я взвыла не столько от боли сколько от страха."
    "Aullé, no tanto por el dolor como por el miedo."

# game/script3.rpy:1493
translate Spanish bes_cfcc0899:

    # "Нож дошёл до точки невозврата, перерезая мне горло от уха до уха."
    "El cuchillo alcanzó el punto de no retorno, cortándome la garganta de oreja a oreja."

# game/script3.rpy:1494
translate Spanish bes_235e95fa:

    # "Кровь фонтанировала."
    "La sangre brotaba a chorros."

# game/script3.rpy:1495
translate Spanish bes_2c96848a:

    # "Мои крики сменились на затихающие бульканья."
    "Mis gritos se transformaron en gorgoteos que se apagaban."

# game/script3.rpy:1496
translate Spanish bes_19167e6a:

    # "Глаза стали медленно закрываться."
    "Mis ojos comenzaron a cerrarse lentamente."

# game/script3.rpy:1499
translate Spanish bes_8f117c10:

    # "Мне становилось холодно."
    "Empezaba a sentir frío."

# game/script3.rpy:1507
translate Spanish dalee8_e94743d7:

    # e1 "Ой!"
    e1 "¡Ups!"

# game/script3.rpy:1508
translate Spanish dalee8_6fb5574c:

    # e1 "Да ты угадала!"
    e1 "¡Acertaste!"

# game/script3.rpy:1509
translate Spanish dalee8_cb8f0e7e:

    # e1 "Тогда закрывай глаза вновь!"
    e1 "¡Entonces vuelve a cerrar los ojos!"

# game/script3.rpy:1511
translate Spanish dalee8_234b6721:

    # "Я послушно накрыла глаза руками."
    "Obedientemente, me tapé los ojos con las manos."

# game/script3.rpy:1512
translate Spanish dalee8_a53ed1be:

    # e1 "Открывай."
    e1 "Abre."

# game/script3.rpy:1514
translate Spanish dalee8_7ae1929d:

    # "Вторая игра... Надо подумать."
    "Segunda partida... Tengo que pensarlo."

# game/script3.rpy:1515
translate Spanish dalee8_cd98409a:

    # "Где же может быть шарик?"
    "¿Dónde estará la bolita?"

# game/script3.rpy:1518
translate Spanish dalee8_e7efb3df:

    # e1 "Посмотрим..."
    e1 "Veamos..."

# game/script3.rpy:1520
translate Spanish dalee8_c45c4a0a:

    # "Он открыл один стакан."
    "Destapó un vaso."

# game/script3.rpy:1523
translate Spanish dalee8_e7efb3df_1:

    # e1 "Посмотрим..."
    e1 "Veamos..."

# game/script3.rpy:1525
translate Spanish dalee8_c45c4a0a_1:

    # "Он открыл один стакан."
    "Destapó un vaso."

# game/script3.rpy:1528
translate Spanish dalee8_e7efb3df_2:

    # e1 "Посмотрим..."
    e1 "Veamos..."

# game/script3.rpy:1530
translate Spanish dalee8_c45c4a0a_2:

    # "Он открыл один стакан."
    "Destapó un vaso."

# game/script3.rpy:1534
translate Spanish dalee9_e94743d7:

    # e1 "Ой!"
    e1 "¡Ups!"

# game/script3.rpy:1535
translate Spanish dalee9_6fb5574c:

    # e1 "Да ты угадала!"
    e1 "¡Acertaste!"

# game/script3.rpy:1536
translate Spanish dalee9_94c1023b:

    # e1 "В казино тебя теперь точно не пустят!"
    e1 "¡En el casino ya no te dejarán entrar!"

# game/script3.rpy:1537
translate Spanish dalee9_13c2f8f4:

    # e1 "У нас последняя игра! Закрывай глаза."
    e1 "¡Última partida! Cierra los ojos."

# game/script3.rpy:1539
translate Spanish dalee9_234b6721:

    # "Я послушно накрыла глаза руками."
    "Obedientemente, me tapé los ojos con las manos."

# game/script3.rpy:1540
translate Spanish dalee9_a843c271:

    # "Если сейчас я угадаю, то все мои мучения закончатся."
    "Si acierto ahora, todo mi sufrimiento terminará."

# game/script3.rpy:1541
translate Spanish dalee9_803b5dc3:

    # "Мне надо постараться."
    "Debo esforzarme."

# game/script3.rpy:1542
translate Spanish dalee9_a53ed1be:

    # e1 "Открывай."
    e1 "Abre."

# game/script3.rpy:1544
translate Spanish dalee9_41db72e2:

    # "Я нервно улыбаюсь."
    "Sonrío nerviosamente."

# game/script3.rpy:1545
translate Spanish dalee9_45bccc33:

    # "Руки трясутся, где же шарик?"
    "Me tiemblan las manos, ¿dónde está la bolita?"

# game/script3.rpy:1548
translate Spanish dalee9_e7efb3df:

    # e1 "Посмотрим..."
    e1 "Veamos..."

# game/script3.rpy:1550
translate Spanish dalee9_c45c4a0a:

    # "Он открыл один стакан."
    "Destapó un vaso."

# game/script3.rpy:1553
translate Spanish dalee9_e7efb3df_1:

    # e1 "Посмотрим..."
    e1 "Veamos..."

# game/script3.rpy:1556
translate Spanish dalee9_e7efb3df_2:

    # e1 "Посмотрим..."
    e1 "Veamos..."

# game/script3.rpy:1558
translate Spanish dalee9_c45c4a0a_1:

    # "Он открыл один стакан."
    "Destapó un vaso."

# game/script3.rpy:1570
translate Spanish cnoj2_c45c4a0a:

    # "Он открыл один стакан."
    "Destapó un vaso."

# game/script3.rpy:1571
translate Spanish cnoj2_b399373f:

    # "Улыбка упала с лица, а взгляд стал стеклянным."
    "La sonrisa se borró de mi rostro y mi mirada se volvió vidriosa."

# game/script3.rpy:1572
translate Spanish cnoj2_8ae808c3:

    # e1 "Такс, посмотрим ещё."
    e1 "Bueno, veamos uno más."

# game/script3.rpy:1574
translate Spanish cnoj2_fb6e5257:

    # "Он опрокинул ещё один стаканчик, но под ним тоже было пусто."
    "Volteó otro vasito, pero también estaba vacío."

# game/script3.rpy:1575
translate Spanish cnoj2_bbc7a459:

    # e1 "Может тут?"
    e1 "¿Quizás aquí?"

# game/script3.rpy:1576
translate Spanish cnoj2_3d2c393b:

    # "Я уже понимала к чему всё идёт."
    "Ya entendía hacia dónde iba todo esto."

# game/script3.rpy:1578
translate Spanish cnoj2_6c7f3f19:

    # e1 "Тоже пусто."
    e1 "También vacío."

# game/script3.rpy:1579
translate Spanish cnoj2_995a1c37:

    # "Он меня обманул."
    "Me engañó."

# game/script3.rpy:1581
translate Spanish cnoj2_4eb0092b:

    # "Я не успела ни слова сказать, как оказалась на полу прямо под ним."
    "No me dio tiempo a decir una palabra cuando ya estaba en el suelo, justo debajo de él."

# game/script3.rpy:1582
translate Spanish cnoj2_d438dfe5:

    # "Он легко удерживал мои руки над головой."
    "Sostenía mis manos por encima de mi cabeza con facilidad."

# game/script3.rpy:1583
translate Spanish cnoj2_ff1344cb:

    # e "Бен! Ты наврал мне!"
    e "¡Ben! ¡Me mentiste!"

# game/script3.rpy:1584
translate Spanish cnoj2_154f7686:

    # e1 "Ты действительно думала, что я отпущу тебя?"
    e1 "¿De verdad creíste que te dejaría ir?"

# game/script3.rpy:1585
translate Spanish cnoj2_d09a6c25:

    # "Я вскрикнула чувствуя, как его рука шарит там где не следовало."
    "Grité al sentir su mano manoseando donde no debía."

# game/script3.rpy:1586
translate Spanish cnoj2_186b4d8c:

    # "Я пыталась извиваться чувствуя, как его пальцы исследуют каждый сантиметр моего тела в области бёдер."
    "Intenté retorcerme mientras sentía sus dedos recorrer cada centímetro de mi cuerpo en la zona de las caderas."

# game/script3.rpy:1588
translate Spanish cnoj2_13fea6f1:

    # e "Пусти!"
    e "¡Suéltame!"

# game/script3.rpy:1590
translate Spanish cnoj2_1685e4d2:

    # e1 "Ой."
    e1 "Ups."

# game/script3.rpy:1591
translate Spanish cnoj2_a00cba62:

    # e1 "Что это?"
    e1 "¿Qué es esto?"

# game/script3.rpy:1592
translate Spanish cnoj2_c8a6a9e7:

    # "Его пальцы уверенно проникли ко мне в карман."
    "Sus dedos se metieron con seguridad en mi bolsillo."

# game/script3.rpy:1594
translate Spanish cnoj2_0fd2e3f5:

    # e1 "Нашёл!"
    e1 "¡Lo encontré!"

# game/script3.rpy:1595
translate Spanish cnoj2_03bd074b:

    # "Он поднял в воздух мой нож."
    "Alzó mi cuchillo en el aire."

# game/script3.rpy:1596
translate Spanish cnoj2_3f2317a7:

    # "Я измучено простонала, теряя надежду на спасение."
    "Solté un gemido exhausto, perdiendo toda esperanza de salvación."

# game/script3.rpy:1597
translate Spanish cnoj2_aee18daa:

    # e "Прошу..."
    e "Te lo ruego..."

# game/script3.rpy:1599
translate Spanish cnoj2_311f6ebf:

    # "Он приставил нож к моему горлу."
    "Presionó el cuchillo contra mi garganta."

# game/script3.rpy:1600
translate Spanish cnoj2_d396b2d3:

    # "Я сглотнула"
    "Tragué saliva."

# game/script3.rpy:1601
translate Spanish cnoj2_c6aa85ec:

    # e1 "Ты проиграла."
    e1 "Perdiste."

# game/script3.rpy:1602
translate Spanish cnoj2_2923cbe2:

    # "После этих слов он медленно вонзил нож в кожу."
    "Tras esas palabras, clavó lentamente el cuchillo en mi piel."

# game/script3.rpy:1603
translate Spanish cnoj2_8cb11e07:

    # "Я взвыла не столько от боли сколько от страха."
    "Aullé, no tanto por el dolor como por el miedo."

# game/script3.rpy:1605
translate Spanish cnoj2_cfcc0899:

    # "Нож дошёл до точки невозврата, перерезая мне горло от уха до уха."
    "El cuchillo alcanzó el punto de no retorno, cortándome la garganta de oreja a oreja."

# game/script3.rpy:1606
translate Spanish cnoj2_235e95fa:

    # "Кровь фонтанировала."
    "La sangre brotaba a chorros."

# game/script3.rpy:1607
translate Spanish cnoj2_2c96848a:

    # "Мои крики сменились на затихающие бульканья."
    "Mis gritos se transformaron en gorgoteos que se apagaban."

# game/script3.rpy:1608
translate Spanish cnoj2_19167e6a:

    # "Глаза стали медленно закрываться."
    "Mis ojos comenzaron a cerrarse lentamente."

# game/script3.rpy:1611
translate Spanish cnoj2_8f117c10:

    # "Мне становилось холодно."
    "Empezaba a sentir frío."

# game/script3.rpy:1619
translate Spanish besnoj2_a2e02585:

    # e1 "Ты победила."
    e1 "Ganaste."

# game/script3.rpy:1620
translate Spanish besnoj2_05f95212:

    # "Я не верю своим глазам!"
    "¡No puedo creer lo que veo!"

# game/script3.rpy:1622
translate Spanish besnoj2_d738c3f5:

    # "Я хотела встать, но он усадил меня обратно надавливая на плечи."
    "Quise levantarme, pero me obligó a sentarme de nuevo presionando mis hombros."

# game/script3.rpy:1624
translate Spanish besnoj2_c8dddf02:

    # e1 "Не хочешь даже попрощаться?"
    e1 "¿Ni siquiera quieres despedirte?"

# game/script3.rpy:1625
translate Spanish besnoj2_d8f55f27:

    # e "Ты обещал уйти..."
    e "Prometiste que te irías..."

# game/script3.rpy:1626
translate Spanish besnoj2_838f2cb1:

    # e1 "Уже выгоняешь?"
    e1 "¿Ya me estás echando?"

# game/script3.rpy:1629
translate Spanish besnoj2_9f908291:

    # e "Уходи."
    e "Vete."

# game/script3.rpy:1630
translate Spanish besnoj2_aca714ad:

    # e "Уговор есть уговор."
    e "Un trato es un trato."

# game/script3.rpy:1632
translate Spanish besnoj2_268fba2b:

    # e1 "Ну ты и скучная."
    e1 "Vaya, qué aburrida eres."

# game/script3.rpy:1640
translate Spanish besnoj2_e26941f0:

    # "Он удивился."
    "Se mostró sorprendido."

# game/script3.rpy:1642
translate Spanish besnoj2_85c967e5:

    # e1 "Вот это манеры."
    e1 "Vaya modales."

# game/script3.rpy:1643
translate Spanish besnoj2_95fdc03f:

    # e "Ну, ты ведь не причинишь больше зла мне?"
    e "Bueno, ¿no me harás más daño, verdad?"

# game/script3.rpy:1645
translate Spanish besnoj2_5b0da5ad:

    # e1 "Только твоей посуде."
    e1 "Solo a tu vajilla."

# game/script3.rpy:1646
translate Spanish besnoj2_e44d0ff4:

    # e "Идёт."
    e "Trato hecho."

# game/script3.rpy:1654
translate Spanish besnoj2_1b72d313:

    # e1 "Полнейшее отсутствие такта."
    e1 "Una total falta de tacto."

# game/script3.rpy:1655
translate Spanish besnoj2_3add09d1:

    # e "Не тебе меня судить, урод."
    e "No tienes derecho a juzgarme, monstruo."

# game/script3.rpy:1657
translate Spanish besnoj2_7dfbb668:

    # e1 "Не боишся встретиься со мной вновь?."
    e1 "¿No te da miedo volver a cruzarte conmigo?"

# game/script3.rpy:1658
translate Spanish besnoj2_226fe54c:

    # e "Только в твоих кошмарах."
    e "Solo en tus pesadillas."

# game/script3.rpy:1660
translate Spanish besnoj2_5c523627:

    # e1 "Я буду ждать."
    e1 "Estaré esperando."

# game/script3.rpy:1668
translate Spanish nova_303d8dd1:

    # e1 "Но ты выиграла."
    e1 "Pero ganaste."

# game/script3.rpy:1669
translate Spanish nova_ac3b8294:

    # e1 "Могла бы сорвать большой куш."
    e1 "Podrías haberte llevado un buen premio."

# game/script3.rpy:1670
translate Spanish nova_eb55ebe7:

    # "Он подмигнул мне."
    "Me guiñó un ojo."

# game/script3.rpy:1671
translate Spanish nova_691c321b:

    # e1 "Я думаю, удача не может быть вечно направлена лицом ко мне."
    e1 "Creo que la suerte no puede estar siempre de mi lado."

# game/script3.rpy:1672
translate Spanish nova_ae250a4b:

    # e1 "Может ты и права."
    e1 "Quizás tengas razón."

# game/script3.rpy:1674
translate Spanish nova_3fc835af:

    # e1 "Но знаешь, у нас есть ещё время, что бы вдоволь насладиться компанией друг друга."
    e1 "Pero sabes, aún nos queda tiempo para disfrutar de nuestra compañía a gusto."

# game/script3.rpy:1675
translate Spanish nova_f9517e4f:

    # e "О чём ты?"
    e "¿A qué te refieres?"

# game/script3.rpy:1677
translate Spanish nova_245a3ee7:

    # e1 "О-о-о, сестрёнка, поверь, у меня много идей."
    e1 "Oh, hermanita, créeme, tengo muchas ideas."

# game/script3.rpy:1678
translate Spanish nova_a7cc431d:

    # "Он лукаво заглянул мне в глаза."
    "Me miró a los ojos con picardía."

# game/script3.rpy:1679
translate Spanish nova_14f517d6:

    # e "Просвети..."
    e "Ilústrame..."

# game/script3.rpy:1680
translate Spanish nova_2dc19c43:

    # e1 "С радостью!"
    e1 "¡Con gusto!"

# game/script3.rpy:1681
translate Spanish nova_c38dcf54:

    # "Я устало вздохнула."
    "Suspiré cansada."

# game/script3.rpy:1684
translate Spanish nova_3f8ab17d:

    # "Но впервые договорить не дали ему."
    "Pero por primera vez, no lo dejaron terminar."

# game/script3.rpy:1685
translate Spanish nova_db3c6b68:

    # "В небе послышался сильнейший удар."
    "Un estruendo atronador resonó en el cielo."

# game/script3.rpy:1686
translate Spanish nova_5cca3f90:

    # "Я видела, как в соседних домах резко погас свет."
    "Vi cómo la luz se apagaba de golpe en las casas vecinas."

# game/script3.rpy:1687
translate Spanish nova_fa5fdf8e:

    # "Вместе с этим в моей комнате погас и индикатор телевизора, что говорил о достатке питания."
    "Junto con eso, en mi habitación se apagó el indicador del televisor que señalaba que había corriente."

# game/script3.rpy:1688
translate Spanish nova_711742e3:

    # "Бен заметно занервничал."
    "Ben se puso visiblemente nervioso."

# game/script3.rpy:1689
translate Spanish nova_f7eaf039:

    # "Хватка на моих плечах ослабла."
    "Su agarre en mis hombros se debilitó."

# game/script3.rpy:1690
translate Spanish nova_b3d8a098:

    # "Сейчас возможно и настал момент когда он уязвим!"
    "¡Quizás este sea el momento en que es vulnerable!"

# game/script3.rpy:1704
translate Spanish napadenie1_df8303a0:

    # "Я собираюсь с силами."
    "Reúno mis fuerzas."

# game/script3.rpy:1705
translate Spanish napadenie1_a654c221:

    # "Одним рывком я вынимаю из кармана нож."
    "De un tirón, saco el cuchillo del bolsillo."

# game/script3.rpy:1714
translate Spanish napadenie1_b82c3bac:

    # "Нож полоснул его по щеке."
    "El cuchillo le abrió un corte en la mejilla."

# game/script3.rpy:1715
translate Spanish napadenie1_3e6b3b3b:

    # "Не давая ему времени на раздумия и принятия решений, я хватаю его за рубашку, кидая на кровать."
    "Sin darle tiempo a pensar o reaccionar, lo agarro de la camisa y lo lanzo sobre la cama."

# game/script3.rpy:1717
translate Spanish napadenie1_8aa811bc:

    # "Он смотрел на меня не столько со страхом, сколько с непониманием."
    "Me miraba no tanto con miedo, sino con incomprensión."

# game/script3.rpy:1718
translate Spanish napadenie1_c81ad40c:

    # "Очевидно, он не верил, что я способна на подобное."
    "Obviamente, no podía creer que fuera capaz de algo así."

# game/script3.rpy:1719
translate Spanish napadenie1_cb6601e2:

    # e1 "Как ты..."
    e1 "¿Cómo...?"

# game/script3.rpy:1720
translate Spanish napadenie1_be4afab0:

    # "Я выставила перед собой нож."
    "Apunté el cuchillo hacia él."

# game/script3.rpy:1721
translate Spanish napadenie1_3b4d1bc8:

    # "Я явно давала понять, кто теперь тут главный."
    "Dejaba claro quién mandaba ahora aquí."

# game/script3.rpy:1722
translate Spanish napadenie1_52308e6e:

    # "Но я ведь не убийца?"
    "Pero yo no soy una asesina, ¿verdad?"

# game/script3.rpy:1723
translate Spanish napadenie1_2394f1a0:

    # "Убить его значит стать свободной, но убийц в мире меньше не станет."
    "Matarlo significaría ser libre, pero el mundo no tendrá menos asesinos por ello."

# game/script3.rpy:1724
translate Spanish napadenie1_86641069:

    # "Решение надо принять здесь и сейчас."
    "Debo tomar una decisión aquí y ahora."

# game/script3.rpy:1725
translate Spanish napadenie1_66479f10:

    # "Либо я..."
    "O yo..."

# game/script3.rpy:1726
translate Spanish napadenie1_e9d29704:

    # "Либо он."
    "O él."

# game/script3.rpy:1733
translate Spanish ybit_98639d42:

    # e "Убийц может и не станет меньше..."
    e "Puede que no haya menos asesinos..."

# game/script3.rpy:1734
translate Spanish ybit_35edac90:

    # e1 "Стой, прошу..."
    e1 "Espera, te lo ruego..."

# game/script3.rpy:1735
translate Spanish ybit_dd55c8a3:

    # "От тихо шептал мольбы, которые могли сорваться с моих губ."
    "Él susurraba en voz baja las mismas súplicas que podrían haber salido de mis labios."

# game/script3.rpy:1736
translate Spanish ybit_4fa59b9e:

    # e "Но жертв точно больше не будет!"
    e "¡Pero definitivamente no habrá más víctimas!"

# game/script3.rpy:1737
translate Spanish ybit_f662a067:

    # "Я замахиваюсь."
    "Alzo el brazo para atacar."

# game/script3.rpy:1746
translate Spanish ybit_a709f971:

    # "С силой я вонзила лезвие в его горло дёргая его вбок."
    "Con fuerza, clavé la hoja en su garganta y la giré hacia un lado."

# game/script3.rpy:1747
translate Spanish ybit_5afcb149:

    # "Кровь начала фонтанировать, пачкая моё лицо."
    "La sangre comenzó a brotar a chorros, manchándome la cara."

# game/script3.rpy:1748
translate Spanish ybit_ff51ad43:

    # "Он тут же схватился за рану."
    "De inmediato se llevó las manos a la herida."

# game/script3.rpy:1749
translate Spanish ybit_186d1053:

    # "Я смотрела, как он извивается в агонии."
    "Lo vi retorcirse en agonía."

# game/script3.rpy:1750
translate Spanish ybit_3b2d1dc5:

    # e "Ты бы убил меня так же..."
    e "Tú me habrías matado igual..."

# game/script3.rpy:1752
translate Spanish ybit_f26489f4:

    # "Его глаза медленно стали закрываться."
    "Sus ojos comenzaron a cerrarse lentamente."

# game/script3.rpy:1753
translate Spanish ybit_20a29941:

    # "Он умер."
    "Murió."

# game/script3.rpy:1754
translate Spanish ybit_9f7df064:

    # "Я его убила."
    "Lo maté."

# game/script3.rpy:1756
translate Spanish ybit_09a4a864:

    # "Я села обратно отвернувшись от него."
    "Me senté de nuevo, dándole la espalda."

# game/script3.rpy:1757
translate Spanish ybit_886f6f68:

    # "Шмыгнув носом, я принялась рассматривать свои руки."
    "Tras sorberme la nariz, me puse a mirar mis manos."

# game/script3.rpy:1758
translate Spanish ybit_5fb29110:

    # "Теперь в моей комнате труп неизвестного парня."
    "Ahora hay un cadáver de un chico desconocido en mi habitación."

# game/script3.rpy:1759
translate Spanish ybit_7a89887f:

    # "Нервная улыбка коснулась губ."
    "Una sonrisa nerviosa asomó en mis labios."

# game/script3.rpy:1767
translate Spanish neybit_98639d42:

    # e "Убийц может и не станет меньше..."
    e "Puede que no haya menos asesinos..."

# game/script3.rpy:1768
translate Spanish neybit_35edac90:

    # e1 "Стой, прошу..."
    e1 "Espera, te lo ruego..."

# game/script3.rpy:1769
translate Spanish neybit_dd55c8a3:

    # "От тихо шептал мольбы, которые могли сорваться с моих губ."
    "Él susurraba en voz baja las mismas súplicas que podrían haber salido de mis labios."

# game/script3.rpy:1770
translate Spanish neybit_4fa59b9e:

    # e "Но жертв точно больше не будет!"
    e "¡Pero definitivamente no habrá más víctimas!"

# game/script3.rpy:1771
translate Spanish neybit_f662a067:

    # "Я замахиваюсь."
    "Alzo el brazo para atacar."

# game/script3.rpy:1773
translate Spanish neybit_c08ca989:

    # "Но нож останавливается над головой."
    "Pero el cuchillo se detiene sobre su cabeza."

# game/script3.rpy:1774
translate Spanish neybit_87d2de4a:

    # "Я смотрю ему в глаза."
    "Lo miro a los ojos."

# game/script3.rpy:1775
translate Spanish neybit_dd72ce99:

    # "Он напуган."
    "Está aterrorizado."

# game/script3.rpy:1776
translate Spanish neybit_f2bfcbce:

    # e "Нет. Я не могу."
    e "No. No puedo."

# game/script3.rpy:1778
translate Spanish neybit_208abb37:

    # "Я опустила нож."
    "Bajé el cuchillo."

# game/script3.rpy:1779
translate Spanish neybit_174f5192:

    # "Теперь я больше не стараюсь удержать его под собой."
    "Ya no intento mantenerlo inmovilizado debajo de mí."

# game/script3.rpy:1780
translate Spanish neybit_c47ea84a:

    # "Он запросто может скинуть меня с себя."
    "Podría quitarme de encima con facilidad."

# game/script3.rpy:1781
translate Spanish neybit_47b50f0f:

    # "Может поменять нас местами."
    "Podría cambiar nuestras posiciones."

# game/script3.rpy:1782
translate Spanish neybit_864e837c:

    # "Но почему-то он не спешит делать это."
    "Pero por alguna razón, no se apresura a hacerlo."

# game/script3.rpy:1783
translate Spanish neybit_bca383b2:

    # e "Я не такая, как ты!"
    e "¡No soy como tú!"

# game/script3.rpy:1784
translate Spanish neybit_ca6d2e7c:

    # "Последнее я произношу через зубы."
    "Esto último lo escupo entre dientes."

# game/script3.rpy:1785
translate Spanish neybit_29215f2d:

    # "Нож выпадает их рук."
    "El cuchillo se me cae de las manos."

# game/script3.rpy:1787
translate Spanish neybit_431d1d32:

    # "Я сажусь на кровать спиной к нему."
    "Me siento en la cama, dándole la espalda."

# game/script3.rpy:1788
translate Spanish neybit_3fdd9085:

    # "Легко можно услышать как он берёт лезвие в руки."
    "Se escucha claramente cómo toma el cuchillo."

# game/script3.rpy:1790
translate Spanish neybit_c4cb0f87:

    # "Я закрываю глаза ожидая удара."
    "Cierro los ojos, esperando el golpe."

# game/script3.rpy:1791
translate Spanish neybit_d829e197:

    # "Но затем слышу, как оружие падает на пол."
    "Pero luego oigo cómo el arma cae al suelo."

# game/script3.rpy:1793
translate Spanish neybit_60a54098:

    # "Я открываю глаза."
    "Abro los ojos."

# game/script3.rpy:1794
translate Spanish neybit_1a0c5bd6:

    # "Он сел рядом, неловко ютясь на краю."
    "Se sentó a mi lado, acomodándose torpemente en el borde."

# game/script3.rpy:1795
translate Spanish neybit_add023ed:

    # e1 "Ты..."
    e1 "Tú..."

# game/script3.rpy:1796
translate Spanish neybit_0696d07b:

    # e1 "Меня не убила."
    e1 "No me mataste."

# game/script3.rpy:1797
translate Spanish neybit_1cab3834:

    # e1 "Я столько сделал"
    e1 "Hice tantas cosas..."

# game/script3.rpy:1799
translate Spanish neybit_7ed0b395:

    # e1 "А ты пощадила меня."
    e1 "Y tú me perdonaste la vida."

# game/script3.rpy:1800
translate Spanish neybit_5d873a5b:

    # e "Ты совершаешь ужасные вещи..."
    e "Haces cosas horribles..."

# game/script3.rpy:1801
translate Spanish neybit_7975c39f:

    # e "Может, хотя бы сейчас стоит одуматься?"
    e "¿Quizás, al menos ahora, deberías recapacitar?"

# game/script3.rpy:1802
translate Spanish neybit_608e5ff6:

    # e1 "Мне тяжело контролировать это..."
    e1 "Me cuesta mucho controlar esto..."

# game/script3.rpy:1803
translate Spanish neybit_777b9b35:

    # e "Это тебя не оправдывает."
    e "Eso no te justifica."

# game/script3.rpy:1804
translate Spanish neybit_2bc5986b:

    # e1 "Я оставлю тебя, и больше не побеспокою."
    e1 "Te dejaré en paz y no volveré a molestarte."

# game/script3.rpy:1805
translate Spanish neybit_07f36d85:

    # e "И когда-нибудь найдется тот, кто сможет сделать то, что не смогла я."
    e "Y algún día aparecerá alguien capaz de hacer lo que yo no pude."

# game/script3.rpy:1806
translate Spanish neybit_7e8f7bb7:

    # "Он замолчал."
    "Guardó silencio."

# game/script3.rpy:1814
translate Spanish napadenie2_92c825fd:

    # "Только я дёрнулась, что бы схватить его, как мои руки перехватили."
    "Apenas me moví para agarrarlo, cuando me sujetaron las manos."

# game/script3.rpy:1823
translate Spanish napadenie2_beac5e60:

    # "Он легко заломал мои руки опрокидывая тело."
    "Con facilidad, me retorció los brazos y me volteó."

# game/script3.rpy:1824
translate Spanish napadenie2_b243b366:

    # "Даже сейчас он сильнее."
    "Incluso ahora, es más fuerte."

# game/script3.rpy:1825
translate Spanish napadenie2_93b05dbb:

    # "Его руки грубо и крепко сжали моё горло."
    "Sus manos se cerraron con rudeza y fuerza alrededor de mi garganta."

# game/script3.rpy:1826
translate Spanish napadenie2_9880f9a3:

    # e1 "Ты хотела напасть на меня?!"
    e1 "¡¿Querías atacarme?!"

# game/script3.rpy:1827
translate Spanish napadenie2_3e3d333d:

    # e "Нет, Бен, пожалуйста, я..."
    e "No, Ben, por favor, yo..."

# game/script3.rpy:1828
translate Spanish napadenie2_0c3e7b4a:

    # "Я хрипела чувствуя, как пальцы сжимают мою трахею."
    "Jadeaba, sintiendo cómo sus dedos me aplastaban la tráquea."

# game/script3.rpy:1829
translate Spanish napadenie2_c865512c:

    # e "Нет, Бен, правда! Умоляю!"
    e "¡No, Ben, en serio! ¡Te lo suplico!"

# game/script3.rpy:1830
translate Spanish napadenie2_fc495d54:

    # e "Я не хотела убивать тебя!"
    e "¡No quería matarte!"

# game/script3.rpy:1831
translate Spanish napadenie2_1183dffe:

    # e1 "Я ненавижу лжецов!"
    e1 "¡Odio a los mentirosos!"

# game/script3.rpy:1832
translate Spanish napadenie2_b1f94a4c:

    # "У меня в глазах начало темнеть."
    "Mi visión comenzó a oscurecerse."

# game/script3.rpy:1833
translate Spanish napadenie2_556f09e0:

    # "Не могу поверить, что он настолько испугался."
    "No puedo creer que se haya asustado tanto."

# game/script3.rpy:1834
translate Spanish napadenie2_1c077640:

    # "Его хватка усилилась."
    "Su agarre se hizo más fuerte."

# game/script3.rpy:1835
translate Spanish napadenie2_cb2c59a6:

    # "Его кровь капала мне на лицо."
    "Su sangre me caía sobre la cara."

# game/script3.rpy:1836
translate Spanish napadenie2_5670e259:

    # "Он не просто душит меня, он впивался пальцами и ногтями так сильно, что казалось он хочет вырвать мне трахею."
    "No solo me estaba asfixiando; clavaba los dedos y las uñas con tanta fuerza que parecía querer arrancarme la tráquea."

# game/script3.rpy:1838
translate Spanish napadenie2_8cae707a:

    # "Это причиняло ужасную боль."
    "Provocaba un dolor insoportable."

# game/script3.rpy:1839
translate Spanish napadenie2_769ff3b4:

    # "Голова пульсировала."
    "La cabeza me palpitaba."

# game/script3.rpy:1840
translate Spanish napadenie2_bbd0422a:

    # "Но медленно боль начала отступать."
    "Pero lentamente, el dolor comenzó a menguar."

# game/script3.rpy:1843
translate Spanish napadenie2_939ccaf6:

    # e1 "Подохни уже!"
    e1 "¡Muérete de una vez!"

# game/script3.rpy:1851
translate Spanish nenapadenie_0f7cc4ba:

    # e1 "Ты только глянь."
    e1 "Solo mira."

# game/script3.rpy:1852
translate Spanish nenapadenie_592f160a:

    # "Нервно начал он."
    "empezó él, nervioso."

# game/script3.rpy:1853
translate Spanish nenapadenie_b4e962af:

    # e1 "На улице, кажется, темнеет."
    e1 "Parece que está oscureciendo ahí fuera."

# game/script3.rpy:1854
translate Spanish nenapadenie_01802a3a:

    # "Да, тут он прав."
    "Sí, en eso tiene razón."

# game/script3.rpy:1855
translate Spanish nenapadenie_930998bf:

    # "Начало темнеть."
    "Empezaba a oscurecer."

# game/script3.rpy:1856
translate Spanish nenapadenie_1dc82688:

    # "Я сделала вид, словно и не заметила его паники."
    "Hice como si no hubiera notado su pánico."

# game/script3.rpy:1857
translate Spanish nenapadenie_05fd4f15:

    # "Свой шанс я уже упустила."
    "Ya había perdido mi oportunidad."

# game/script3.rpy:1858
translate Spanish nenapadenie_2ac94116:

    # "Я ненароком зевнула."
    "Bostecé sin querer."

# game/script3.rpy:1860
translate Spanish nenapadenie_abc1a0a3:

    # e1 "Я считаю тебе нужно отдохнуть!"
    e1 "¡Creo que necesitas descansar!"

# game/script3.rpy:1861
translate Spanish nenapadenie_d96cafd8:

    # e1 "Да-да-да! Ты очень устала! Я вижу!"
    e1 "¡Sí, sí, sí! ¡Estás muy cansada! ¡Lo veo!"

# game/script3.rpy:1862
translate Spanish nenapadenie_ba098ffb:

    # e "Бен, эм, я..."
    e "Ben, eh, yo..."

# game/script3.rpy:1863
translate Spanish nenapadenie_f43e7912:

    # e1 "Да ну-у-у!"
    e1 "¡Vamos, no insistas!"

# game/script3.rpy:1864
translate Spanish nenapadenie_2a3024de:

    # e1 "Я вымотал тебя. Ты можешь лечь спать я не в обиде!"
    e1 "Te he agotado. Puedes irte a dormir, ¡no me ofendo!"

# game/script3.rpy:1865
translate Spanish nenapadenie_1fb39dd9:

    # e1 "Вот, с этим будет легче."
    e1 "Toma, con esto te será más fácil."

# game/script3.rpy:1867
translate Spanish nenapadenie_8b098322:

    # "Он протянул мне стеклянную банку с какой-то тёмной жидкостью."
    "Me tendió un frasco de vidrio con algún líquido oscuro."

# game/script3.rpy:1868
translate Spanish nenapadenie_145b6e7e:

    # e1 "Это поможет уснуть."
    e1 "Esto te ayudará a dormir."

# game/script3.rpy:1869
translate Spanish nenapadenie_e46e0c23:

    # "Я с сомнением посмотрела на баночку, после, беря её в руки и откручивая крышку."
    "Miré el frasco con duda, luego lo tomé y desenroscé la tapa."

# game/script3.rpy:1870
translate Spanish nenapadenie_5307e882:

    # "Ничем, вроде, не пахнет."
    "Parece que no huele a nada."

# game/script3.rpy:1871
translate Spanish nenapadenie_276b1452:

    # "Я сделала глоток."
    "Di un sorbo."

# game/script3.rpy:1872
translate Spanish nenapadenie_9ae9ccaf:

    # "Жидкость приятно обволакивала горло."
    "El líquido recubrió agradablemente mi garganta."

# game/script3.rpy:1874
translate Spanish nenapadenie_0dc4ec87:

    # e1 "Ну как оно?"
    e1 "¿Qué tal?"

# game/script3.rpy:1875
translate Spanish nenapadenie_ead6efbb:

    # "Я начала чувствовать себя приподнято. Тревога быстро сошла на нет."
    "Empecé a sentirme eufórica. La ansiedad desapareció rápidamente."

# game/script3.rpy:1876
translate Spanish nenapadenie_b994d235:

    # e "Кажется, лучше..."
    e "Parece que mejor..."

# game/script3.rpy:1878
translate Spanish nenapadenie_48ea0245:

    # e1 "Отлично."
    e1 "Genial."

# game/script3.rpy:1879
translate Spanish nenapadenie_db36f447:

    # e1 "Значит спокойной ночи!"
    e1 "¡Entonces, buenas noches!"

# game/script3.rpy:1880
translate Spanish nenapadenie_2b7a16f6:

    # "Он толкнул меня на кровать."
    "Me empujó hacia la cama."

# game/script3.rpy:1889
translate Spanish nenapadenie_7ce03f03:

    # "Я уставилась в потолок."
    "Me quedé mirando el techo."

# game/script3.rpy:1890
translate Spanish nenapadenie_fcfdb92c:

    # "Сладко зевнув, я закрыла глаза."
    "Tras un dulce bostezo, cerré los ojos."

# game/script3.rpy:1893
translate Spanish nenapadenie_6c80b428:

    # e2 "Тебя постигла ужасная участь..."
    e2 "Te ha tocado un destino terrible..."

# game/script3.rpy:1894
translate Spanish nenapadenie_f0545410:

    # e2 "Тебя постигла ужасная участь."
    e2 "Has sufrido un destino terrible."

# game/script3.rpy:1895
translate Spanish nenapadenie_f917f4c3:

    # e2 "Тебя постигла ужасная участь!!!"
    e2 "¡¡¡Has sufrido un destino terrible!!!"

# game/script3.rpy:1896
translate Spanish nenapadenie_127c2fe9:

    # e2 "..."
    e2 "..."

# game/script3.rpy:1897
translate Spanish nenapadenie_ede2aa53:

    # e2 "Не так ли?"
    e2 "¿No es así?"

# game/script3.rpy:1898
translate Spanish nenapadenie_479b1c35:

    # e "Что?"
    e "¿Qué?"

# game/script3.rpy:1899
translate Spanish nenapadenie_5fda87d6:

    # e2 "Так же как и его."
    e2 "Al igual que el suyo."

# game/script3.rpy:1900
translate Spanish nenapadenie_4aeb9247:

    # "Странный голос колокольным звоном прозвучал в темноте, я тут же открыла глаза."
    "Una voz extraña resonó como una campana en la oscuridad; abrí los ojos de inmediato."

# game/script3.rpy:1902
translate Spanish nenapadenie_4cb986aa:

    # "Не знаю сколько я спала, но на улице окончательно стемнело."
    "No sé cuánto dormí, pero ahí fuera ya había oscurecido por completo."

# game/script3.rpy:1904
translate Spanish nenapadenie_41e35810:

    # "Приподнявшись и повернув голову, я увидела Бена."
    "Al incorporarme y girar la cabeza, vi a Ben."

# game/script3.rpy:1905
translate Spanish nenapadenie_9818ab42:

    # "Он сидел на подоконнике умиротворённо разглядывая что-то в окне."
    "Estaba sentado en el alféizar, observando con calma algo por la ventana."

# game/script3.rpy:1907
translate Spanish nenapadenie_d2d8b450:

    # "Я тихо подобралась ближе к нему."
    "Me acerqué a él en silencio."

# game/script3.rpy:1908
translate Spanish nenapadenie_22a9ac91:

    # e1 "Не спится?"
    e1 "¿No puedes dormir?"

# game/script3.rpy:1921
translate Spanish konec1_60858f35:

    # e1 "Да? И что же ты видела?"
    e1 "¿Sí? ¿Y qué viste?"

# game/script3.rpy:1922
translate Spanish konec1_602cdad4:

    # e "Даже скорее слышала..."
    e "Más bien oí..."

# game/script3.rpy:1923
translate Spanish konec1_1194d21d:

    # e "Странный скрипучий голос"
    e "Una voz extraña y chirriante"

# game/script3.rpy:1924
translate Spanish konec1_afa10cc7:

    # e "Он всё время твердил, что меня постигла ужасная участь. Звучит странно."
    e "No paraba de repetir que mi destino era terrible. Suena extraño."

# game/script3.rpy:1926
translate Spanish konec1_30ad7595:

    # e1 "Это просто глупый сон."
    e1 "Es solo un sueño estúpido."

# game/script3.rpy:1928
translate Spanish konec1_62f9fd3e:

    # e "Но кажется, что голос упомянул и тебя..."
    e "Pero parece que la voz también te mencionó a ti..."

# game/script3.rpy:1929
translate Spanish konec1_762917a7:

    # e1 "Не говори ерунды, ты просто устала."
    e1 "No digas tonterías, solo estás cansada."

# game/script3.rpy:1930
translate Spanish konec1_588e9a53:

    # "Он что-то понимал, но мне говорить не решался."
    "Entendía algo, pero no se atrevía a decírmelo."

# game/script3.rpy:1931
translate Spanish konec1_181c7374:

    # e "Что это могло значить?"
    e "¿Qué podría significar?"

# game/script3.rpy:1932
translate Spanish konec1_dff15f33:

    # "Я продолжала стоять на своём."
    "Seguí insistiendo en mi postura."

# game/script3.rpy:1933
translate Spanish konec1_a4db4448:

    # e1 "Я сказал вали спать! Пока твой сон не стал вечным!"
    e1 "¡Te dije que te largues a dormir! ¡Antes de que tu sueño se vuelva eterno!"

# game/script3.rpy:1934
translate Spanish konec1_7c934666:

    # "Я не хочу спорить с ним, не думаю, что в этом есть смысл."
    "No quiero discutir con él, no creo que tenga sentido."

# game/script3.rpy:1939
translate Spanish konec5_89349140:

    # "Я ложусь обратно."
    "Me recuesto de nuevo."

# game/script3.rpy:1940
translate Spanish konec5_55094e2f:

    # "С ним просто бесполезно разговаривать."
    "Simplemente es inútil hablar con él."

# game/script3.rpy:1942
translate Spanish konec5_24b4c630:

    # "Я мигом упала в крепкий сон..."
    "Caí de inmediato en un sueño profundo..."

# game/script3.rpy:1944
translate Spanish konec5_57e0d58f:

    # "Открыв глаза, я увидела тот же потолок."
    "Al abrir los ojos, vi el mismo techo."

# game/script3.rpy:1945
translate Spanish konec5_201561bf:

    # "Бена рядом не было..."
    "Ben no estaba a mi lado..."

# game/script3.rpy:1947
translate Spanish konec5_e1e826f6:

    # "Его не было во всей комнате."
    "No estaba en toda la habitación."

# game/script3.rpy:1948
translate Spanish konec5_32fd4ca3:

    # "Неужели..."
    "¿Será posible que...?"

# game/script3.rpy:1949
translate Spanish konec5_669ab899:

    # "Он оставил меня?"
    "¿Me dejó?"

# game/script3.rpy:1958
translate Spanish konec2_0942e121:

    # e1 "Врать не стану: это действительно дрянь."
    e1 "No voy a mentir: es una verdadera porquería."

# game/script3.rpy:1960
translate Spanish konec2_1ce6f8f1:

    # e1 "Но ты хотя бы не трясёшься от страха теперь."
    e1 "Pero al menos ya no tiemblas de miedo."

# game/script3.rpy:1961
translate Spanish konec2_d736b834:

    # e1 "И в твоих глазах не скачут трусливые огоньки."
    e1 "Y esos destellos cobardes ya no saltan en tus ojos."

# game/script3.rpy:1962
translate Spanish konec2_611ea85b:

    # e "Я и не боялась."
    e "Ni siquiera tenía miedo."

# game/script3.rpy:1963
translate Spanish konec2_8d26bf27:

    # "Наверное, если бы сейчас я не была в приподнятом состоянии, то закрыла бы рот руками."
    "Probablemente, si no estuviera bajo los efectos de eso ahora, me habría tapado la boca con las manos."

# game/script3.rpy:1964
translate Spanish konec2_4f72c9a0:

    # "Уж слишком смелыми были мои высказывания."
    "Mis palabras habían sido demasiado atrevidas."

# game/script3.rpy:1965
translate Spanish konec2_b694da96:

    # e1 "Правда?"
    e1 "¿De verdad?"

# game/script3.rpy:1966
translate Spanish konec2_3ded385c:

    # e1 "Может тогда и смерти не боишься?"
    e1 "¿Entonces tampoco le temes a la muerte?"

# game/script3.rpy:1967
translate Spanish konec2_6394980e:

    # e "Чего?"
    e "¿Qué?"

# game/script3.rpy:1968
translate Spanish konec2_e50a5815:

    # e1 "Что ты слышала."
    e1 "Lo que oíste."

# game/script3.rpy:1969
translate Spanish konec2_94b3cb42:

    # e1 "Прикончи себя на радость мне."
    e1 "Mátate para mi deleite."

# game/script3.rpy:1970
translate Spanish konec2_20ee460b:

    # e1 "Можешь выпрыгнуть с окна."
    e1 "Puedes saltar por la ventana."

# game/script3.rpy:1971
translate Spanish konec2_4d2ed8be:

    # e1 "Но если ты останешься жива, то я сделаю твою жизнь сказкой:"
    e1 "Pero si sobrevives, haré que tu vida sea un cuento de hadas:"

# game/script3.rpy:1972
translate Spanish konec2_cdfda3e1:

    # e1 "Популярность, деньги, всё что ты захочешь!"
    e1 "Popularidad, dinero, ¡todo lo que quieras!"

# game/script3.rpy:1973
translate Spanish konec2_f5392245:

    # "Он на секунду замолчал."
    "Guardó silencio por un segundo."

# game/script3.rpy:1974
translate Spanish konec2_2a556a0f:

    # e1 "Однако..."
    e1 "Sin embargo..."

# game/script3.rpy:1975
translate Spanish konec2_f5942af9:

    # e1 "Сможешь ли ты."
    e1 "¿Serás capaz?"

# game/script3.rpy:1976
translate Spanish konec2_516f252b:

    # "Я опешила."
    "Me quedé paralizada."

# game/script3.rpy:1977
translate Spanish konec2_08ded51b:

    # "Но может у меня действительно появилась возможность доказать ему свою правоту?"
    "Pero ¿quizás realmente tengo la oportunidad de demostrarle que tengo razón?"

# game/script3.rpy:1982
translate Spanish konec2_6500e424:

    # "Нет. Всё же это слишком."
    "No. Sigue siendo demasiado."

# game/script3.rpy:1983
translate Spanish konec2_1874a784:

    # "Я стыдливо опускаю глаза."
    "Bajo la mirada, avergonzada."

# game/script3.rpy:1984
translate Spanish konec2_3d383ae9:

    # e1 "Вот видишь."
    e1 "Ya ves."

# game/script3.rpy:1985
translate Spanish konec2_a1e984a0:

    # e1 "Ты слишком сильно веришь, что игра в героя тебе хоть что-то да даст."
    e1 "Estás demasiado convencida de que jugar a la heroína te servirá de algo."

# game/script3.rpy:1986
translate Spanish konec2_b4437c4d:

    # e1 "Ты жалкая."
    e1 "Eres patética."

# game/script3.rpy:1987
translate Spanish konec2_eff9686e:

    # "Я открываю рот, что бы возразить, но он не даёт это сделать."
    "Abro la boca para replicar, pero no me deja hacerlo."

# game/script3.rpy:1988
translate Spanish konec2_0803e310:

    # e1 "Всё, оставь меня, ты не с тем затеяла беседу."
    e1 "Basta, déjame, no es conmigo con quien deberías hablar."

# game/script3.rpy:1993
translate Spanish konec9_10538571:

    # "Я не стушуюсь!"
    "¡No me acobardo!"

# game/script3.rpy:1994
translate Spanish konec9_bdff004e:

    # "Не смей брать меня на понт!"
    "¡No intentes provocarme!"

# game/script3.rpy:1995
translate Spanish konec9_da6f9cdb:

    # "Я гордо запрокидываю голову и поднимаюсь с кровати."
    "Alzo la cabeza con orgullo y me levanto de la cama."

# game/script3.rpy:1997
translate Spanish konec9_227f44ed:

    # "Он уступает мне место и я становлюсь на подоконник."
    "Me cede el sitio y me subo al alféizar."

# game/script3.rpy:1998
translate Spanish konec9_f2c5511f:

    # "Высоко..."
    "Está alto..."

# game/script3.rpy:1999
translate Spanish konec9_33553be5:

    # "Но мне нестрашно."
    "Pero no me da miedo."

# game/script3.rpy:2000
translate Spanish konec9_3beb5d70:

    # "Мне плевать на деньги, плевать на славу."
    "Me importan un bledo el dinero y la fama."

# game/script3.rpy:2001
translate Spanish konec9_828ab583:

    # "Я хочу увидеть в его глазах реальное удивление."
    "Quiero ver una sorpresa genuina en sus ojos."

# game/script3.rpy:2002
translate Spanish konec9_7e73a146:

    # "Он знает каждый мой шаг!"
    "¡Conoce cada uno de mis movimientos!"

# game/script3.rpy:2003
translate Spanish konec9_2e607085:

    # "Как же бесит!"
    "¡Qué rabia me da!"

# game/script3.rpy:2004
translate Spanish konec9_e2ebde41:

    # e "Да сгори ты в аду, Бен!"
    e "¡Vete al infierno, Ben!"

# game/script3.rpy:2006
translate Spanish konec9_a41e3d7c:

    # "Я делаю шаг вперёд."
    "Doy un paso adelante."

# game/script3.rpy:2008
translate Spanish konec9_7658bbdd:

    # "Я слышу хруст собственных костей."
    "Oigo el crujido de mis propios huesos."

# game/script3.rpy:2018
translate Spanish konec9_cf5f6be2:

    # "И вот я лежу на холодном асфальте."
    "Y aquí estoy, tendida sobre el asfalto frío."

# game/script3.rpy:2019
translate Spanish konec9_d5f63a6a:

    # "Я чувствую, как растекается подо мной лужа крови."
    "Siento cómo se extiende bajo mí un charco de sangre."

# game/script3.rpy:2020
translate Spanish konec9_53ac1cfd:

    # "Ощущаю, как началось внутреннее кровотечение."
    "Percibo cómo ha comenzado la hemorragia interna."

# game/script3.rpy:2022
translate Spanish konec9_60e4fe5c:

    # "Мои глаза стали закатываться, а веки потяжелели."
    "Mis ojos comienzan a ponerse en blanco y los párpados se vuelven pesados."

# game/script3.rpy:2023
translate Spanish konec9_2390e327:

    # e2 "А он нехило тебя помотал."
    e2 "Vaya, cómo te ha zarandeado."

# game/script3.rpy:2024
translate Spanish konec9_83b2e144:

    # "Я слышу сверху хриплый голос."
    "Escucho una voz ronca desde arriba."

# game/script3.rpy:2025
translate Spanish konec9_e75f40ae:

    # "Из последних сил я пытаюсь открыть глаза"
    "Con las últimas fuerzas, intento abrir los ojos."

# game/script3.rpy:2027
translate Spanish konec9_32d74d6d:

    # "Надо мной стоит человек."
    "Hay una persona parada sobre mí."

# game/script3.rpy:2028
translate Spanish konec9_e2428483:

    # e2 "Нехило, но..."
    e2 "No está mal, pero..."

# game/script3.rpy:2030
translate Spanish konec9_b98100fc:

    # e2 "Слишком мало!"
    e2 "¡Muy poco!"

# game/script3.rpy:2031
translate Spanish konec9_ead57043:

    # e2 "Так не интересно!"
    e2 "¡Así no tiene gracia!"

# game/script3.rpy:2032
translate Spanish konec9_4c788411:

    # "Он рывком опустился ко мне, хватая за плечи."
    "Se deja caer de golpe a mi lado, agarrándome de los hombros."

# game/script3.rpy:2033
translate Spanish konec9_62492860:

    # "Голову тут же пронзила боль."
    "Un dolor agudo me atraviesa la cabeza al instante."

# game/script3.rpy:2034
translate Spanish konec9_bc008219:

    # e2 "Ты и вправду странная..."
    e2 "De verdad que eres rara..."

# game/script3.rpy:2035
translate Spanish konec9_021a08b1:

    # e2 "И мне всё ещё не ясно. И с каких это интересно пор Бен начал заглядываться на таких, как ты?"
    e2 "Y sigo sin entenderlo. ¿Desde cuándo, me pregunto, Ben empezó a fijarse en chicas como tú?"

# game/script3.rpy:2036
translate Spanish konec9_ca5951a2:

    # "Он произносит слова, но я совсем не могу понять их смысл..."
    "Dice palabras, pero no logro entender su significado..."

# game/script3.rpy:2037
translate Spanish konec9_92d92954:

    # "О чём он говорит?"
    "¿De qué está hablando?"

# game/script3.rpy:2038
translate Spanish konec9_52fe85e4:

    # e2 "Ты уже меня не слышишь, да?"
    e2 "Ya no me escuchas, ¿verdad?"

# game/script3.rpy:2039
translate Spanish konec9_9e79422a:

    # "Я стараюсь шевелить губами."
    "Intento mover los labios."

# game/script3.rpy:2040
translate Spanish konec9_4a281b47:

    # "Он страдальчески вздыхает."
    "Suelta un suspiro de desesperación."

# game/script3.rpy:2041
translate Spanish konec9_19fb4de3:

    # e2 "Да. Ты уже всё равно ничего не воспринимаешь."
    e2 "Sí. De todos modos, ya no percibes nada."

# game/script3.rpy:2043
translate Spanish konec9_2141c1f3:

    # "Я закрываю глаза."
    "Cierro los ojos."

# game/script3.rpy:2044
translate Spanish konec9_b8822a6e:

    # e2 "Просто иди спать."
    e2 "Simplemente duérmete."

# game/script3.rpy:2053
translate Spanish konec7_ed81f009:

    # e1 "Твоё молчание меня бесит."
    e1 "Tu silencio me saca de quicio."

# game/script3.rpy:2054
translate Spanish konec7_a20cefa7:

    # "..."
    "..."

# game/script3.rpy:2055
translate Spanish konec7_ac594fa7:

    # e1 "Ты точно какая-то придурошная."
    e1 "De verdad que estás chalada."

# game/script3.rpy:2056
translate Spanish konec7_8ca42802:

    # e1 "Даже не думай о какой-то беседе."
    e1 "Ni se te ocurra querer conversar."

# game/script3.rpy:2057
translate Spanish konec7_b05521d7:

    # e1 "Если тебе не спится, то это твои проблемы."
    e1 "Si no puedes dormir, ese es tu problema."

# game/script3.rpy:2062
translate Spanish konec4_97bd43ef:

    # e1 "Как хочешь."
    e1 "Como quieras."

# game/script3.rpy:2063
translate Spanish konec4_52de0c95:

    # e1 "Я даже не против твоей компании."
    e1 "Ni siquiera me molesta tu compañía."

# game/script3.rpy:2064
translate Spanish konec4_af6d419a:

    # e1 "Но у меня всё ещё есть под боком та дрянь, что позволила тебе уснуть."
    e1 "Pero aún tengo a mi lado esa porquería que te hizo dormir."

# game/script3.rpy:2065
translate Spanish konec4_3560ece7:

    # e "Нет. Мне это не нужно."
    e "No. No lo necesito."

# game/script3.rpy:2066
translate Spanish konec4_0360d382:

    # "Слова легко срывались с уст."
    "Las palabras brotaron con facilidad de mis labios."

# game/script3.rpy:2067
translate Spanish konec4_500f4a53:

    # "Я не боялась его."
    "No le tenía miedo."

# game/script3.rpy:2069
translate Spanish konec4_bcd2db5a:

    # e1 "Могу я задать тебе вопрос?"
    e1 "¿Puedo hacerte una pregunta?"

# game/script3.rpy:2070
translate Spanish konec4_f8b88a20:

    # e "Да."
    e "Sí."

# game/script3.rpy:2071
translate Spanish konec4_4af2976d:

    # e1 "Что конкретно ты сейчас чувствуешь?"
    e1 "¿Qué sientes exactamente ahora?"

# game/script3.rpy:2073
translate Spanish konec4_38e9a5ba:

    # e1 "Я имею в виду: наверняка ты хочешь убить меня или что-то в этом духе."
    e1 "Me refiero a: seguro que quieres matarme o algo así."

# game/script3.rpy:2074
translate Spanish konec4_94ac8725:

    # e1 "Ты держишь на меня обиду."
    e1 "Guardas rencor hacia mí."

# game/script3.rpy:2075
translate Spanish konec4_60ccd5f3:

    # e1 "А что если я скажу, что у тебя даже есть возможность мне..."
    e1 "¿Y si te dijera que incluso tienes la oportunidad de...?"

# game/script3.rpy:2076
translate Spanish konec4_bba0cc7e:

    # e "Вовсе нет."
    e "Para nada."

# game/script3.rpy:2078
translate Spanish konec4_dffb6ebb:

    # "Он не ожидал от меня такой реакции."
    "No esperaba esa reacción de mi parte."

# game/script3.rpy:2079
translate Spanish konec4_621e7120:

    # e "Я думаю, что моя жизнь слишком коротка, что бы держать на кого то обиду."
    e "Creo que mi vida es demasiado corta para guardarle rencor a alguien."

# game/script3.rpy:2080
translate Spanish konec4_b5aab812:

    # "Удивительно, но это действительно мои слова."
    "Sorprendentemente, esas son realmente mis palabras."

# game/script3.rpy:2081
translate Spanish konec4_32ed014a:

    # "А он выглядел вызывающе."
    "Y él lucía desafiante."

# game/script3.rpy:2082
translate Spanish konec4_1dfa92a6:

    # "Хотел опять предложить мне что-то, что меня испугает или даст надежду."
    "Quería volver a ofrecerme algo que me asustara o me diera esperanza."

# game/script3.rpy:2083
translate Spanish konec4_fdc1c699:

    # "Но и я возможно творю глупость, но это моё дело."
    "Pero quizás yo también estoy haciendo una tontería, y es asunto mío."

# game/script3.rpy:2084
translate Spanish konec4_47d08ff0:

    # e "Даже больше..."
    e "Incluso más..."

# game/script3.rpy:2085
translate Spanish konec4_cfb44e1c:

    # e "Может, то, что случилось."
    e "Quizás, lo que pasó."

# game/script3.rpy:2086
translate Spanish konec4_04e524ee:

    # e "Должно было случится?"
    e "¿Tenía que pasar?"

# game/script3.rpy:2087
translate Spanish konec4_950d6b3e:

    # "Он смотрел на меня с недоверием."
    "Me miraba con incredulidad."

# game/script3.rpy:2088
translate Spanish konec4_11ed9a50:

    # "Словно он ждал этих слов, но всё ещё не верит в них."
    "Como si hubiera estado esperando estas palabras, pero aún no terminaba de creérselas."

# game/script3.rpy:2089
translate Spanish konec4_d6433c5b:

    # e "Я не думаю, что ты плохой парень, Бен."
    e "No creo que seas un mal tipo, Ben."

# game/script3.rpy:2090
translate Spanish konec4_02814083:

    # e1 "Нет, прекрати."
    e1 "No, basta."

# game/script3.rpy:2091
translate Spanish konec4_d153035c:

    # e1 "Просто попробуй уснуть."
    e1 "Solo intenta dormir."

# game/script3.rpy:2092
translate Spanish konec4_4ebdee54:

    # "Он пытается закрыться от моих слов."
    "Intenta protegerse de mis palabras."

# game/script3.rpy:2093
translate Spanish konec4_bd1dd311:

    # e "Бен, я просто..."
    e "Ben, solo..."

# game/script3.rpy:2095
translate Spanish konec4_ff5e63a4:

    # e1 "Я сказал прямо! Отвали от меня. Ты глухая?"
    e1 "¡Te lo dije claro! Déjame en paz. ¿Estás sorda?"

# game/script3.rpy:2096
translate Spanish konec4_00f0e446:

    # "Я дёрнулась."
    "Me estremecí."

# game/script3.rpy:2103
translate Spanish love_5ba8fa39:

    # "Может..."
    "Quizás..."

# game/script3.rpy:2104
translate Spanish love_b652a4ee:

    # "Хоть сейчас мне следует пойти ему наперекор?"
    "¿Debería llevarle la contraria ahora?"

# game/script3.rpy:2110
translate Spanish love_58f16a49:

    # e "Нет."
    e "No."

# game/script3.rpy:2111
translate Spanish love_8c5188dd:

    # e "Я хочу верить."
    e "Quiero creer."

# game/script3.rpy:2113
translate Spanish love_ad4b5bb2:

    # e1 "Во что? Прекрати этот цирк."
    e1 "¿En qué? Deja ya este circo."

# game/script3.rpy:2114
translate Spanish love_a5df5a8e:

    # e "Бен."
    e "Ben."

# game/script3.rpy:2116
translate Spanish love_208b30a4:

    # e "Я просто знаю, что ты возможно чувствуешь."
    e "Solo sé lo que quizás estás sintiendo."

# game/script3.rpy:2117
translate Spanish love_a2156709:

    # e "Я думаю, что твоё сердце всё ещё хранит в себе тепло."
    e "Creo que tu corazón aún guarda algo de calidez."

# game/script3.rpy:2119
translate Spanish love_1a436062:

    # e1 "Прекрати..."
    e1 "Basta..."

# game/script3.rpy:2120
translate Spanish love_0eafc0d4:

    # e "Кто-то причинил тебе боль, такую сильную, что ты до сих пор не можешь забыть о ней, и веришь, что причинив её другим ты..."
    e "Alguien te hizo daño, un dolor tan fuerte que aún no puedes olvidar, y crees que al hacérselo a otros..."

# game/script3.rpy:2133
translate Spanish konec10_846210d7:

    # e1 "Просто замолкни!"
    e1 "¡Cállate!"

# game/script3.rpy:2134
translate Spanish konec10_30af9fe9:

    # "Он опрокинул меня на кровать."
    "Me empujó contra la cama."

# game/script3.rpy:2135
translate Spanish konec10_f2f21a6c:

    # "Его руки легли мне на шею, но не спешили сжиматься. Он держал меня даже с неким опасением."
    "Sus manos se posaron en mi cuello, pero no se apresuraron a apretar. Incluso me sujetaba con cierta cautela."

# game/script3.rpy:2136
translate Spanish konec10_1021555e:

    # e1 "Думаешь, что сможешь залезть мне в душу?!"
    e1 "¿¡Crees que podrás hurgar en mi alma!?"

# game/script3.rpy:2137
translate Spanish konec10_846210d7_1:

    # e1 "Просто замолкни!"
    e1 "¡Cállate!"

# game/script3.rpy:2138
translate Spanish konec10_01989c30:

    # "Его пальцы начали едва ощутимо дрожать."
    "Sus dedos comenzaron a temblar apenas perceptiblemente."

# game/script3.rpy:2139
translate Spanish konec10_44a2d633:

    # e1 "Ты не знаешь меня! Я вирус! Я убийца! Мне несвойственно милосердие!"
    e1 "¡No me conoces! ¡Soy un virus! ¡Soy un asesino! ¡La misericordia no va conmigo!"

# game/script3.rpy:2140
translate Spanish konec10_c4512cee:

    # e1 "И я!"
    e1 "¡Y yo!"

# game/script3.rpy:2141
translate Spanish konec10_28790144:

    # e1 "Твой!"
    e1 "¡Tu...!"

# game/script3.rpy:2142
translate Spanish konec10_512c5d12:

    # e1 "Мучитель!"
    e1 "¡Verdugo!"

# game/script3.rpy:2143
translate Spanish konec10_f2e6da5a:

    # "Теперь хватка стала сильнее."
    "Ahora el agarre se hizo más fuerte."

# game/script3.rpy:2144
translate Spanish konec10_a019b94f:

    # "Я не сопротивлялась, просто смотрела из под полуприкрытых век."
    "No opuse resistencia, solo lo miré desde mis párpados semicerrados."

# game/script3.rpy:2146
translate Spanish konec10_3d81fec6:

    # "Он поморщился когда я положила руки ему на плечи."
    "Hizo una mueca cuando le puse las manos sobre los hombros."

# game/script3.rpy:2147
translate Spanish konec10_0ee27aea:

    # e1 "Просто перестань..."
    e1 "Simplemente para..."

# game/script3.rpy:2148
translate Spanish konec10_a4e63e88:

    # "Я тепло ему улыбаюсь."
    "Le sonrío con calidez."

# game/script3.rpy:2149
translate Spanish konec10_ee743238:

    # "Теперь он не сопротивляется мне."
    "Ahora ya no me rechaza."

# game/script3.rpy:2151
translate Spanish konec10_71d9a78a:

    # "Я действительно согласна с теми, кто говорил, что я больна."
    "De verdad estoy de acuerdo con quienes decían que estoy enferma."

# game/script3.rpy:2152
translate Spanish konec10_a0236a2e:

    # "То, что я делаю — не нормально."
    "Lo que hago no es normal."

# game/script3.rpy:2153
translate Spanish konec10_7dd2acab:

    # "Я с теплом принимаю того, кто недавно причинил мне боль."
    "Acojo con calidez a quien hace poco me hizo daño."

# game/script3.rpy:2154
translate Spanish konec10_8906b037:

    # "Мои руки ползут к его затылку зарываясь в волосы."
    "Mis manos se deslizan hacia su nuca, enredándose en su cabello."

# game/script3.rpy:2155
translate Spanish konec10_7da366f9:

    # "Я тяну его вниз, заставляя Бена почти упасть на меня."
    "Lo atraigo hacia abajo, haciendo que Ben casi caiga sobre mí."

# game/script3.rpy:2157
translate Spanish konec10_892b60d4:

    # "Я не уверена, что то, что я делаю правильно, но мне плевать."
    "No estoy segura de que lo que hago esté bien, pero me importa un comino."

# game/script3.rpy:2158
translate Spanish konec10_bc55bd5f:

    # e1 "Сколько можно?"
    e1 "¿Hasta cuándo?"

# game/script3.rpy:2159
translate Spanish konec10_fa74a3e0:

    # "Он рычит, руки сжимаются сильнее."
    "Gruñe, y sus manos aprietan con más fuerza."

# game/script3.rpy:2161
translate Spanish konec10_516ca9ed:

    # "Я вновь закрываю глаза и вовлекаю его в аккуратный поцелуй."
    "Vuelvo a cerrar los ojos y lo arrastro a un beso suave."

# game/script3.rpy:2162
translate Spanish konec10_0a8db145:

    # "Он не противится мне: не пытается вырваться. Но пока не отвечает."
    "No se resiste: no intenta zafarse. Pero por ahora no corresponde."

# game/script3.rpy:2163
translate Spanish konec10_6a83d119:

    # "Я же изучала его рот своим языком."
    "Yo exploraba su boca con mi lengua."

# game/script3.rpy:2164
translate Spanish konec10_e7b815e2:

    # "Мне нравилось ранить язык о его клыки, покусывать губы."
    "Me gustaba hacerme pequeños cortes en la lengua contra sus colmillos, mordisquear sus labios."

# game/script3.rpy:2165
translate Spanish konec10_42d35e1a:

    # "А он словно боялся ответить мне."
    "Y él parecía temer responderme."

# game/script3.rpy:2166
translate Spanish konec10_8655cc76:

    # "Его пальцы больше не сжимали мою шею."
    "Sus dedos ya no apretaban mi cuello."

# game/script3.rpy:2167
translate Spanish konec10_ae72cc37:

    # "Наконец он углубил поцелуй, я тут же почувствовала прогорклый вкус его крови."
    "Por fin profundizó el beso, y al instante sentí el sabor rancio de su sangre."

# game/script3.rpy:2168
translate Spanish konec10_6ec25ef2:

    # "Он не дал мне насладиться собой и оторвался от моих губ."
    "No me dejó disfrutar del momento y se separó de mis labios."

# game/script3.rpy:2170
translate Spanish konec10_cd2f58e4:

    # "От наших губ потянулась тонкая нить слюны."
    "De nuestros labios se estiró un fino hilo de saliva."

# game/script3.rpy:2171
translate Spanish konec10_639f3729:

    # "Я заглянула ему в глаза."
    "Lo miré a los ojos."

# game/script3.rpy:2172
translate Spanish konec10_c6b4272e:

    # "Он холоден, но в этом холоде я больше не вижу желания убить."
    "Está frío, pero en esa frialdad ya no veo ganas de matar."

translate Spanish strings:

    # game/script3.rpy:31
    old "Отказаться от идеи"
    new "Descartar la idea"

    # game/script3.rpy:42
    old "Вставить картридж"
    new "Insertar el cartucho"

    # game/script3.rpy:48
    old "Осмотреть картридж"
    new "Examinar el cartucho"

    # game/script3.rpy:104
    old "Да, кажется, я припоминаю..."
    new "Sí, creo que lo recuerdo..."

    # game/script3.rpy:111
    old "Нет, ничего не могу вспомнить"
    new "No, no logro recordar nada"

    # game/script3.rpy:117
    old "Промолчать"
    new "Guardar silencio"

    # game/script3.rpy:193
    old "Взять нож"
    new "Tomar el cuchillo"

    # game/script3.rpy:198
    old "Оставить нож"
    new "Dejar el cuchillo"

    # game/script3.rpy:209
    old "Можно попробовать"
    new "Podría intentarlo"

    # game/script3.rpy:218
    old "Не сейчас..."
    new "Ahora no..."

    # game/script3.rpy:228
    old "Отдать нож"
    new "Entregar el cuchillo"

    # game/script3.rpy:233
    old "Напасть"
    new "Atacar"

    # game/script3.rpy:318
    old "Думаю, я помогу."
    new "Creo que te ayudaré."

    # game/script3.rpy:333
    old "Может в другой раз..."
    new "Quizás en otra ocasión..."

    # game/script3.rpy:340
    old "Нет! Оставь меня в покое, больной урод!"
    new "¡No! ¡Déjame en paz, monstruo enfermo!"

    # game/script3.rpy:376
    old "Молить о свободе"
    new "Suplicar por la libertad"

    # game/script3.rpy:410
    old "Попытаться разбить стекло"
    new "Intentar romper el cristal"

    # game/script3.rpy:619
    old "Смириться"
    new "Resignarme"

    # game/script3.rpy:629
    old "Постараться открыть глаза"
    new "Intentar abrir los ojos"

    # game/script3.rpy:683
    old "Остаться"
    new "Quedarme"

    # game/script3.rpy:698
    old "Идти вперёд"
    new "Seguir adelante"

    # game/script3.rpy:787
    old "Попросить его рассказать о Бене"
    new "Pedirle que hable sobre Ben"

    # game/script3.rpy:789
    old "Попросить его рассказать о себе"
    new "Pedirle que hable sobre sí mismo"

    # game/script3.rpy:815
    old "Ты прав, я могу простить его."
    new "Tienes razón, puedo perdonarlo."

    # game/script3.rpy:817
    old "Думаю, что мне надо для этого время"
    new "Creo que necesito tiempo para ello"

    # game/script3.rpy:819
    old "Я ни за что не прощу его."
    new "Jamás lo perdonaré."

    # game/script3.rpy:854
    old "Уйти"
    new "Marcharme"

    # game/script3.rpy:979
    old "Думаю мне надо для этого время"
    new "Creo que necesito tiempo para ello"

    # game/script3.rpy:1001
    old "Принять идею"
    new "Aceptar la propuesta"

    # game/script3.rpy:1020
    old "Отказаться"
    new "Rechazarla"

    # game/script3.rpy:1060
    old "Почему ты стал таким?"
    new "¿Por qué te volviste así?"

    # game/script3.rpy:1062
    old "Где твои глаза?"
    new "¿Dónde están tus ojos?"

    # game/script3.rpy:1064
    old "Ты оставишь меня в живых?"
    new "¿Me dejarás con vida?"

    # game/script3.rpy:1191
    old "Продолжить"
    new "Continuar"

    # game/script3.rpy:1207
    old "Зельда"
    new "Zelda"

    # game/script3.rpy:1209
    old "Линк"
    new "Link"

    # game/script3.rpy:1211
    old "Сидон"
    new "Sidon"

    # game/script3.rpy:1316
    old "Топор"
    new "Hacha"

    # game/script3.rpy:1318
    old "Меч"
    new "Espada"

    # game/script3.rpy:1320
    old "Лук"
    new "Arco"

    # game/script3.rpy:1326
    old "Герудо"
    new "Gerudo"

    # game/script3.rpy:1328
    old "Рито"
    new "Rito"

    # game/script3.rpy:1330
    old "Зора"
    new "Zora"

    # game/script3.rpy:1337
    old "1987"
    new "1987"

    # game/script3.rpy:1339
    old "1993"
    new "1993"

    # game/script3.rpy:1341
    old "1989"
    new "1989"

    # game/script3.rpy:1348
    old "19"
    new "19"

    # game/script3.rpy:1350
    old "29"
    new "29"

    # game/script3.rpy:1352
    old "16"
    new "16"

    # game/script3.rpy:1370
    old "Идти до конца"
    new "Ir hasta el final"

    # game/script3.rpy:1372
    old "Закончить"
    new "Terminar"

    # game/script3.rpy:1398
    old "Лево"
    new "Izquierda"

    # game/script3.rpy:1403
    old "Центр"
    new "Centro"

    # game/script3.rpy:1408
    old "Право"
    new "Derecha"

    # game/script3.rpy:1628
    old "Да, ты должен уйти."
    new "Sí, debes irte."

    # game/script3.rpy:1638
    old "Можешь остаться ещё на чашку чая."
    new "Puedes quedarte a tomar otra taza de té."

    # game/script3.rpy:1652
    old "Проваливай"
    new "Lárgate"

    # game/script3.rpy:1695
    old "Не нападать"
    new "No atacar"

    # game/script3.rpy:1728
    old "Убить его"
    new "Matarlo"

    # game/script3.rpy:1730
    old "Пощадить"
    new "Perdonarle la vida"

    # game/script3.rpy:1910
    old "Я видела странный сон"
    new "Tuve un sueño extraño"

    # game/script3.rpy:1912
    old "Мне плохо от той дряни, что ты мне дал."
    new "Me siento mal por culpa de esa porquería que me diste."

    # game/script3.rpy:1916
    old "Мне совсем не спится, можно побыть с тобой?"
    new "No tengo sueño en absoluto, ¿puedo quedarme contigo?"

    # game/script3.rpy:1979
    old "Спрыгнуть"
    new "Saltar"

    # game/script3.rpy:1981
    old "Струсить"
    new "Acobardarme"

    # game/script3.rpy:2106
    old "Отступить"
    new "Retroceder"

    # game/script3.rpy:2108
    old "Настоять на своём"
    new "Mantener mi postura"

    old "Слот1"
    new "Ranura 1"

    old "Слот2"
    new "Ranura 2"

    old "Слот3"
    new "Ranura 3"

    old "Слот4"
    new "Ranura 4"
    
    old "Ты"
    new "Tú"

    old "Бен"
    new "Ben"

    old "???"
    new "???"

    old "Сильвер"
    new "Silver"
