# TODO: Translation updated at 2026-10-07 22:53

translate Spanish strings:

    # game/screens.rpy:256
    old "Назад"
    new "Atrás"

    # game/screens.rpy:257
    old "История"
    new "Historial"

    # game/screens.rpy:258
    old "Пропуск"
    new "Saltar"

    # game/screens.rpy:259
    old "Авто"
    new "Automático"

    # game/screens.rpy:260
    old "Сохранить"
    new "Guardar"

    # game/screens.rpy:261
    old "Б.Сохр"
    new "G.Ráp."

    # game/screens.rpy:262
    old "Б.Загр"
    new "C.Ráp."

    # game/screens.rpy:263
    old "Опции"
    new "Opciones"

    # game/screens.rpy:304
    old "Начать"
    new "Empezar"

    # game/screens.rpy:312
    old "Загрузить"
    new "Cargar"

    # game/screens.rpy:314
    old "Настройки"
    new "Ajustes"

    # game/screens.rpy:318
    old "Завершить повтор"
    new "Finalizar repetición"

    # game/screens.rpy:322
    old "Главное меню"
    new "Menú principal"

    # game/screens.rpy:324
    old "Об игре"
    new "Acerca del juego"

    # game/screens.rpy:329
    old "Помощь"
    new "Ayuda"

    # game/screens.rpy:335
    old "Выход"
    new "Salir"

    # game/screens.rpy:541
    old "Вернуться"
    new "Volver"

    # game/screens.rpy:624
    old "Версия [config.version!t]\n"
    new "Versión [config.version!t]\n"

    # game/screens.rpy:630
    old "Сделано с помощью {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "Hecho con {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"

    # game/screens.rpy:665
    old "{} страница"
    new "{} página"

    # game/screens.rpy:665
    old "Автосохранения"
    new "Guardados automáticos"

    # game/screens.rpy:665
    old "Быстрые сохранения"
    new "Guardados rápidos"

    # game/screens.rpy:708
    old "{#file_time}%A, %d %B %Y, %H:%M"
    new "{#file_time}%A, %d %B %Y, %H:%M"

    # game/screens.rpy:708
    old "Пустой слот"
    new "Ranura vacía"

    # game/screens.rpy:725
    old "<"
    new "<"

    # game/screens.rpy:728
    old "{#auto_page}А"
    new "{#auto_page}A"

    # game/screens.rpy:731
    old "{#quick_page}Б"
    new "{#quick_page}B"

    # game/screens.rpy:737
    old ">"
    new ">"

    # game/screens.rpy:793
    old "Режим экрана"
    new "Modo de pantalla"

    # game/screens.rpy:794
    old "Оконный"
    new "Ventana"

    # game/screens.rpy:795
    old "Полный"
    new "Pantalla completa"

    # game/screens.rpy:799
    old "Сторона отката"
    new "Lado de retroceso"

    # game/screens.rpy:800
    old "Отключено"
    new "Desactivado"

    # game/screens.rpy:801
    old "Левая"
    new "Izquierda"

    # game/screens.rpy:802
    old "Правая"
    new "Derecha"

    # game/screens.rpy:807
    old "Всего текста"
    new "Todo el texto"

    # game/screens.rpy:808
    old "После выборов"
    new "Tras elecciones"

    # game/screens.rpy:809
    old "Переходов"
    new "Transiciones"

    # game/screens.rpy:822
    old "Скорость текста"
    new "Velocidad del texto"

    # game/screens.rpy:826
    old "Скорость авточтения"
    new "Velocidad de lectura automática"

    # game/screens.rpy:833
    old "Громкость музыки"
    new "Volumen de música"

    # game/screens.rpy:840
    old "Громкость звуков"
    new "Volumen de efectos"

    # game/screens.rpy:846
    old "Тест"
    new "Prueba"

    # game/screens.rpy:850
    old "Громкость голоса"
    new "Volumen de voz"

    # game/screens.rpy:861
    old "Без звука"
    new "Silencio"

    # game/screens.rpy:981
    old "История диалогов пуста."
    new "El historial de diálogos está vacío."

    # game/screens.rpy:1051
    old "Клавиатура"
    new "Teclado"

    # game/screens.rpy:1052
    old "Мышь"
    new "Ratón"

    # game/screens.rpy:1055
    old "Геймпад"
    new "Mando"

    # game/screens.rpy:1068
    old "Enter"
    new "Enter"

    # game/screens.rpy:1069
    old "Прохождение диалогов, активация интерфейса."
    new "Avanzar diálogos, activar interfaz."

    # game/screens.rpy:1072
    old "Пробел"
    new "Espacio"

    # game/screens.rpy:1073
    old "Прохождение диалогов без возможности делать выбор."
    new "Avanzar diálogos sin posibilidad de elegir."

    # game/screens.rpy:1076
    old "Стрелки"
    new "Flechas"

    # game/screens.rpy:1077
    old "Навигация по интерфейсу."
    new "Navegación por la interfaz."

    # game/screens.rpy:1080
    old "Esc"
    new "Esc"

    # game/screens.rpy:1081
    old "Вход в игровое меню."
    new "Acceder al menú del juego."

    # game/screens.rpy:1084
    old "Ctrl"
    new "Ctrl"

    # game/screens.rpy:1085
    old "Пропускает диалоги, пока зажат."
    new "Salta diálogos mientras se mantiene presionado."

    # game/screens.rpy:1088
    old "Tab"
    new "Tab"

    # game/screens.rpy:1089
    old "Включает режим пропуска."
    new "Activa el modo de salto."

    # game/screens.rpy:1092
    old "Page Up"
    new "Re Pág"

    # game/screens.rpy:1093
    old "Откат назад по сюжету игры."
    new "Retrocede en la trama del juego."

    # game/screens.rpy:1096
    old "Page Down"
    new "Av Pág"

    # game/screens.rpy:1097
    old "Откатывает предыдущее действие вперёд."
    new "Avanza la acción anterior."

    # game/screens.rpy:1101
    old "Скрывает интерфейс пользователя."
    new "Oculta la interfaz de usuario."

    # game/screens.rpy:1105
    old "Делает снимок экрана."
    new "Captura una imagen de la pantalla."

    # game/screens.rpy:1109
    old "Включает поддерживаемый {a=https://www.renpy.org/l/voicing}синтезатор речи{/a}."
    new "Activa el {a=https://www.renpy.org/l/voicing}sintetizador de voz{/a} compatible."

    # game/screens.rpy:1113
    old "Открывает меню специальных возможностей."
    new "Abre el menú de accesibilidad."

    # game/screens.rpy:1119
    old "Левый клик"
    new "Clic izquierdo"

    # game/screens.rpy:1123
    old "Клик колёсиком"
    new "Clic con rueda"

    # game/screens.rpy:1127
    old "Правый клик"
    new "Clic derecho"

    # game/screens.rpy:1131
    old "Колёсико вверх\nКлик на сторону отката"
    new "Rueda hacia arriba\nClic en el lado de retroceso"

    # game/screens.rpy:1135
    old "Колёсико вниз"
    new "Rueda hacia abajo"

    # game/screens.rpy:1142
    old "Правый триггер\nA/Нижняя кнопка"
    new "Gatillo derecho\nA/Botón inferior"

    # game/screens.rpy:1146
    old "Левый Триггер\nЛевый Бампер"
    new "Gatillo izquierdo\nBumper izquierdo"

    # game/screens.rpy:1150
    old "Правый бампер"
    new "Bumper derecho"

    # game/screens.rpy:1155
    old "Крестовина, Стики"
    new "Cruceta, Joysticks"

    # game/screens.rpy:1159
    old "Start, Guide"
    new "Start, Guide"

    # game/screens.rpy:1163
    old "Y/Верхняя кнопка"
    new "Y/Botón superior"

    # game/screens.rpy:1166
    old "Калибровка"
    new "Calibración"

    # game/screens.rpy:1231
    old "Да"
    new "Sí"

    # game/screens.rpy:1232
    old "Нет"
    new "No"

    # game/screens.rpy:1278
    old "Пропускаю"
    new "Saltar"

    # game/screens.rpy:1500
    old "Меню"
    new "Menú"

