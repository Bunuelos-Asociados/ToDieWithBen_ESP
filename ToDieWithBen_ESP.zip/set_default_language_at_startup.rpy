image mitch_spanish = "tl/Spanish/image/mitch.png"

label splashscreen:

    if preferences.language == "Spanish":
        scene mitch_spanish
    else:
        scene mitch

    pause
    return

init 1000 python:
    renpy.game.preferences.language = "Spanish"
    
    
    